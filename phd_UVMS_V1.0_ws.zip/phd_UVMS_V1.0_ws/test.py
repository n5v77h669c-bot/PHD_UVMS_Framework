
#!/usr/bin/env python3
import pygame
import time

pygame.init()
pygame.joystick.init()

if pygame.joystick.get_count() == 0:
    print("未检测到手柄")
    exit()

joystick = pygame.joystick.Joystick(0)
joystick.init()
print(f"手柄名称: {joystick.get_name()}")
print(f"轴数量: {joystick.get_numaxes()}")
print(f"按钮数量: {joystick.get_numbuttons()}")
print("\n正在读取轴值，移动摇杆/按扳机查看...\n")

while True:
    pygame.event.pump()
    axes = []
    for i in range(joystick.get_numaxes()):
        axes.append(joystick.get_axis(i))
    
    # 只显示有变化的轴
    if max([abs(x) for x in axes]) > 0.05:
        print(f"轴值: {[f'{x:+.2f}' for x in axes]}")
    
    time.sleep(0.05)