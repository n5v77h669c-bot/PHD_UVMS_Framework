import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    
    slave_machine_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('phd_slave_machine'),
                'launch', 'slave_machine.launch.py'
            )
        ])
    )

    master_machine_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('phd_master_machine'),
                'launch', 'phd_master_machine.launch.py'
            )
        ])
    )

    moveit_real_machine_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('phd_uvms_moveitGZ'),
                'launch', 'moveitRM.launch.py'
            )
        ])
    )

    # 延迟 x秒 后启动姿态控制
    pose_control_real_launch = TimerAction(
        period=1.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    os.path.join(
                        get_package_share_directory('phd_uvms_poseCtrl'),
                        'launch', 'pose_control_real.launch.py'
                    )
                ])
            )
        ]
    )
    return LaunchDescription([
        slave_machine_launch,
        master_machine_launch,
        moveit_real_machine_launch,
        pose_control_real_launch,
    ])