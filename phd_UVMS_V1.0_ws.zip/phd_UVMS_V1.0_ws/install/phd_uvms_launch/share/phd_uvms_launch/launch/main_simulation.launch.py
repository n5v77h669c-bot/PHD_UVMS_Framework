import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    
    # 1. 启动Gazebo仿真
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('phd_uvms_moveitGZ'),
                'launch', 'gazebo.launch.py'
            )
        ])
    )
    
    # 2. 延迟5秒后启动MoveIt和RViz
    moveit_launch = TimerAction(
        period=8.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    os.path.join(
                        get_package_share_directory('phd_uvms_moveitGZ'),
                        'launch', 'moveitGZ.launch.py'
                    )
                ])
            )
        ]
    )
    
    # 3. 延迟3秒后启动姿态控制（在Gazebo启动后，MoveIt启动前）
    pose_control_launch = TimerAction(
        period=3.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    os.path.join(
                        get_package_share_directory('phd_uvms_poseCtrl'),
                        'launch', 'pose_control_sim.launch.py'
                    )
                ])
            )
        ]
    )
    
    return LaunchDescription([
        gazebo_launch,          
        pose_control_launch,    
        moveit_launch,          
    ])