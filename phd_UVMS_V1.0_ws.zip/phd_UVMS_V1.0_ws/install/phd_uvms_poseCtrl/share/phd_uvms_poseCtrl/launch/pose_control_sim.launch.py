import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import TimerAction

def generate_launch_description():
    
    xbox_pose_control_node = Node(
        package='phd_uvms_poseCtrl',
        executable='xbox_pose_control',
        name='xbox_pose_control',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info']
    )

    pid_control_node = Node(
        package='phd_uvms_poseCtrl',
        executable='pid_control',
        name='pid_control',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info']
    )

    pos_cmd_node = Node(
        package='phd_uvms_poseCtrl',
        executable='pos_cmd',
        name='pos_cmd',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info']
    )

    pos_glo2loc_tf_node = Node(
        package='phd_uvms_poseCtrl',
        executable='pos_glo2loc_tf',
        name='pos_glo2loc_tf',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info']
    )

    thruster_allocator_node = Node(
        package='phd_uvms_poseCtrl',
        executable='thruster_allocator',
        name='thruster_allocator',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info']
    )

    sim_hydrodynamic_node = Node(
        package='phd_uvms_poseCtrl',
        executable='sim_hydrodynamic',
        name='sim_hydrodynamic',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info']
    )

    return LaunchDescription([
        xbox_pose_control_node,
        pid_control_node,
        pos_cmd_node,
        pos_glo2loc_tf_node,
        thruster_allocator_node,
        sim_hydrodynamic_node,
    ])

