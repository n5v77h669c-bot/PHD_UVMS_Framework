# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_phd_uvms_moveitGZ_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED phd_uvms_moveitGZ_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(phd_uvms_moveitGZ_FOUND FALSE)
  elseif(NOT phd_uvms_moveitGZ_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(phd_uvms_moveitGZ_FOUND FALSE)
  endif()
  return()
endif()
set(_phd_uvms_moveitGZ_CONFIG_INCLUDED TRUE)

# output package information
if(NOT phd_uvms_moveitGZ_FIND_QUIETLY)
  message(STATUS "Found phd_uvms_moveitGZ: 0.3.0 (${phd_uvms_moveitGZ_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'phd_uvms_moveitGZ' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT ${phd_uvms_moveitGZ_DEPRECATED_QUIET})
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(phd_uvms_moveitGZ_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "")
foreach(_extra ${_extras})
  include("${phd_uvms_moveitGZ_DIR}/${_extra}")
endforeach()
