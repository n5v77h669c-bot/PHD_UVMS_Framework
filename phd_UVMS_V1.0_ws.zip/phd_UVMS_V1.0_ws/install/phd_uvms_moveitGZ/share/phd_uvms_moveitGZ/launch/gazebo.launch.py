import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, IncludeLaunchDescription, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
import xacro

def generate_launch_description():
    robot_name = 'phd_uvms'
    package_name = 'phd_uvms_moveitGZ'

    pkg_path = os.path.join(
        get_package_share_directory(package_name))
    
    world_file = os.path.join(pkg_path, 'world', 'underwater.world')

    gazebo = IncludeLaunchDescription(
                PythonLaunchDescriptionSource([os.path.join(
                    get_package_share_directory('gazebo_ros'), 'launch'), '/gazebo.launch.py']),
                    # launch_arguments={
                        # 'world': world_file,
                        # 'verbose': 'true',
                        # 'extra_gazebo_args': '--verbose'
                        # }.items()
             )
    
    xacro_file = os.path.join(pkg_path,
                              'config',
                              'phd_uvms.gazebo.xacro')
    
    doc = xacro.parse(open(xacro_file))
    xacro.process_doc(doc)
    params = {'robot_description': doc.toxml()}

    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[params]
    )

    
    spawn_entity = Node(package='gazebo_ros', executable='spawn_entity.py',
                        arguments=['-topic', 'robot_description',
                                   '-entity', robot_name,
                                   '-topic', 'robot_description',
                                   '-x', '0.0',      # X坐标
                                   '-y', '0.0',      # Y坐标  
                                   '-z', '1.0',     # Z坐标
                                   '-R', '0.0',      # 横滚角
                                   '-P', '0.0',      # 俯仰角
                                   '-Y', '0.0'       # 偏航角
                                   ],
                        output='screen')
    
    load_joint_state_broadcaster = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active',
             'joint_state_broadcaster'],
        output='screen'
    )

    load_joint_trajectory_controller_arm1 = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'arm1_group_controller'],
        output='screen'
    )

    load_joint_trajectory_controller_arm2 = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'arm2_group_controller'],
        output='screen'
    )

    load_joint_trajectory_controller_thrusters = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'thrusters_group_controller'],
        output='screen'
    )

    return LaunchDescription([
        RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=spawn_entity,
                on_exit=[load_joint_state_broadcaster],
            )
        ),
        RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=load_joint_state_broadcaster,
                on_exit=[load_joint_trajectory_controller_arm1,load_joint_trajectory_controller_arm2,load_joint_trajectory_controller_thrusters],
            )
        ),
        gazebo,
        node_robot_state_publisher,
        spawn_entity,
        # damping_controller,
    ])
