# generated from rosidl_generator_py/resource/_idl.py.em
# with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ThrusterStatus(type):
    """Metaclass of message 'ThrusterStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('phd_master_slave_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'phd_master_slave_interfaces.msg.ThrusterStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__thruster_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__thruster_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__thruster_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__thruster_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__thruster_status

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class ThrusterStatus(metaclass=Metaclass_ThrusterStatus):
    """Message class 'ThrusterStatus'."""

    __slots__ = [
        '_timestamp',
        '_set_power_lfu',
        '_set_power_lfd',
        '_set_power_rfu',
        '_set_power_rfd',
        '_set_power_lbu',
        '_set_power_lbd',
        '_set_power_rbu',
        '_set_power_rbd',
        '_actual_power_lfu',
        '_actual_power_lfd',
        '_actual_power_rfu',
        '_actual_power_rfd',
        '_actual_power_lbu',
        '_actual_power_lbd',
        '_actual_power_rbu',
        '_actual_power_rbd',
        '_data_valid',
        '_temperature',
    ]

    _fields_and_field_types = {
        'timestamp': 'builtin_interfaces/Time',
        'set_power_lfu': 'uint8',
        'set_power_lfd': 'uint8',
        'set_power_rfu': 'uint8',
        'set_power_rfd': 'uint8',
        'set_power_lbu': 'uint8',
        'set_power_lbd': 'uint8',
        'set_power_rbu': 'uint8',
        'set_power_rbd': 'uint8',
        'actual_power_lfu': 'uint8',
        'actual_power_lfd': 'uint8',
        'actual_power_rfu': 'uint8',
        'actual_power_rfd': 'uint8',
        'actual_power_lbu': 'uint8',
        'actual_power_lbd': 'uint8',
        'actual_power_rbu': 'uint8',
        'actual_power_rbd': 'uint8',
        'data_valid': 'boolean',
        'temperature': 'float',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from builtin_interfaces.msg import Time
        self.timestamp = kwargs.get('timestamp', Time())
        self.set_power_lfu = kwargs.get('set_power_lfu', int())
        self.set_power_lfd = kwargs.get('set_power_lfd', int())
        self.set_power_rfu = kwargs.get('set_power_rfu', int())
        self.set_power_rfd = kwargs.get('set_power_rfd', int())
        self.set_power_lbu = kwargs.get('set_power_lbu', int())
        self.set_power_lbd = kwargs.get('set_power_lbd', int())
        self.set_power_rbu = kwargs.get('set_power_rbu', int())
        self.set_power_rbd = kwargs.get('set_power_rbd', int())
        self.actual_power_lfu = kwargs.get('actual_power_lfu', int())
        self.actual_power_lfd = kwargs.get('actual_power_lfd', int())
        self.actual_power_rfu = kwargs.get('actual_power_rfu', int())
        self.actual_power_rfd = kwargs.get('actual_power_rfd', int())
        self.actual_power_lbu = kwargs.get('actual_power_lbu', int())
        self.actual_power_lbd = kwargs.get('actual_power_lbd', int())
        self.actual_power_rbu = kwargs.get('actual_power_rbu', int())
        self.actual_power_rbd = kwargs.get('actual_power_rbd', int())
        self.data_valid = kwargs.get('data_valid', bool())
        self.temperature = kwargs.get('temperature', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.timestamp != other.timestamp:
            return False
        if self.set_power_lfu != other.set_power_lfu:
            return False
        if self.set_power_lfd != other.set_power_lfd:
            return False
        if self.set_power_rfu != other.set_power_rfu:
            return False
        if self.set_power_rfd != other.set_power_rfd:
            return False
        if self.set_power_lbu != other.set_power_lbu:
            return False
        if self.set_power_lbd != other.set_power_lbd:
            return False
        if self.set_power_rbu != other.set_power_rbu:
            return False
        if self.set_power_rbd != other.set_power_rbd:
            return False
        if self.actual_power_lfu != other.actual_power_lfu:
            return False
        if self.actual_power_lfd != other.actual_power_lfd:
            return False
        if self.actual_power_rfu != other.actual_power_rfu:
            return False
        if self.actual_power_rfd != other.actual_power_rfd:
            return False
        if self.actual_power_lbu != other.actual_power_lbu:
            return False
        if self.actual_power_lbd != other.actual_power_lbd:
            return False
        if self.actual_power_rbu != other.actual_power_rbu:
            return False
        if self.actual_power_rbd != other.actual_power_rbd:
            return False
        if self.data_valid != other.data_valid:
            return False
        if self.temperature != other.temperature:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def timestamp(self):
        """Message field 'timestamp'."""
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'timestamp' field must be a sub message of type 'Time'"
        self._timestamp = value

    @builtins.property
    def set_power_lfu(self):
        """Message field 'set_power_lfu'."""
        return self._set_power_lfu

    @set_power_lfu.setter
    def set_power_lfu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_lfu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_lfu' field must be an unsigned integer in [0, 255]"
        self._set_power_lfu = value

    @builtins.property
    def set_power_lfd(self):
        """Message field 'set_power_lfd'."""
        return self._set_power_lfd

    @set_power_lfd.setter
    def set_power_lfd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_lfd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_lfd' field must be an unsigned integer in [0, 255]"
        self._set_power_lfd = value

    @builtins.property
    def set_power_rfu(self):
        """Message field 'set_power_rfu'."""
        return self._set_power_rfu

    @set_power_rfu.setter
    def set_power_rfu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_rfu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_rfu' field must be an unsigned integer in [0, 255]"
        self._set_power_rfu = value

    @builtins.property
    def set_power_rfd(self):
        """Message field 'set_power_rfd'."""
        return self._set_power_rfd

    @set_power_rfd.setter
    def set_power_rfd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_rfd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_rfd' field must be an unsigned integer in [0, 255]"
        self._set_power_rfd = value

    @builtins.property
    def set_power_lbu(self):
        """Message field 'set_power_lbu'."""
        return self._set_power_lbu

    @set_power_lbu.setter
    def set_power_lbu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_lbu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_lbu' field must be an unsigned integer in [0, 255]"
        self._set_power_lbu = value

    @builtins.property
    def set_power_lbd(self):
        """Message field 'set_power_lbd'."""
        return self._set_power_lbd

    @set_power_lbd.setter
    def set_power_lbd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_lbd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_lbd' field must be an unsigned integer in [0, 255]"
        self._set_power_lbd = value

    @builtins.property
    def set_power_rbu(self):
        """Message field 'set_power_rbu'."""
        return self._set_power_rbu

    @set_power_rbu.setter
    def set_power_rbu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_rbu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_rbu' field must be an unsigned integer in [0, 255]"
        self._set_power_rbu = value

    @builtins.property
    def set_power_rbd(self):
        """Message field 'set_power_rbd'."""
        return self._set_power_rbd

    @set_power_rbd.setter
    def set_power_rbd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'set_power_rbd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'set_power_rbd' field must be an unsigned integer in [0, 255]"
        self._set_power_rbd = value

    @builtins.property
    def actual_power_lfu(self):
        """Message field 'actual_power_lfu'."""
        return self._actual_power_lfu

    @actual_power_lfu.setter
    def actual_power_lfu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_lfu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_lfu' field must be an unsigned integer in [0, 255]"
        self._actual_power_lfu = value

    @builtins.property
    def actual_power_lfd(self):
        """Message field 'actual_power_lfd'."""
        return self._actual_power_lfd

    @actual_power_lfd.setter
    def actual_power_lfd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_lfd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_lfd' field must be an unsigned integer in [0, 255]"
        self._actual_power_lfd = value

    @builtins.property
    def actual_power_rfu(self):
        """Message field 'actual_power_rfu'."""
        return self._actual_power_rfu

    @actual_power_rfu.setter
    def actual_power_rfu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_rfu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_rfu' field must be an unsigned integer in [0, 255]"
        self._actual_power_rfu = value

    @builtins.property
    def actual_power_rfd(self):
        """Message field 'actual_power_rfd'."""
        return self._actual_power_rfd

    @actual_power_rfd.setter
    def actual_power_rfd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_rfd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_rfd' field must be an unsigned integer in [0, 255]"
        self._actual_power_rfd = value

    @builtins.property
    def actual_power_lbu(self):
        """Message field 'actual_power_lbu'."""
        return self._actual_power_lbu

    @actual_power_lbu.setter
    def actual_power_lbu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_lbu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_lbu' field must be an unsigned integer in [0, 255]"
        self._actual_power_lbu = value

    @builtins.property
    def actual_power_lbd(self):
        """Message field 'actual_power_lbd'."""
        return self._actual_power_lbd

    @actual_power_lbd.setter
    def actual_power_lbd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_lbd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_lbd' field must be an unsigned integer in [0, 255]"
        self._actual_power_lbd = value

    @builtins.property
    def actual_power_rbu(self):
        """Message field 'actual_power_rbu'."""
        return self._actual_power_rbu

    @actual_power_rbu.setter
    def actual_power_rbu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_rbu' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_rbu' field must be an unsigned integer in [0, 255]"
        self._actual_power_rbu = value

    @builtins.property
    def actual_power_rbd(self):
        """Message field 'actual_power_rbd'."""
        return self._actual_power_rbd

    @actual_power_rbd.setter
    def actual_power_rbd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'actual_power_rbd' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'actual_power_rbd' field must be an unsigned integer in [0, 255]"
        self._actual_power_rbd = value

    @builtins.property
    def data_valid(self):
        """Message field 'data_valid'."""
        return self._data_valid

    @data_valid.setter
    def data_valid(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'data_valid' field must be of type 'bool'"
        self._data_valid = value

    @builtins.property
    def temperature(self):
        """Message field 'temperature'."""
        return self._temperature

    @temperature.setter
    def temperature(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'temperature' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'temperature' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._temperature = value
