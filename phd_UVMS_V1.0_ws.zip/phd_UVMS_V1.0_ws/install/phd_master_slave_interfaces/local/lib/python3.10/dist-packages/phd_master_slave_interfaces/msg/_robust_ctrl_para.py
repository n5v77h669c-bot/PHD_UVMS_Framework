# generated from rosidl_generator_py/resource/_idl.py.em
# with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_RobustCtrlPara(type):
    """Metaclass of message 'RobustCtrlPara'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('phd_master_slave_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'phd_master_slave_interfaces.msg.RobustCtrlPara')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__robust_ctrl_para
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__robust_ctrl_para
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__robust_ctrl_para
            cls._TYPE_SUPPORT = module.type_support_msg__msg__robust_ctrl_para
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__robust_ctrl_para

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class RobustCtrlPara(metaclass=Metaclass_RobustCtrlPara):
    """Message class 'RobustCtrlPara'."""

    __slots__ = [
        '_robust_mode',
        '_s_x_k1',
        '_s_x_k2',
        '_s_x_f_lim',
        '_s_y_k1',
        '_s_y_k2',
        '_s_y_f_lim',
        '_s_z_k1',
        '_s_z_k2',
        '_s_z_f_lim',
        '_s_roll_k1',
        '_s_roll_k2',
        '_s_roll_t_lim',
        '_s_pitch_k1',
        '_s_pitch_k2',
        '_s_pitch_t_lim',
        '_s_yaw_k1',
        '_s_yaw_k2',
        '_s_yaw_t_lim',
        '_p_x_kp',
        '_p_x_ki',
        '_p_x_kd',
        '_p_x_f_lim',
        '_p_y_kp',
        '_p_y_ki',
        '_p_y_kd',
        '_p_y_f_lim',
        '_p_z_kp',
        '_p_z_ki',
        '_p_z_kd',
        '_p_z_f_lim',
        '_p_roll_kp',
        '_p_roll_ki',
        '_p_roll_kd',
        '_p_roll_t_lim',
        '_p_pitch_kp',
        '_p_pitch_ki',
        '_p_pitch_kd',
        '_p_pitch_t_lim',
        '_p_yaw_kp',
        '_p_yaw_ki',
        '_p_yaw_kd',
        '_p_yaw_t_lim',
        '_data_valid',
        '_timestamp',
    ]

    _fields_and_field_types = {
        'robust_mode': 'uint8',
        's_x_k1': 'float',
        's_x_k2': 'float',
        's_x_f_lim': 'float',
        's_y_k1': 'float',
        's_y_k2': 'float',
        's_y_f_lim': 'float',
        's_z_k1': 'float',
        's_z_k2': 'float',
        's_z_f_lim': 'float',
        's_roll_k1': 'float',
        's_roll_k2': 'float',
        's_roll_t_lim': 'float',
        's_pitch_k1': 'float',
        's_pitch_k2': 'float',
        's_pitch_t_lim': 'float',
        's_yaw_k1': 'float',
        's_yaw_k2': 'float',
        's_yaw_t_lim': 'float',
        'p_x_kp': 'float',
        'p_x_ki': 'float',
        'p_x_kd': 'float',
        'p_x_f_lim': 'float',
        'p_y_kp': 'float',
        'p_y_ki': 'float',
        'p_y_kd': 'float',
        'p_y_f_lim': 'float',
        'p_z_kp': 'float',
        'p_z_ki': 'float',
        'p_z_kd': 'float',
        'p_z_f_lim': 'float',
        'p_roll_kp': 'float',
        'p_roll_ki': 'float',
        'p_roll_kd': 'float',
        'p_roll_t_lim': 'float',
        'p_pitch_kp': 'float',
        'p_pitch_ki': 'float',
        'p_pitch_kd': 'float',
        'p_pitch_t_lim': 'float',
        'p_yaw_kp': 'float',
        'p_yaw_ki': 'float',
        'p_yaw_kd': 'float',
        'p_yaw_t_lim': 'float',
        'data_valid': 'boolean',
        'timestamp': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.robust_mode = kwargs.get('robust_mode', int())
        self.s_x_k1 = kwargs.get('s_x_k1', float())
        self.s_x_k2 = kwargs.get('s_x_k2', float())
        self.s_x_f_lim = kwargs.get('s_x_f_lim', float())
        self.s_y_k1 = kwargs.get('s_y_k1', float())
        self.s_y_k2 = kwargs.get('s_y_k2', float())
        self.s_y_f_lim = kwargs.get('s_y_f_lim', float())
        self.s_z_k1 = kwargs.get('s_z_k1', float())
        self.s_z_k2 = kwargs.get('s_z_k2', float())
        self.s_z_f_lim = kwargs.get('s_z_f_lim', float())
        self.s_roll_k1 = kwargs.get('s_roll_k1', float())
        self.s_roll_k2 = kwargs.get('s_roll_k2', float())
        self.s_roll_t_lim = kwargs.get('s_roll_t_lim', float())
        self.s_pitch_k1 = kwargs.get('s_pitch_k1', float())
        self.s_pitch_k2 = kwargs.get('s_pitch_k2', float())
        self.s_pitch_t_lim = kwargs.get('s_pitch_t_lim', float())
        self.s_yaw_k1 = kwargs.get('s_yaw_k1', float())
        self.s_yaw_k2 = kwargs.get('s_yaw_k2', float())
        self.s_yaw_t_lim = kwargs.get('s_yaw_t_lim', float())
        self.p_x_kp = kwargs.get('p_x_kp', float())
        self.p_x_ki = kwargs.get('p_x_ki', float())
        self.p_x_kd = kwargs.get('p_x_kd', float())
        self.p_x_f_lim = kwargs.get('p_x_f_lim', float())
        self.p_y_kp = kwargs.get('p_y_kp', float())
        self.p_y_ki = kwargs.get('p_y_ki', float())
        self.p_y_kd = kwargs.get('p_y_kd', float())
        self.p_y_f_lim = kwargs.get('p_y_f_lim', float())
        self.p_z_kp = kwargs.get('p_z_kp', float())
        self.p_z_ki = kwargs.get('p_z_ki', float())
        self.p_z_kd = kwargs.get('p_z_kd', float())
        self.p_z_f_lim = kwargs.get('p_z_f_lim', float())
        self.p_roll_kp = kwargs.get('p_roll_kp', float())
        self.p_roll_ki = kwargs.get('p_roll_ki', float())
        self.p_roll_kd = kwargs.get('p_roll_kd', float())
        self.p_roll_t_lim = kwargs.get('p_roll_t_lim', float())
        self.p_pitch_kp = kwargs.get('p_pitch_kp', float())
        self.p_pitch_ki = kwargs.get('p_pitch_ki', float())
        self.p_pitch_kd = kwargs.get('p_pitch_kd', float())
        self.p_pitch_t_lim = kwargs.get('p_pitch_t_lim', float())
        self.p_yaw_kp = kwargs.get('p_yaw_kp', float())
        self.p_yaw_ki = kwargs.get('p_yaw_ki', float())
        self.p_yaw_kd = kwargs.get('p_yaw_kd', float())
        self.p_yaw_t_lim = kwargs.get('p_yaw_t_lim', float())
        self.data_valid = kwargs.get('data_valid', bool())
        from builtin_interfaces.msg import Time
        self.timestamp = kwargs.get('timestamp', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.robust_mode != other.robust_mode:
            return False
        if self.s_x_k1 != other.s_x_k1:
            return False
        if self.s_x_k2 != other.s_x_k2:
            return False
        if self.s_x_f_lim != other.s_x_f_lim:
            return False
        if self.s_y_k1 != other.s_y_k1:
            return False
        if self.s_y_k2 != other.s_y_k2:
            return False
        if self.s_y_f_lim != other.s_y_f_lim:
            return False
        if self.s_z_k1 != other.s_z_k1:
            return False
        if self.s_z_k2 != other.s_z_k2:
            return False
        if self.s_z_f_lim != other.s_z_f_lim:
            return False
        if self.s_roll_k1 != other.s_roll_k1:
            return False
        if self.s_roll_k2 != other.s_roll_k2:
            return False
        if self.s_roll_t_lim != other.s_roll_t_lim:
            return False
        if self.s_pitch_k1 != other.s_pitch_k1:
            return False
        if self.s_pitch_k2 != other.s_pitch_k2:
            return False
        if self.s_pitch_t_lim != other.s_pitch_t_lim:
            return False
        if self.s_yaw_k1 != other.s_yaw_k1:
            return False
        if self.s_yaw_k2 != other.s_yaw_k2:
            return False
        if self.s_yaw_t_lim != other.s_yaw_t_lim:
            return False
        if self.p_x_kp != other.p_x_kp:
            return False
        if self.p_x_ki != other.p_x_ki:
            return False
        if self.p_x_kd != other.p_x_kd:
            return False
        if self.p_x_f_lim != other.p_x_f_lim:
            return False
        if self.p_y_kp != other.p_y_kp:
            return False
        if self.p_y_ki != other.p_y_ki:
            return False
        if self.p_y_kd != other.p_y_kd:
            return False
        if self.p_y_f_lim != other.p_y_f_lim:
            return False
        if self.p_z_kp != other.p_z_kp:
            return False
        if self.p_z_ki != other.p_z_ki:
            return False
        if self.p_z_kd != other.p_z_kd:
            return False
        if self.p_z_f_lim != other.p_z_f_lim:
            return False
        if self.p_roll_kp != other.p_roll_kp:
            return False
        if self.p_roll_ki != other.p_roll_ki:
            return False
        if self.p_roll_kd != other.p_roll_kd:
            return False
        if self.p_roll_t_lim != other.p_roll_t_lim:
            return False
        if self.p_pitch_kp != other.p_pitch_kp:
            return False
        if self.p_pitch_ki != other.p_pitch_ki:
            return False
        if self.p_pitch_kd != other.p_pitch_kd:
            return False
        if self.p_pitch_t_lim != other.p_pitch_t_lim:
            return False
        if self.p_yaw_kp != other.p_yaw_kp:
            return False
        if self.p_yaw_ki != other.p_yaw_ki:
            return False
        if self.p_yaw_kd != other.p_yaw_kd:
            return False
        if self.p_yaw_t_lim != other.p_yaw_t_lim:
            return False
        if self.data_valid != other.data_valid:
            return False
        if self.timestamp != other.timestamp:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def robust_mode(self):
        """Message field 'robust_mode'."""
        return self._robust_mode

    @robust_mode.setter
    def robust_mode(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'robust_mode' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'robust_mode' field must be an unsigned integer in [0, 255]"
        self._robust_mode = value

    @builtins.property
    def s_x_k1(self):
        """Message field 's_x_k1'."""
        return self._s_x_k1

    @s_x_k1.setter
    def s_x_k1(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_x_k1' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_x_k1' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_x_k1 = value

    @builtins.property
    def s_x_k2(self):
        """Message field 's_x_k2'."""
        return self._s_x_k2

    @s_x_k2.setter
    def s_x_k2(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_x_k2' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_x_k2' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_x_k2 = value

    @builtins.property
    def s_x_f_lim(self):
        """Message field 's_x_f_lim'."""
        return self._s_x_f_lim

    @s_x_f_lim.setter
    def s_x_f_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_x_f_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_x_f_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_x_f_lim = value

    @builtins.property
    def s_y_k1(self):
        """Message field 's_y_k1'."""
        return self._s_y_k1

    @s_y_k1.setter
    def s_y_k1(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_y_k1' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_y_k1' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_y_k1 = value

    @builtins.property
    def s_y_k2(self):
        """Message field 's_y_k2'."""
        return self._s_y_k2

    @s_y_k2.setter
    def s_y_k2(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_y_k2' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_y_k2' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_y_k2 = value

    @builtins.property
    def s_y_f_lim(self):
        """Message field 's_y_f_lim'."""
        return self._s_y_f_lim

    @s_y_f_lim.setter
    def s_y_f_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_y_f_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_y_f_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_y_f_lim = value

    @builtins.property
    def s_z_k1(self):
        """Message field 's_z_k1'."""
        return self._s_z_k1

    @s_z_k1.setter
    def s_z_k1(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_z_k1' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_z_k1' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_z_k1 = value

    @builtins.property
    def s_z_k2(self):
        """Message field 's_z_k2'."""
        return self._s_z_k2

    @s_z_k2.setter
    def s_z_k2(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_z_k2' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_z_k2' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_z_k2 = value

    @builtins.property
    def s_z_f_lim(self):
        """Message field 's_z_f_lim'."""
        return self._s_z_f_lim

    @s_z_f_lim.setter
    def s_z_f_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_z_f_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_z_f_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_z_f_lim = value

    @builtins.property
    def s_roll_k1(self):
        """Message field 's_roll_k1'."""
        return self._s_roll_k1

    @s_roll_k1.setter
    def s_roll_k1(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_roll_k1' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_roll_k1' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_roll_k1 = value

    @builtins.property
    def s_roll_k2(self):
        """Message field 's_roll_k2'."""
        return self._s_roll_k2

    @s_roll_k2.setter
    def s_roll_k2(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_roll_k2' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_roll_k2' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_roll_k2 = value

    @builtins.property
    def s_roll_t_lim(self):
        """Message field 's_roll_t_lim'."""
        return self._s_roll_t_lim

    @s_roll_t_lim.setter
    def s_roll_t_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_roll_t_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_roll_t_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_roll_t_lim = value

    @builtins.property
    def s_pitch_k1(self):
        """Message field 's_pitch_k1'."""
        return self._s_pitch_k1

    @s_pitch_k1.setter
    def s_pitch_k1(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_pitch_k1' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_pitch_k1' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_pitch_k1 = value

    @builtins.property
    def s_pitch_k2(self):
        """Message field 's_pitch_k2'."""
        return self._s_pitch_k2

    @s_pitch_k2.setter
    def s_pitch_k2(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_pitch_k2' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_pitch_k2' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_pitch_k2 = value

    @builtins.property
    def s_pitch_t_lim(self):
        """Message field 's_pitch_t_lim'."""
        return self._s_pitch_t_lim

    @s_pitch_t_lim.setter
    def s_pitch_t_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_pitch_t_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_pitch_t_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_pitch_t_lim = value

    @builtins.property
    def s_yaw_k1(self):
        """Message field 's_yaw_k1'."""
        return self._s_yaw_k1

    @s_yaw_k1.setter
    def s_yaw_k1(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_yaw_k1' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_yaw_k1' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_yaw_k1 = value

    @builtins.property
    def s_yaw_k2(self):
        """Message field 's_yaw_k2'."""
        return self._s_yaw_k2

    @s_yaw_k2.setter
    def s_yaw_k2(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_yaw_k2' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_yaw_k2' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_yaw_k2 = value

    @builtins.property
    def s_yaw_t_lim(self):
        """Message field 's_yaw_t_lim'."""
        return self._s_yaw_t_lim

    @s_yaw_t_lim.setter
    def s_yaw_t_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 's_yaw_t_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 's_yaw_t_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._s_yaw_t_lim = value

    @builtins.property
    def p_x_kp(self):
        """Message field 'p_x_kp'."""
        return self._p_x_kp

    @p_x_kp.setter
    def p_x_kp(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_x_kp' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_x_kp' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_x_kp = value

    @builtins.property
    def p_x_ki(self):
        """Message field 'p_x_ki'."""
        return self._p_x_ki

    @p_x_ki.setter
    def p_x_ki(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_x_ki' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_x_ki' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_x_ki = value

    @builtins.property
    def p_x_kd(self):
        """Message field 'p_x_kd'."""
        return self._p_x_kd

    @p_x_kd.setter
    def p_x_kd(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_x_kd' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_x_kd' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_x_kd = value

    @builtins.property
    def p_x_f_lim(self):
        """Message field 'p_x_f_lim'."""
        return self._p_x_f_lim

    @p_x_f_lim.setter
    def p_x_f_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_x_f_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_x_f_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_x_f_lim = value

    @builtins.property
    def p_y_kp(self):
        """Message field 'p_y_kp'."""
        return self._p_y_kp

    @p_y_kp.setter
    def p_y_kp(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_y_kp' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_y_kp' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_y_kp = value

    @builtins.property
    def p_y_ki(self):
        """Message field 'p_y_ki'."""
        return self._p_y_ki

    @p_y_ki.setter
    def p_y_ki(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_y_ki' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_y_ki' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_y_ki = value

    @builtins.property
    def p_y_kd(self):
        """Message field 'p_y_kd'."""
        return self._p_y_kd

    @p_y_kd.setter
    def p_y_kd(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_y_kd' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_y_kd' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_y_kd = value

    @builtins.property
    def p_y_f_lim(self):
        """Message field 'p_y_f_lim'."""
        return self._p_y_f_lim

    @p_y_f_lim.setter
    def p_y_f_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_y_f_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_y_f_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_y_f_lim = value

    @builtins.property
    def p_z_kp(self):
        """Message field 'p_z_kp'."""
        return self._p_z_kp

    @p_z_kp.setter
    def p_z_kp(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_z_kp' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_z_kp' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_z_kp = value

    @builtins.property
    def p_z_ki(self):
        """Message field 'p_z_ki'."""
        return self._p_z_ki

    @p_z_ki.setter
    def p_z_ki(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_z_ki' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_z_ki' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_z_ki = value

    @builtins.property
    def p_z_kd(self):
        """Message field 'p_z_kd'."""
        return self._p_z_kd

    @p_z_kd.setter
    def p_z_kd(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_z_kd' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_z_kd' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_z_kd = value

    @builtins.property
    def p_z_f_lim(self):
        """Message field 'p_z_f_lim'."""
        return self._p_z_f_lim

    @p_z_f_lim.setter
    def p_z_f_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_z_f_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_z_f_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_z_f_lim = value

    @builtins.property
    def p_roll_kp(self):
        """Message field 'p_roll_kp'."""
        return self._p_roll_kp

    @p_roll_kp.setter
    def p_roll_kp(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_roll_kp' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_roll_kp' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_roll_kp = value

    @builtins.property
    def p_roll_ki(self):
        """Message field 'p_roll_ki'."""
        return self._p_roll_ki

    @p_roll_ki.setter
    def p_roll_ki(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_roll_ki' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_roll_ki' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_roll_ki = value

    @builtins.property
    def p_roll_kd(self):
        """Message field 'p_roll_kd'."""
        return self._p_roll_kd

    @p_roll_kd.setter
    def p_roll_kd(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_roll_kd' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_roll_kd' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_roll_kd = value

    @builtins.property
    def p_roll_t_lim(self):
        """Message field 'p_roll_t_lim'."""
        return self._p_roll_t_lim

    @p_roll_t_lim.setter
    def p_roll_t_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_roll_t_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_roll_t_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_roll_t_lim = value

    @builtins.property
    def p_pitch_kp(self):
        """Message field 'p_pitch_kp'."""
        return self._p_pitch_kp

    @p_pitch_kp.setter
    def p_pitch_kp(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_pitch_kp' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_pitch_kp' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_pitch_kp = value

    @builtins.property
    def p_pitch_ki(self):
        """Message field 'p_pitch_ki'."""
        return self._p_pitch_ki

    @p_pitch_ki.setter
    def p_pitch_ki(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_pitch_ki' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_pitch_ki' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_pitch_ki = value

    @builtins.property
    def p_pitch_kd(self):
        """Message field 'p_pitch_kd'."""
        return self._p_pitch_kd

    @p_pitch_kd.setter
    def p_pitch_kd(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_pitch_kd' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_pitch_kd' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_pitch_kd = value

    @builtins.property
    def p_pitch_t_lim(self):
        """Message field 'p_pitch_t_lim'."""
        return self._p_pitch_t_lim

    @p_pitch_t_lim.setter
    def p_pitch_t_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_pitch_t_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_pitch_t_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_pitch_t_lim = value

    @builtins.property
    def p_yaw_kp(self):
        """Message field 'p_yaw_kp'."""
        return self._p_yaw_kp

    @p_yaw_kp.setter
    def p_yaw_kp(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_yaw_kp' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_yaw_kp' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_yaw_kp = value

    @builtins.property
    def p_yaw_ki(self):
        """Message field 'p_yaw_ki'."""
        return self._p_yaw_ki

    @p_yaw_ki.setter
    def p_yaw_ki(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_yaw_ki' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_yaw_ki' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_yaw_ki = value

    @builtins.property
    def p_yaw_kd(self):
        """Message field 'p_yaw_kd'."""
        return self._p_yaw_kd

    @p_yaw_kd.setter
    def p_yaw_kd(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_yaw_kd' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_yaw_kd' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_yaw_kd = value

    @builtins.property
    def p_yaw_t_lim(self):
        """Message field 'p_yaw_t_lim'."""
        return self._p_yaw_t_lim

    @p_yaw_t_lim.setter
    def p_yaw_t_lim(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'p_yaw_t_lim' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'p_yaw_t_lim' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._p_yaw_t_lim = value

    @builtins.property
    def data_valid(self):
        """Message field 'data_valid'."""
        return self._data_valid

    @data_valid.setter
    def data_valid(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'data_valid' field must be of type 'bool'"
        self._data_valid = value

    @builtins.property
    def timestamp(self):
        """Message field 'timestamp'."""
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'timestamp' field must be a sub message of type 'Time'"
        self._timestamp = value
