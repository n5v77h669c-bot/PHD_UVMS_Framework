// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__struct.h"
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool builtin_interfaces__msg__time__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * builtin_interfaces__msg__time__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool phd_master_slave_interfaces__msg__master_machine_ui__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[67];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("phd_master_slave_interfaces.msg._master_machine_ui.MasterMachineUI", full_classname_dest, 66) == 0);
  }
  phd_master_slave_interfaces__msg__MasterMachineUI * ros_message = _ros_message;
  {  // control_mode
    PyObject * field = PyObject_GetAttrString(_pymsg, "control_mode");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->control_mode = (int32_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_lfu
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_lfu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_lfu = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_lfd
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_lfd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_lfd = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_rfu
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_rfu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_rfu = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_rfd
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_rfd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_rfd = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_lbu
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_lbu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_lbu = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_lbd
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_lbd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_lbd = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_rbu
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_rbu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_rbu = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // manual_rbd
    PyObject * field = PyObject_GetAttrString(_pymsg, "manual_rbd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->manual_rbd = (int8_t)PyLong_AsLong(field);
    Py_DECREF(field);
  }
  {  // auto_x_velocity
    PyObject * field = PyObject_GetAttrString(_pymsg, "auto_x_velocity");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->auto_x_velocity = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // auto_y_velocity
    PyObject * field = PyObject_GetAttrString(_pymsg, "auto_y_velocity");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->auto_y_velocity = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // auto_yaw
    PyObject * field = PyObject_GetAttrString(_pymsg, "auto_yaw");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->auto_yaw = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // auto_depth
    PyObject * field = PyObject_GetAttrString(_pymsg, "auto_depth");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->auto_depth = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // auto_x_distance
    PyObject * field = PyObject_GetAttrString(_pymsg, "auto_x_distance");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->auto_x_distance = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // auto_y_distance
    PyObject * field = PyObject_GetAttrString(_pymsg, "auto_y_distance");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->auto_y_distance = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // protect_depth
    PyObject * field = PyObject_GetAttrString(_pymsg, "protect_depth");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->protect_depth = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // protect_height
    PyObject * field = PyObject_GetAttrString(_pymsg, "protect_height");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->protect_height = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // protect_time
    PyObject * field = PyObject_GetAttrString(_pymsg, "protect_time");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->protect_time = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // upper_computer_timer
    PyObject * field = PyObject_GetAttrString(_pymsg, "upper_computer_timer");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->upper_computer_timer = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // lower_machine_timer
    PyObject * field = PyObject_GetAttrString(_pymsg, "lower_machine_timer");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->lower_machine_timer = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // timestamp
    PyObject * field = PyObject_GetAttrString(_pymsg, "timestamp");
    if (!field) {
      return false;
    }
    if (!builtin_interfaces__msg__time__convert_from_py(field, &ros_message->timestamp)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }
  {  // data_valid
    PyObject * field = PyObject_GetAttrString(_pymsg, "data_valid");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->data_valid = (Py_True == field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * phd_master_slave_interfaces__msg__master_machine_ui__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of MasterMachineUI */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("phd_master_slave_interfaces.msg._master_machine_ui");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "MasterMachineUI");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  phd_master_slave_interfaces__msg__MasterMachineUI * ros_message = (phd_master_slave_interfaces__msg__MasterMachineUI *)raw_ros_message;
  {  // control_mode
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->control_mode);
    {
      int rc = PyObject_SetAttrString(_pymessage, "control_mode", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_lfu
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_lfu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_lfu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_lfd
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_lfd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_lfd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_rfu
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_rfu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_rfu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_rfd
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_rfd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_rfd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_lbu
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_lbu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_lbu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_lbd
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_lbd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_lbd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_rbu
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_rbu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_rbu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // manual_rbd
    PyObject * field = NULL;
    field = PyLong_FromLong(ros_message->manual_rbd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "manual_rbd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // auto_x_velocity
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->auto_x_velocity);
    {
      int rc = PyObject_SetAttrString(_pymessage, "auto_x_velocity", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // auto_y_velocity
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->auto_y_velocity);
    {
      int rc = PyObject_SetAttrString(_pymessage, "auto_y_velocity", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // auto_yaw
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->auto_yaw);
    {
      int rc = PyObject_SetAttrString(_pymessage, "auto_yaw", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // auto_depth
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->auto_depth);
    {
      int rc = PyObject_SetAttrString(_pymessage, "auto_depth", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // auto_x_distance
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->auto_x_distance);
    {
      int rc = PyObject_SetAttrString(_pymessage, "auto_x_distance", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // auto_y_distance
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->auto_y_distance);
    {
      int rc = PyObject_SetAttrString(_pymessage, "auto_y_distance", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // protect_depth
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->protect_depth);
    {
      int rc = PyObject_SetAttrString(_pymessage, "protect_depth", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // protect_height
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->protect_height);
    {
      int rc = PyObject_SetAttrString(_pymessage, "protect_height", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // protect_time
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->protect_time);
    {
      int rc = PyObject_SetAttrString(_pymessage, "protect_time", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // upper_computer_timer
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->upper_computer_timer);
    {
      int rc = PyObject_SetAttrString(_pymessage, "upper_computer_timer", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // lower_machine_timer
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->lower_machine_timer);
    {
      int rc = PyObject_SetAttrString(_pymessage, "lower_machine_timer", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // timestamp
    PyObject * field = NULL;
    field = builtin_interfaces__msg__time__convert_to_py(&ros_message->timestamp);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "timestamp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // data_valid
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->data_valid ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "data_valid", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
