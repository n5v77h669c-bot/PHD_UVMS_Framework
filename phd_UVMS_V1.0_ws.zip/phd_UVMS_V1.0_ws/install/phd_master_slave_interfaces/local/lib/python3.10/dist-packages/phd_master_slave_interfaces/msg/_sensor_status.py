# generated from rosidl_generator_py/resource/_idl.py.em
# with input from phd_master_slave_interfaces:msg/SensorStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SensorStatus(type):
    """Metaclass of message 'SensorStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('phd_master_slave_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'phd_master_slave_interfaces.msg.SensorStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__sensor_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__sensor_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__sensor_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__sensor_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__sensor_status

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SensorStatus(metaclass=Metaclass_SensorStatus):
    """Message class 'SensorStatus'."""

    __slots__ = [
        '_dvl_set_status',
        '_light_set_status',
        '_front_sonar_set_status',
        '_scanning_sonar_set_status',
        '_dvl_cur_status',
        '_light_cur_status',
        '_front_sonar_cur_status',
        '_scanning_sonar_cur_status',
        '_water_leak_status',
        '_data_valid',
        '_timestamp',
    ]

    _fields_and_field_types = {
        'dvl_set_status': 'uint8',
        'light_set_status': 'uint8',
        'front_sonar_set_status': 'uint8',
        'scanning_sonar_set_status': 'uint8',
        'dvl_cur_status': 'uint8',
        'light_cur_status': 'uint8',
        'front_sonar_cur_status': 'uint8',
        'scanning_sonar_cur_status': 'uint8',
        'water_leak_status': 'uint8',
        'data_valid': 'boolean',
        'timestamp': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.dvl_set_status = kwargs.get('dvl_set_status', int())
        self.light_set_status = kwargs.get('light_set_status', int())
        self.front_sonar_set_status = kwargs.get('front_sonar_set_status', int())
        self.scanning_sonar_set_status = kwargs.get('scanning_sonar_set_status', int())
        self.dvl_cur_status = kwargs.get('dvl_cur_status', int())
        self.light_cur_status = kwargs.get('light_cur_status', int())
        self.front_sonar_cur_status = kwargs.get('front_sonar_cur_status', int())
        self.scanning_sonar_cur_status = kwargs.get('scanning_sonar_cur_status', int())
        self.water_leak_status = kwargs.get('water_leak_status', int())
        self.data_valid = kwargs.get('data_valid', bool())
        from builtin_interfaces.msg import Time
        self.timestamp = kwargs.get('timestamp', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.dvl_set_status != other.dvl_set_status:
            return False
        if self.light_set_status != other.light_set_status:
            return False
        if self.front_sonar_set_status != other.front_sonar_set_status:
            return False
        if self.scanning_sonar_set_status != other.scanning_sonar_set_status:
            return False
        if self.dvl_cur_status != other.dvl_cur_status:
            return False
        if self.light_cur_status != other.light_cur_status:
            return False
        if self.front_sonar_cur_status != other.front_sonar_cur_status:
            return False
        if self.scanning_sonar_cur_status != other.scanning_sonar_cur_status:
            return False
        if self.water_leak_status != other.water_leak_status:
            return False
        if self.data_valid != other.data_valid:
            return False
        if self.timestamp != other.timestamp:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def dvl_set_status(self):
        """Message field 'dvl_set_status'."""
        return self._dvl_set_status

    @dvl_set_status.setter
    def dvl_set_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'dvl_set_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'dvl_set_status' field must be an unsigned integer in [0, 255]"
        self._dvl_set_status = value

    @builtins.property
    def light_set_status(self):
        """Message field 'light_set_status'."""
        return self._light_set_status

    @light_set_status.setter
    def light_set_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'light_set_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'light_set_status' field must be an unsigned integer in [0, 255]"
        self._light_set_status = value

    @builtins.property
    def front_sonar_set_status(self):
        """Message field 'front_sonar_set_status'."""
        return self._front_sonar_set_status

    @front_sonar_set_status.setter
    def front_sonar_set_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'front_sonar_set_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'front_sonar_set_status' field must be an unsigned integer in [0, 255]"
        self._front_sonar_set_status = value

    @builtins.property
    def scanning_sonar_set_status(self):
        """Message field 'scanning_sonar_set_status'."""
        return self._scanning_sonar_set_status

    @scanning_sonar_set_status.setter
    def scanning_sonar_set_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'scanning_sonar_set_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'scanning_sonar_set_status' field must be an unsigned integer in [0, 255]"
        self._scanning_sonar_set_status = value

    @builtins.property
    def dvl_cur_status(self):
        """Message field 'dvl_cur_status'."""
        return self._dvl_cur_status

    @dvl_cur_status.setter
    def dvl_cur_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'dvl_cur_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'dvl_cur_status' field must be an unsigned integer in [0, 255]"
        self._dvl_cur_status = value

    @builtins.property
    def light_cur_status(self):
        """Message field 'light_cur_status'."""
        return self._light_cur_status

    @light_cur_status.setter
    def light_cur_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'light_cur_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'light_cur_status' field must be an unsigned integer in [0, 255]"
        self._light_cur_status = value

    @builtins.property
    def front_sonar_cur_status(self):
        """Message field 'front_sonar_cur_status'."""
        return self._front_sonar_cur_status

    @front_sonar_cur_status.setter
    def front_sonar_cur_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'front_sonar_cur_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'front_sonar_cur_status' field must be an unsigned integer in [0, 255]"
        self._front_sonar_cur_status = value

    @builtins.property
    def scanning_sonar_cur_status(self):
        """Message field 'scanning_sonar_cur_status'."""
        return self._scanning_sonar_cur_status

    @scanning_sonar_cur_status.setter
    def scanning_sonar_cur_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'scanning_sonar_cur_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'scanning_sonar_cur_status' field must be an unsigned integer in [0, 255]"
        self._scanning_sonar_cur_status = value

    @builtins.property
    def water_leak_status(self):
        """Message field 'water_leak_status'."""
        return self._water_leak_status

    @water_leak_status.setter
    def water_leak_status(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'water_leak_status' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'water_leak_status' field must be an unsigned integer in [0, 255]"
        self._water_leak_status = value

    @builtins.property
    def data_valid(self):
        """Message field 'data_valid'."""
        return self._data_valid

    @data_valid.setter
    def data_valid(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'data_valid' field must be of type 'bool'"
        self._data_valid = value

    @builtins.property
    def timestamp(self):
        """Message field 'timestamp'."""
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'timestamp' field must be a sub message of type 'Time'"
        self._timestamp = value
