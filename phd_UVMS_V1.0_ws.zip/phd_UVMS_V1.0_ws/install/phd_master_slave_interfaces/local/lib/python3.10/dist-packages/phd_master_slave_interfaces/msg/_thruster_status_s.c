// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "phd_master_slave_interfaces/msg/detail/thruster_status__struct.h"
#include "phd_master_slave_interfaces/msg/detail/thruster_status__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool builtin_interfaces__msg__time__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * builtin_interfaces__msg__time__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool phd_master_slave_interfaces__msg__thruster_status__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[64];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("phd_master_slave_interfaces.msg._thruster_status.ThrusterStatus", full_classname_dest, 63) == 0);
  }
  phd_master_slave_interfaces__msg__ThrusterStatus * ros_message = _ros_message;
  {  // timestamp
    PyObject * field = PyObject_GetAttrString(_pymsg, "timestamp");
    if (!field) {
      return false;
    }
    if (!builtin_interfaces__msg__time__convert_from_py(field, &ros_message->timestamp)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }
  {  // set_power_lfu
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_lfu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_lfu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // set_power_lfd
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_lfd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_lfd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // set_power_rfu
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_rfu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_rfu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // set_power_rfd
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_rfd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_rfd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // set_power_lbu
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_lbu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_lbu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // set_power_lbd
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_lbd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_lbd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // set_power_rbu
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_rbu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_rbu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // set_power_rbd
    PyObject * field = PyObject_GetAttrString(_pymsg, "set_power_rbd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->set_power_rbd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_lfu
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_lfu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_lfu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_lfd
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_lfd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_lfd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_rfu
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_rfu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_rfu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_rfd
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_rfd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_rfd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_lbu
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_lbu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_lbu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_lbd
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_lbd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_lbd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_rbu
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_rbu");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_rbu = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // actual_power_rbd
    PyObject * field = PyObject_GetAttrString(_pymsg, "actual_power_rbd");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->actual_power_rbd = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // data_valid
    PyObject * field = PyObject_GetAttrString(_pymsg, "data_valid");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->data_valid = (Py_True == field);
    Py_DECREF(field);
  }
  {  // temperature
    PyObject * field = PyObject_GetAttrString(_pymsg, "temperature");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->temperature = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * phd_master_slave_interfaces__msg__thruster_status__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ThrusterStatus */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("phd_master_slave_interfaces.msg._thruster_status");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ThrusterStatus");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  phd_master_slave_interfaces__msg__ThrusterStatus * ros_message = (phd_master_slave_interfaces__msg__ThrusterStatus *)raw_ros_message;
  {  // timestamp
    PyObject * field = NULL;
    field = builtin_interfaces__msg__time__convert_to_py(&ros_message->timestamp);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "timestamp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_lfu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_lfu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_lfu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_lfd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_lfd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_lfd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_rfu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_rfu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_rfu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_rfd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_rfd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_rfd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_lbu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_lbu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_lbu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_lbd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_lbd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_lbd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_rbu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_rbu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_rbu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // set_power_rbd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->set_power_rbd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "set_power_rbd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_lfu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_lfu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_lfu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_lfd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_lfd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_lfd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_rfu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_rfu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_rfu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_rfd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_rfd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_rfd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_lbu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_lbu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_lbu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_lbd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_lbd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_lbd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_rbu
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_rbu);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_rbu", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // actual_power_rbd
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->actual_power_rbd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "actual_power_rbd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // data_valid
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->data_valid ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "data_valid", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // temperature
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->temperature);
    {
      int rc = PyObject_SetAttrString(_pymessage, "temperature", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
