// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from phd_master_slave_interfaces:msg/SensorStatus.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "phd_master_slave_interfaces/msg/detail/sensor_status__struct.h"
#include "phd_master_slave_interfaces/msg/detail/sensor_status__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool builtin_interfaces__msg__time__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * builtin_interfaces__msg__time__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool phd_master_slave_interfaces__msg__sensor_status__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[60];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("phd_master_slave_interfaces.msg._sensor_status.SensorStatus", full_classname_dest, 59) == 0);
  }
  phd_master_slave_interfaces__msg__SensorStatus * ros_message = _ros_message;
  {  // dvl_set_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "dvl_set_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->dvl_set_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // light_set_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "light_set_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->light_set_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // front_sonar_set_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "front_sonar_set_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->front_sonar_set_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // scanning_sonar_set_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "scanning_sonar_set_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->scanning_sonar_set_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // dvl_cur_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "dvl_cur_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->dvl_cur_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // light_cur_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "light_cur_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->light_cur_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // front_sonar_cur_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "front_sonar_cur_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->front_sonar_cur_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // scanning_sonar_cur_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "scanning_sonar_cur_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->scanning_sonar_cur_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // water_leak_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "water_leak_status");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->water_leak_status = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // data_valid
    PyObject * field = PyObject_GetAttrString(_pymsg, "data_valid");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->data_valid = (Py_True == field);
    Py_DECREF(field);
  }
  {  // timestamp
    PyObject * field = PyObject_GetAttrString(_pymsg, "timestamp");
    if (!field) {
      return false;
    }
    if (!builtin_interfaces__msg__time__convert_from_py(field, &ros_message->timestamp)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * phd_master_slave_interfaces__msg__sensor_status__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of SensorStatus */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("phd_master_slave_interfaces.msg._sensor_status");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "SensorStatus");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  phd_master_slave_interfaces__msg__SensorStatus * ros_message = (phd_master_slave_interfaces__msg__SensorStatus *)raw_ros_message;
  {  // dvl_set_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->dvl_set_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "dvl_set_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // light_set_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->light_set_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "light_set_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // front_sonar_set_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->front_sonar_set_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "front_sonar_set_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // scanning_sonar_set_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->scanning_sonar_set_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "scanning_sonar_set_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // dvl_cur_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->dvl_cur_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "dvl_cur_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // light_cur_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->light_cur_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "light_cur_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // front_sonar_cur_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->front_sonar_cur_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "front_sonar_cur_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // scanning_sonar_cur_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->scanning_sonar_cur_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "scanning_sonar_cur_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // water_leak_status
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->water_leak_status);
    {
      int rc = PyObject_SetAttrString(_pymessage, "water_leak_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // data_valid
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->data_valid ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "data_valid", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // timestamp
    PyObject * field = NULL;
    field = builtin_interfaces__msg__time__convert_to_py(&ros_message->timestamp);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "timestamp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
