// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__struct.h"
#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool builtin_interfaces__msg__time__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * builtin_interfaces__msg__time__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool phd_master_slave_interfaces__msg__robust_ctrl_para__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[65];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("phd_master_slave_interfaces.msg._robust_ctrl_para.RobustCtrlPara", full_classname_dest, 64) == 0);
  }
  phd_master_slave_interfaces__msg__RobustCtrlPara * ros_message = _ros_message;
  {  // robust_mode
    PyObject * field = PyObject_GetAttrString(_pymsg, "robust_mode");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->robust_mode = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // s_x_k1
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_x_k1");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_x_k1 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_x_k2
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_x_k2");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_x_k2 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_x_f_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_x_f_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_x_f_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_y_k1
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_y_k1");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_y_k1 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_y_k2
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_y_k2");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_y_k2 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_y_f_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_y_f_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_y_f_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_z_k1
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_z_k1");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_z_k1 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_z_k2
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_z_k2");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_z_k2 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_z_f_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_z_f_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_z_f_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_roll_k1
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_roll_k1");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_roll_k1 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_roll_k2
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_roll_k2");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_roll_k2 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_roll_t_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_roll_t_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_roll_t_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_pitch_k1
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_pitch_k1");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_pitch_k1 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_pitch_k2
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_pitch_k2");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_pitch_k2 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_pitch_t_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_pitch_t_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_pitch_t_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_yaw_k1
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_yaw_k1");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_yaw_k1 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_yaw_k2
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_yaw_k2");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_yaw_k2 = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // s_yaw_t_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "s_yaw_t_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->s_yaw_t_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_x_kp
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_x_kp");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_x_kp = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_x_ki
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_x_ki");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_x_ki = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_x_kd
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_x_kd");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_x_kd = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_x_f_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_x_f_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_x_f_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_y_kp
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_y_kp");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_y_kp = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_y_ki
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_y_ki");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_y_ki = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_y_kd
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_y_kd");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_y_kd = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_y_f_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_y_f_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_y_f_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_z_kp
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_z_kp");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_z_kp = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_z_ki
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_z_ki");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_z_ki = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_z_kd
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_z_kd");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_z_kd = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_z_f_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_z_f_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_z_f_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_roll_kp
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_roll_kp");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_roll_kp = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_roll_ki
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_roll_ki");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_roll_ki = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_roll_kd
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_roll_kd");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_roll_kd = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_roll_t_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_roll_t_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_roll_t_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_pitch_kp
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_pitch_kp");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_pitch_kp = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_pitch_ki
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_pitch_ki");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_pitch_ki = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_pitch_kd
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_pitch_kd");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_pitch_kd = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_pitch_t_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_pitch_t_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_pitch_t_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_yaw_kp
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_yaw_kp");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_yaw_kp = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_yaw_ki
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_yaw_ki");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_yaw_ki = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_yaw_kd
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_yaw_kd");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_yaw_kd = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // p_yaw_t_lim
    PyObject * field = PyObject_GetAttrString(_pymsg, "p_yaw_t_lim");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->p_yaw_t_lim = (float)PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // data_valid
    PyObject * field = PyObject_GetAttrString(_pymsg, "data_valid");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->data_valid = (Py_True == field);
    Py_DECREF(field);
  }
  {  // timestamp
    PyObject * field = PyObject_GetAttrString(_pymsg, "timestamp");
    if (!field) {
      return false;
    }
    if (!builtin_interfaces__msg__time__convert_from_py(field, &ros_message->timestamp)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * phd_master_slave_interfaces__msg__robust_ctrl_para__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of RobustCtrlPara */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("phd_master_slave_interfaces.msg._robust_ctrl_para");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "RobustCtrlPara");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  phd_master_slave_interfaces__msg__RobustCtrlPara * ros_message = (phd_master_slave_interfaces__msg__RobustCtrlPara *)raw_ros_message;
  {  // robust_mode
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->robust_mode);
    {
      int rc = PyObject_SetAttrString(_pymessage, "robust_mode", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_x_k1
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_x_k1);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_x_k1", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_x_k2
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_x_k2);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_x_k2", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_x_f_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_x_f_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_x_f_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_y_k1
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_y_k1);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_y_k1", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_y_k2
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_y_k2);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_y_k2", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_y_f_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_y_f_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_y_f_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_z_k1
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_z_k1);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_z_k1", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_z_k2
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_z_k2);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_z_k2", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_z_f_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_z_f_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_z_f_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_roll_k1
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_roll_k1);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_roll_k1", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_roll_k2
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_roll_k2);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_roll_k2", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_roll_t_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_roll_t_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_roll_t_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_pitch_k1
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_pitch_k1);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_pitch_k1", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_pitch_k2
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_pitch_k2);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_pitch_k2", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_pitch_t_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_pitch_t_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_pitch_t_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_yaw_k1
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_yaw_k1);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_yaw_k1", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_yaw_k2
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_yaw_k2);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_yaw_k2", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // s_yaw_t_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->s_yaw_t_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "s_yaw_t_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_x_kp
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_x_kp);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_x_kp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_x_ki
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_x_ki);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_x_ki", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_x_kd
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_x_kd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_x_kd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_x_f_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_x_f_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_x_f_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_y_kp
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_y_kp);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_y_kp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_y_ki
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_y_ki);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_y_ki", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_y_kd
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_y_kd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_y_kd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_y_f_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_y_f_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_y_f_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_z_kp
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_z_kp);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_z_kp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_z_ki
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_z_ki);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_z_ki", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_z_kd
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_z_kd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_z_kd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_z_f_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_z_f_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_z_f_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_roll_kp
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_roll_kp);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_roll_kp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_roll_ki
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_roll_ki);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_roll_ki", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_roll_kd
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_roll_kd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_roll_kd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_roll_t_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_roll_t_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_roll_t_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_pitch_kp
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_pitch_kp);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_pitch_kp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_pitch_ki
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_pitch_ki);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_pitch_ki", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_pitch_kd
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_pitch_kd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_pitch_kd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_pitch_t_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_pitch_t_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_pitch_t_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_yaw_kp
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_yaw_kp);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_yaw_kp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_yaw_ki
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_yaw_ki);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_yaw_ki", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_yaw_kd
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_yaw_kd);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_yaw_kd", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // p_yaw_t_lim
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->p_yaw_t_lim);
    {
      int rc = PyObject_SetAttrString(_pymessage, "p_yaw_t_lim", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // data_valid
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->data_valid ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "data_valid", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // timestamp
    PyObject * field = NULL;
    field = builtin_interfaces__msg__time__convert_to_py(&ros_message->timestamp);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "timestamp", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
