# generated from rosidl_generator_py/resource/_idl.py.em
# with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_MasterMachineUI(type):
    """Metaclass of message 'MasterMachineUI'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('phd_master_slave_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'phd_master_slave_interfaces.msg.MasterMachineUI')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__master_machine_ui
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__master_machine_ui
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__master_machine_ui
            cls._TYPE_SUPPORT = module.type_support_msg__msg__master_machine_ui
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__master_machine_ui

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class MasterMachineUI(metaclass=Metaclass_MasterMachineUI):
    """Message class 'MasterMachineUI'."""

    __slots__ = [
        '_control_mode',
        '_manual_lfu',
        '_manual_lfd',
        '_manual_rfu',
        '_manual_rfd',
        '_manual_lbu',
        '_manual_lbd',
        '_manual_rbu',
        '_manual_rbd',
        '_auto_x_velocity',
        '_auto_y_velocity',
        '_auto_yaw',
        '_auto_depth',
        '_auto_x_distance',
        '_auto_y_distance',
        '_protect_depth',
        '_protect_height',
        '_protect_time',
        '_upper_computer_timer',
        '_lower_machine_timer',
        '_timestamp',
        '_data_valid',
    ]

    _fields_and_field_types = {
        'control_mode': 'int32',
        'manual_lfu': 'int8',
        'manual_lfd': 'int8',
        'manual_rfu': 'int8',
        'manual_rfd': 'int8',
        'manual_lbu': 'int8',
        'manual_lbd': 'int8',
        'manual_rbu': 'int8',
        'manual_rbd': 'int8',
        'auto_x_velocity': 'float',
        'auto_y_velocity': 'float',
        'auto_yaw': 'float',
        'auto_depth': 'float',
        'auto_x_distance': 'float',
        'auto_y_distance': 'float',
        'protect_depth': 'float',
        'protect_height': 'float',
        'protect_time': 'float',
        'upper_computer_timer': 'float',
        'lower_machine_timer': 'float',
        'timestamp': 'builtin_interfaces/Time',
        'data_valid': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.control_mode = kwargs.get('control_mode', int())
        self.manual_lfu = kwargs.get('manual_lfu', int())
        self.manual_lfd = kwargs.get('manual_lfd', int())
        self.manual_rfu = kwargs.get('manual_rfu', int())
        self.manual_rfd = kwargs.get('manual_rfd', int())
        self.manual_lbu = kwargs.get('manual_lbu', int())
        self.manual_lbd = kwargs.get('manual_lbd', int())
        self.manual_rbu = kwargs.get('manual_rbu', int())
        self.manual_rbd = kwargs.get('manual_rbd', int())
        self.auto_x_velocity = kwargs.get('auto_x_velocity', float())
        self.auto_y_velocity = kwargs.get('auto_y_velocity', float())
        self.auto_yaw = kwargs.get('auto_yaw', float())
        self.auto_depth = kwargs.get('auto_depth', float())
        self.auto_x_distance = kwargs.get('auto_x_distance', float())
        self.auto_y_distance = kwargs.get('auto_y_distance', float())
        self.protect_depth = kwargs.get('protect_depth', float())
        self.protect_height = kwargs.get('protect_height', float())
        self.protect_time = kwargs.get('protect_time', float())
        self.upper_computer_timer = kwargs.get('upper_computer_timer', float())
        self.lower_machine_timer = kwargs.get('lower_machine_timer', float())
        from builtin_interfaces.msg import Time
        self.timestamp = kwargs.get('timestamp', Time())
        self.data_valid = kwargs.get('data_valid', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.control_mode != other.control_mode:
            return False
        if self.manual_lfu != other.manual_lfu:
            return False
        if self.manual_lfd != other.manual_lfd:
            return False
        if self.manual_rfu != other.manual_rfu:
            return False
        if self.manual_rfd != other.manual_rfd:
            return False
        if self.manual_lbu != other.manual_lbu:
            return False
        if self.manual_lbd != other.manual_lbd:
            return False
        if self.manual_rbu != other.manual_rbu:
            return False
        if self.manual_rbd != other.manual_rbd:
            return False
        if self.auto_x_velocity != other.auto_x_velocity:
            return False
        if self.auto_y_velocity != other.auto_y_velocity:
            return False
        if self.auto_yaw != other.auto_yaw:
            return False
        if self.auto_depth != other.auto_depth:
            return False
        if self.auto_x_distance != other.auto_x_distance:
            return False
        if self.auto_y_distance != other.auto_y_distance:
            return False
        if self.protect_depth != other.protect_depth:
            return False
        if self.protect_height != other.protect_height:
            return False
        if self.protect_time != other.protect_time:
            return False
        if self.upper_computer_timer != other.upper_computer_timer:
            return False
        if self.lower_machine_timer != other.lower_machine_timer:
            return False
        if self.timestamp != other.timestamp:
            return False
        if self.data_valid != other.data_valid:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def control_mode(self):
        """Message field 'control_mode'."""
        return self._control_mode

    @control_mode.setter
    def control_mode(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'control_mode' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'control_mode' field must be an integer in [-2147483648, 2147483647]"
        self._control_mode = value

    @builtins.property
    def manual_lfu(self):
        """Message field 'manual_lfu'."""
        return self._manual_lfu

    @manual_lfu.setter
    def manual_lfu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_lfu' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_lfu' field must be an integer in [-128, 127]"
        self._manual_lfu = value

    @builtins.property
    def manual_lfd(self):
        """Message field 'manual_lfd'."""
        return self._manual_lfd

    @manual_lfd.setter
    def manual_lfd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_lfd' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_lfd' field must be an integer in [-128, 127]"
        self._manual_lfd = value

    @builtins.property
    def manual_rfu(self):
        """Message field 'manual_rfu'."""
        return self._manual_rfu

    @manual_rfu.setter
    def manual_rfu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_rfu' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_rfu' field must be an integer in [-128, 127]"
        self._manual_rfu = value

    @builtins.property
    def manual_rfd(self):
        """Message field 'manual_rfd'."""
        return self._manual_rfd

    @manual_rfd.setter
    def manual_rfd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_rfd' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_rfd' field must be an integer in [-128, 127]"
        self._manual_rfd = value

    @builtins.property
    def manual_lbu(self):
        """Message field 'manual_lbu'."""
        return self._manual_lbu

    @manual_lbu.setter
    def manual_lbu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_lbu' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_lbu' field must be an integer in [-128, 127]"
        self._manual_lbu = value

    @builtins.property
    def manual_lbd(self):
        """Message field 'manual_lbd'."""
        return self._manual_lbd

    @manual_lbd.setter
    def manual_lbd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_lbd' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_lbd' field must be an integer in [-128, 127]"
        self._manual_lbd = value

    @builtins.property
    def manual_rbu(self):
        """Message field 'manual_rbu'."""
        return self._manual_rbu

    @manual_rbu.setter
    def manual_rbu(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_rbu' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_rbu' field must be an integer in [-128, 127]"
        self._manual_rbu = value

    @builtins.property
    def manual_rbd(self):
        """Message field 'manual_rbd'."""
        return self._manual_rbd

    @manual_rbd.setter
    def manual_rbd(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'manual_rbd' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'manual_rbd' field must be an integer in [-128, 127]"
        self._manual_rbd = value

    @builtins.property
    def auto_x_velocity(self):
        """Message field 'auto_x_velocity'."""
        return self._auto_x_velocity

    @auto_x_velocity.setter
    def auto_x_velocity(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'auto_x_velocity' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'auto_x_velocity' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._auto_x_velocity = value

    @builtins.property
    def auto_y_velocity(self):
        """Message field 'auto_y_velocity'."""
        return self._auto_y_velocity

    @auto_y_velocity.setter
    def auto_y_velocity(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'auto_y_velocity' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'auto_y_velocity' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._auto_y_velocity = value

    @builtins.property
    def auto_yaw(self):
        """Message field 'auto_yaw'."""
        return self._auto_yaw

    @auto_yaw.setter
    def auto_yaw(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'auto_yaw' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'auto_yaw' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._auto_yaw = value

    @builtins.property
    def auto_depth(self):
        """Message field 'auto_depth'."""
        return self._auto_depth

    @auto_depth.setter
    def auto_depth(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'auto_depth' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'auto_depth' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._auto_depth = value

    @builtins.property
    def auto_x_distance(self):
        """Message field 'auto_x_distance'."""
        return self._auto_x_distance

    @auto_x_distance.setter
    def auto_x_distance(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'auto_x_distance' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'auto_x_distance' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._auto_x_distance = value

    @builtins.property
    def auto_y_distance(self):
        """Message field 'auto_y_distance'."""
        return self._auto_y_distance

    @auto_y_distance.setter
    def auto_y_distance(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'auto_y_distance' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'auto_y_distance' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._auto_y_distance = value

    @builtins.property
    def protect_depth(self):
        """Message field 'protect_depth'."""
        return self._protect_depth

    @protect_depth.setter
    def protect_depth(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'protect_depth' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'protect_depth' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._protect_depth = value

    @builtins.property
    def protect_height(self):
        """Message field 'protect_height'."""
        return self._protect_height

    @protect_height.setter
    def protect_height(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'protect_height' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'protect_height' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._protect_height = value

    @builtins.property
    def protect_time(self):
        """Message field 'protect_time'."""
        return self._protect_time

    @protect_time.setter
    def protect_time(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'protect_time' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'protect_time' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._protect_time = value

    @builtins.property
    def upper_computer_timer(self):
        """Message field 'upper_computer_timer'."""
        return self._upper_computer_timer

    @upper_computer_timer.setter
    def upper_computer_timer(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'upper_computer_timer' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'upper_computer_timer' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._upper_computer_timer = value

    @builtins.property
    def lower_machine_timer(self):
        """Message field 'lower_machine_timer'."""
        return self._lower_machine_timer

    @lower_machine_timer.setter
    def lower_machine_timer(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'lower_machine_timer' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'lower_machine_timer' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._lower_machine_timer = value

    @builtins.property
    def timestamp(self):
        """Message field 'timestamp'."""
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'timestamp' field must be a sub message of type 'Time'"
        self._timestamp = value

    @builtins.property
    def data_valid(self):
        """Message field 'data_valid'."""
        return self._data_valid

    @data_valid.setter
    def data_valid(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'data_valid' field must be of type 'bool'"
        self._data_valid = value
