# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(phd_master_slave_interfaces_IDL_FILES "msg/MtiImu.idl;msg/Depth.idl;msg/ThrusterStatus.idl;msg/MasterMachineUI.idl;msg/SensorStatus.idl;msg/RobustCtrlPara.idl")
set(phd_master_slave_interfaces_INTERFACE_FILES "msg/MtiImu.msg;msg/Depth.msg;msg/ThrusterStatus.msg;msg/MasterMachineUI.msg;msg/SensorStatus.msg;msg/RobustCtrlPara.msg")
