# generated from rosidl_cmake/cmake/rosidl_cmake_aggregate_target-extras.cmake.in

# Create a convenience aggregate target phd_master_slave_interfaces::phd_master_slave_interfaces
# that links all generated interface targets, so downstream packages can use
# a single modern CMake target name instead of ${phd_master_slave_interfaces_TARGETS}.
if(phd_master_slave_interfaces_TARGETS AND NOT TARGET phd_master_slave_interfaces::phd_master_slave_interfaces)
  add_library(phd_master_slave_interfaces::phd_master_slave_interfaces INTERFACE IMPORTED)
  set_target_properties(phd_master_slave_interfaces::phd_master_slave_interfaces PROPERTIES
    INTERFACE_LINK_LIBRARIES "${phd_master_slave_interfaces_TARGETS}")
endif()
