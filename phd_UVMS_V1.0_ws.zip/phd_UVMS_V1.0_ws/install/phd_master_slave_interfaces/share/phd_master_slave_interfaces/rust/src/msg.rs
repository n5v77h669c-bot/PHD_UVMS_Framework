#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to phd_master_slave_interfaces__msg__MtiImu
/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MtiImu.msg

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MtiImu {
    /// ==================== 姿态数据 ====================
    /// 欧拉角 (度)
    pub roll: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pitch: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub yaw: f32,

    /// 四元数 (w, x, y, z)
    pub q0: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub q1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub q2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub q3: f32,

    /// ==================== 加速度计数据 ====================
    /// 线性加速度 (m/s²)
    pub accel_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub accel_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub accel_z: f32,

    /// ==================== 陀螺仪数据 ====================
    /// 角速度 (rad/s)
    pub gyro_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub gyro_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub gyro_z: f32,

    /// ==================== 磁力计数据 ====================
    /// 磁场强度 (任意单位)
    pub mag_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mag_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mag_z: f32,

    /// ==================== 传感器状态 ====================
    /// 温度 (°C)
    pub temp_imu: f32,

    /// ==================== 时间戳 ====================
    /// 系统时间 (秒)
    pub timestamp: builtin_interfaces::msg::Time,

    /// ==================== 数据源标记 ====================
    /// 数据来源: 0=PRDID(只有姿态), 1=PSONCMS(完整数据)
    pub data_source: u8,

    /// ==================== 数据质量 ====================
    /// 有效性标记: 0=无效, 1=有效
    pub data_valid: bool,

    /// ==================== 手动计算：积分速度 (m/s) ====================
    pub vel_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vel_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vel_z: f32,

    /// ==================== 手动计算：积分位置 (m) ====================
    pub pos_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pos_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pos_z: f32,

}



impl Default for MtiImu {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::MtiImu::default())
  }
}

impl rosidl_runtime_rs::Message for MtiImu {
  type RmwMsg = super::msg::rmw::MtiImu;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        roll: msg.roll,
        pitch: msg.pitch,
        yaw: msg.yaw,
        q0: msg.q0,
        q1: msg.q1,
        q2: msg.q2,
        q3: msg.q3,
        accel_x: msg.accel_x,
        accel_y: msg.accel_y,
        accel_z: msg.accel_z,
        gyro_x: msg.gyro_x,
        gyro_y: msg.gyro_y,
        gyro_z: msg.gyro_z,
        mag_x: msg.mag_x,
        mag_y: msg.mag_y,
        mag_z: msg.mag_z,
        temp_imu: msg.temp_imu,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.timestamp)).into_owned(),
        data_source: msg.data_source,
        data_valid: msg.data_valid,
        vel_x: msg.vel_x,
        vel_y: msg.vel_y,
        vel_z: msg.vel_z,
        pos_x: msg.pos_x,
        pos_y: msg.pos_y,
        pos_z: msg.pos_z,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      roll: msg.roll,
      pitch: msg.pitch,
      yaw: msg.yaw,
      q0: msg.q0,
      q1: msg.q1,
      q2: msg.q2,
      q3: msg.q3,
      accel_x: msg.accel_x,
      accel_y: msg.accel_y,
      accel_z: msg.accel_z,
      gyro_x: msg.gyro_x,
      gyro_y: msg.gyro_y,
      gyro_z: msg.gyro_z,
      mag_x: msg.mag_x,
      mag_y: msg.mag_y,
      mag_z: msg.mag_z,
      temp_imu: msg.temp_imu,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.timestamp)).into_owned(),
      data_source: msg.data_source,
      data_valid: msg.data_valid,
      vel_x: msg.vel_x,
      vel_y: msg.vel_y,
      vel_z: msg.vel_z,
      pos_x: msg.pos_x,
      pos_y: msg.pos_y,
      pos_z: msg.pos_z,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      roll: msg.roll,
      pitch: msg.pitch,
      yaw: msg.yaw,
      q0: msg.q0,
      q1: msg.q1,
      q2: msg.q2,
      q3: msg.q3,
      accel_x: msg.accel_x,
      accel_y: msg.accel_y,
      accel_z: msg.accel_z,
      gyro_x: msg.gyro_x,
      gyro_y: msg.gyro_y,
      gyro_z: msg.gyro_z,
      mag_x: msg.mag_x,
      mag_y: msg.mag_y,
      mag_z: msg.mag_z,
      temp_imu: msg.temp_imu,
      timestamp: builtin_interfaces::msg::Time::from_rmw_message(msg.timestamp),
      data_source: msg.data_source,
      data_valid: msg.data_valid,
      vel_x: msg.vel_x,
      vel_y: msg.vel_y,
      vel_z: msg.vel_z,
      pos_x: msg.pos_x,
      pos_y: msg.pos_y,
      pos_z: msg.pos_z,
    }
  }
}


// Corresponds to phd_master_slave_interfaces__msg__Depth
/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/Depth.msg

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Depth {
    /// ==================== 深度计数据 ====================
    /// 深度 (米)
    pub depth: f64,

    /// 温度 (°C)
    pub temp_water: f64,

    /// ==================== 时间戳 ====================
    /// 系统时间 (秒)
    pub timestamp: builtin_interfaces::msg::Time,

}



impl Default for Depth {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Depth::default())
  }
}

impl rosidl_runtime_rs::Message for Depth {
  type RmwMsg = super::msg::rmw::Depth;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        depth: msg.depth,
        temp_water: msg.temp_water,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.timestamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      depth: msg.depth,
      temp_water: msg.temp_water,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.timestamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      depth: msg.depth,
      temp_water: msg.temp_water,
      timestamp: builtin_interfaces::msg::Time::from_rmw_message(msg.timestamp),
    }
  }
}


// Corresponds to phd_master_slave_interfaces__msg__ThrusterStatus
/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/ThrusterStatus.msg
/// ==================== 推进器状态消息 ====================
/// 时间戳

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ThrusterStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp: builtin_interfaces::msg::Time,

    /// ==================== 设置功率 (0-200) ====================
    /// 0-99: 反转, 100: 停止, 101-200: 正转
    pub set_power_lfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_lfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_lbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_lbd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rbd: u8,

    /// ==================== 当前实际功率 (0-200) ====================
    pub actual_power_lfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_lfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_lbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_lbd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rbd: u8,

    /// ==================== 状态标志 ====================
    /// 数据有效性
    pub data_valid: bool,

    /// 控制器温度（可选）
    pub temperature: f32,

}



impl Default for ThrusterStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ThrusterStatus::default())
  }
}

impl rosidl_runtime_rs::Message for ThrusterStatus {
  type RmwMsg = super::msg::rmw::ThrusterStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.timestamp)).into_owned(),
        set_power_lfu: msg.set_power_lfu,
        set_power_lfd: msg.set_power_lfd,
        set_power_rfu: msg.set_power_rfu,
        set_power_rfd: msg.set_power_rfd,
        set_power_lbu: msg.set_power_lbu,
        set_power_lbd: msg.set_power_lbd,
        set_power_rbu: msg.set_power_rbu,
        set_power_rbd: msg.set_power_rbd,
        actual_power_lfu: msg.actual_power_lfu,
        actual_power_lfd: msg.actual_power_lfd,
        actual_power_rfu: msg.actual_power_rfu,
        actual_power_rfd: msg.actual_power_rfd,
        actual_power_lbu: msg.actual_power_lbu,
        actual_power_lbd: msg.actual_power_lbd,
        actual_power_rbu: msg.actual_power_rbu,
        actual_power_rbd: msg.actual_power_rbd,
        data_valid: msg.data_valid,
        temperature: msg.temperature,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.timestamp)).into_owned(),
      set_power_lfu: msg.set_power_lfu,
      set_power_lfd: msg.set_power_lfd,
      set_power_rfu: msg.set_power_rfu,
      set_power_rfd: msg.set_power_rfd,
      set_power_lbu: msg.set_power_lbu,
      set_power_lbd: msg.set_power_lbd,
      set_power_rbu: msg.set_power_rbu,
      set_power_rbd: msg.set_power_rbd,
      actual_power_lfu: msg.actual_power_lfu,
      actual_power_lfd: msg.actual_power_lfd,
      actual_power_rfu: msg.actual_power_rfu,
      actual_power_rfd: msg.actual_power_rfd,
      actual_power_lbu: msg.actual_power_lbu,
      actual_power_lbd: msg.actual_power_lbd,
      actual_power_rbu: msg.actual_power_rbu,
      actual_power_rbd: msg.actual_power_rbd,
      data_valid: msg.data_valid,
      temperature: msg.temperature,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      timestamp: builtin_interfaces::msg::Time::from_rmw_message(msg.timestamp),
      set_power_lfu: msg.set_power_lfu,
      set_power_lfd: msg.set_power_lfd,
      set_power_rfu: msg.set_power_rfu,
      set_power_rfd: msg.set_power_rfd,
      set_power_lbu: msg.set_power_lbu,
      set_power_lbd: msg.set_power_lbd,
      set_power_rbu: msg.set_power_rbu,
      set_power_rbd: msg.set_power_rbd,
      actual_power_lfu: msg.actual_power_lfu,
      actual_power_lfd: msg.actual_power_lfd,
      actual_power_rfu: msg.actual_power_rfu,
      actual_power_rfd: msg.actual_power_rfd,
      actual_power_lbu: msg.actual_power_lbu,
      actual_power_lbd: msg.actual_power_lbd,
      actual_power_rbu: msg.actual_power_rbu,
      actual_power_rbd: msg.actual_power_rbd,
      data_valid: msg.data_valid,
      temperature: msg.temperature,
    }
  }
}


// Corresponds to phd_master_slave_interfaces__msg__MasterMachineUI
/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MasterMachineUI.msg

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MasterMachineUI {
    /// ==================== 控制模式 ====================
    /// 1: 全手操模式 (manual)
    /// 2: 手柄遥控模式 (xboxcontroller)
    /// 3: 键盘遥控模式 (keyboard)
    /// 4: 自动模式 (automatic)
    pub control_mode: i32,

    /// ==================== 全手操模式推进器控制值 (-100 ~ 100) ====================
    /// -100: 最大反转, 0: 停止, 100: 最大正转
    pub manual_lfu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_lfd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rfu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rfd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_lbu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_lbd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rbu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rbd: i8,

    /// ==================== 自动模式参数 ====================
    /// 以下字段在control_mode=4时有效
    /// 纵向速度 (m/s)
    pub auto_x_velocity: f32,

    /// 横向速度 (m/s)
    pub auto_y_velocity: f32,

    /// 期望航向角 (度)
    pub auto_yaw: f32,

    /// 期望深度 (米)
    pub auto_depth: f32,

    /// 纵向距离 (米)
    pub auto_x_distance: f32,

    /// 横向距离 (米)
    pub auto_y_distance: f32,

    /// ==================== 保护参数 ====================
    /// 定深保护深度 (米)
    pub protect_depth: f32,

    /// 定高保护高度 (米)
    pub protect_height: f32,

    /// 定时保护时间 (秒)
    pub protect_time: f32,

    /// 上位机计时 (秒)
    pub upper_computer_timer: f32,

    /// 下位机计时 (秒)
    pub lower_machine_timer: f32,

    /// ==================== 时间戳 ====================
    pub timestamp: builtin_interfaces::msg::Time,

    /// ==================== 状态标志 ====================
    /// 数据有效性
    pub data_valid: bool,

}



impl Default for MasterMachineUI {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::MasterMachineUI::default())
  }
}

impl rosidl_runtime_rs::Message for MasterMachineUI {
  type RmwMsg = super::msg::rmw::MasterMachineUI;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        control_mode: msg.control_mode,
        manual_lfu: msg.manual_lfu,
        manual_lfd: msg.manual_lfd,
        manual_rfu: msg.manual_rfu,
        manual_rfd: msg.manual_rfd,
        manual_lbu: msg.manual_lbu,
        manual_lbd: msg.manual_lbd,
        manual_rbu: msg.manual_rbu,
        manual_rbd: msg.manual_rbd,
        auto_x_velocity: msg.auto_x_velocity,
        auto_y_velocity: msg.auto_y_velocity,
        auto_yaw: msg.auto_yaw,
        auto_depth: msg.auto_depth,
        auto_x_distance: msg.auto_x_distance,
        auto_y_distance: msg.auto_y_distance,
        protect_depth: msg.protect_depth,
        protect_height: msg.protect_height,
        protect_time: msg.protect_time,
        upper_computer_timer: msg.upper_computer_timer,
        lower_machine_timer: msg.lower_machine_timer,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.timestamp)).into_owned(),
        data_valid: msg.data_valid,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      control_mode: msg.control_mode,
      manual_lfu: msg.manual_lfu,
      manual_lfd: msg.manual_lfd,
      manual_rfu: msg.manual_rfu,
      manual_rfd: msg.manual_rfd,
      manual_lbu: msg.manual_lbu,
      manual_lbd: msg.manual_lbd,
      manual_rbu: msg.manual_rbu,
      manual_rbd: msg.manual_rbd,
      auto_x_velocity: msg.auto_x_velocity,
      auto_y_velocity: msg.auto_y_velocity,
      auto_yaw: msg.auto_yaw,
      auto_depth: msg.auto_depth,
      auto_x_distance: msg.auto_x_distance,
      auto_y_distance: msg.auto_y_distance,
      protect_depth: msg.protect_depth,
      protect_height: msg.protect_height,
      protect_time: msg.protect_time,
      upper_computer_timer: msg.upper_computer_timer,
      lower_machine_timer: msg.lower_machine_timer,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.timestamp)).into_owned(),
      data_valid: msg.data_valid,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      control_mode: msg.control_mode,
      manual_lfu: msg.manual_lfu,
      manual_lfd: msg.manual_lfd,
      manual_rfu: msg.manual_rfu,
      manual_rfd: msg.manual_rfd,
      manual_lbu: msg.manual_lbu,
      manual_lbd: msg.manual_lbd,
      manual_rbu: msg.manual_rbu,
      manual_rbd: msg.manual_rbd,
      auto_x_velocity: msg.auto_x_velocity,
      auto_y_velocity: msg.auto_y_velocity,
      auto_yaw: msg.auto_yaw,
      auto_depth: msg.auto_depth,
      auto_x_distance: msg.auto_x_distance,
      auto_y_distance: msg.auto_y_distance,
      protect_depth: msg.protect_depth,
      protect_height: msg.protect_height,
      protect_time: msg.protect_time,
      upper_computer_timer: msg.upper_computer_timer,
      lower_machine_timer: msg.lower_machine_timer,
      timestamp: builtin_interfaces::msg::Time::from_rmw_message(msg.timestamp),
      data_valid: msg.data_valid,
    }
  }
}


// Corresponds to phd_master_slave_interfaces__msg__SensorStatus
/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/SensorStatus.msg

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SensorStatus {
    /// ==================== 传感器开关状态消息 ====================
    /// 用于传感器开关控制和状态反馈
    /// ==================== 设置状态 (来自上位机指令) ====================
    /// 0: 关闭, 1: 开启
    pub dvl_set_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub light_set_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub front_sonar_set_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub scanning_sonar_set_status: u8,

    /// ==================== 当前状态 (从MCU读取) ====================
    /// 0: 关闭, 1: 开启
    pub dvl_cur_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub light_cur_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub front_sonar_cur_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub scanning_sonar_cur_status: u8,

    /// ==================== 漏水状态 ====================
    /// 0: 未漏水, 1: 漏水
    pub water_leak_status: u8,

    /// ==================== 状态标志 ====================
    /// 数据有效性
    pub data_valid: bool,

    /// 时间戳
    pub timestamp: builtin_interfaces::msg::Time,

}



impl Default for SensorStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::SensorStatus::default())
  }
}

impl rosidl_runtime_rs::Message for SensorStatus {
  type RmwMsg = super::msg::rmw::SensorStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        dvl_set_status: msg.dvl_set_status,
        light_set_status: msg.light_set_status,
        front_sonar_set_status: msg.front_sonar_set_status,
        scanning_sonar_set_status: msg.scanning_sonar_set_status,
        dvl_cur_status: msg.dvl_cur_status,
        light_cur_status: msg.light_cur_status,
        front_sonar_cur_status: msg.front_sonar_cur_status,
        scanning_sonar_cur_status: msg.scanning_sonar_cur_status,
        water_leak_status: msg.water_leak_status,
        data_valid: msg.data_valid,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.timestamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      dvl_set_status: msg.dvl_set_status,
      light_set_status: msg.light_set_status,
      front_sonar_set_status: msg.front_sonar_set_status,
      scanning_sonar_set_status: msg.scanning_sonar_set_status,
      dvl_cur_status: msg.dvl_cur_status,
      light_cur_status: msg.light_cur_status,
      front_sonar_cur_status: msg.front_sonar_cur_status,
      scanning_sonar_cur_status: msg.scanning_sonar_cur_status,
      water_leak_status: msg.water_leak_status,
      data_valid: msg.data_valid,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.timestamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      dvl_set_status: msg.dvl_set_status,
      light_set_status: msg.light_set_status,
      front_sonar_set_status: msg.front_sonar_set_status,
      scanning_sonar_set_status: msg.scanning_sonar_set_status,
      dvl_cur_status: msg.dvl_cur_status,
      light_cur_status: msg.light_cur_status,
      front_sonar_cur_status: msg.front_sonar_cur_status,
      scanning_sonar_cur_status: msg.scanning_sonar_cur_status,
      water_leak_status: msg.water_leak_status,
      data_valid: msg.data_valid,
      timestamp: builtin_interfaces::msg::Time::from_rmw_message(msg.timestamp),
    }
  }
}


// Corresponds to phd_master_slave_interfaces__msg__RobustCtrlPara
/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/RobustCtrlPara.msg
/// ==================== 鲁棒控制器参数消息 ====================
/// 用于S面和PID控制器的参数配置

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobustCtrlPara {
    /// ==================== 控制模式 ====================
    /// 0: S面控制, 1: PID控制, 2: 其他(待开发)
    pub robust_mode: u8,

    /// ==================== S面控制参数 ====================
    /// X方向 (Surge)
    pub s_x_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_x_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_x_f_lim: f32,

    /// Y方向 (Sway)
    pub s_y_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_y_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_y_f_lim: f32,

    /// Z方向 (Heave)
    pub s_z_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_z_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_z_f_lim: f32,

    /// Roll (横滚)
    pub s_roll_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_roll_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_roll_t_lim: f32,

    /// Pitch (俯仰)
    pub s_pitch_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_pitch_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_pitch_t_lim: f32,

    /// Yaw (偏航)
    pub s_yaw_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_yaw_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_yaw_t_lim: f32,

    /// ==================== PID控制参数 ====================
    /// X方向 (Surge)
    pub p_x_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_x_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_x_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_x_f_lim: f32,

    /// Y方向 (Sway)
    pub p_y_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_y_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_y_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_y_f_lim: f32,

    /// Z方向 (Heave)
    pub p_z_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_z_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_z_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_z_f_lim: f32,

    /// Roll (横滚)
    pub p_roll_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_roll_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_roll_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_roll_t_lim: f32,

    /// Pitch (俯仰)
    pub p_pitch_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_pitch_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_pitch_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_pitch_t_lim: f32,

    /// Yaw (偏航)
    pub p_yaw_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_yaw_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_yaw_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_yaw_t_lim: f32,

    /// ==================== 状态标志 ====================
    pub data_valid: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp: builtin_interfaces::msg::Time,

}



impl Default for RobustCtrlPara {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::RobustCtrlPara::default())
  }
}

impl rosidl_runtime_rs::Message for RobustCtrlPara {
  type RmwMsg = super::msg::rmw::RobustCtrlPara;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        robust_mode: msg.robust_mode,
        s_x_k1: msg.s_x_k1,
        s_x_k2: msg.s_x_k2,
        s_x_f_lim: msg.s_x_f_lim,
        s_y_k1: msg.s_y_k1,
        s_y_k2: msg.s_y_k2,
        s_y_f_lim: msg.s_y_f_lim,
        s_z_k1: msg.s_z_k1,
        s_z_k2: msg.s_z_k2,
        s_z_f_lim: msg.s_z_f_lim,
        s_roll_k1: msg.s_roll_k1,
        s_roll_k2: msg.s_roll_k2,
        s_roll_t_lim: msg.s_roll_t_lim,
        s_pitch_k1: msg.s_pitch_k1,
        s_pitch_k2: msg.s_pitch_k2,
        s_pitch_t_lim: msg.s_pitch_t_lim,
        s_yaw_k1: msg.s_yaw_k1,
        s_yaw_k2: msg.s_yaw_k2,
        s_yaw_t_lim: msg.s_yaw_t_lim,
        p_x_kp: msg.p_x_kp,
        p_x_ki: msg.p_x_ki,
        p_x_kd: msg.p_x_kd,
        p_x_f_lim: msg.p_x_f_lim,
        p_y_kp: msg.p_y_kp,
        p_y_ki: msg.p_y_ki,
        p_y_kd: msg.p_y_kd,
        p_y_f_lim: msg.p_y_f_lim,
        p_z_kp: msg.p_z_kp,
        p_z_ki: msg.p_z_ki,
        p_z_kd: msg.p_z_kd,
        p_z_f_lim: msg.p_z_f_lim,
        p_roll_kp: msg.p_roll_kp,
        p_roll_ki: msg.p_roll_ki,
        p_roll_kd: msg.p_roll_kd,
        p_roll_t_lim: msg.p_roll_t_lim,
        p_pitch_kp: msg.p_pitch_kp,
        p_pitch_ki: msg.p_pitch_ki,
        p_pitch_kd: msg.p_pitch_kd,
        p_pitch_t_lim: msg.p_pitch_t_lim,
        p_yaw_kp: msg.p_yaw_kp,
        p_yaw_ki: msg.p_yaw_ki,
        p_yaw_kd: msg.p_yaw_kd,
        p_yaw_t_lim: msg.p_yaw_t_lim,
        data_valid: msg.data_valid,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.timestamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      robust_mode: msg.robust_mode,
      s_x_k1: msg.s_x_k1,
      s_x_k2: msg.s_x_k2,
      s_x_f_lim: msg.s_x_f_lim,
      s_y_k1: msg.s_y_k1,
      s_y_k2: msg.s_y_k2,
      s_y_f_lim: msg.s_y_f_lim,
      s_z_k1: msg.s_z_k1,
      s_z_k2: msg.s_z_k2,
      s_z_f_lim: msg.s_z_f_lim,
      s_roll_k1: msg.s_roll_k1,
      s_roll_k2: msg.s_roll_k2,
      s_roll_t_lim: msg.s_roll_t_lim,
      s_pitch_k1: msg.s_pitch_k1,
      s_pitch_k2: msg.s_pitch_k2,
      s_pitch_t_lim: msg.s_pitch_t_lim,
      s_yaw_k1: msg.s_yaw_k1,
      s_yaw_k2: msg.s_yaw_k2,
      s_yaw_t_lim: msg.s_yaw_t_lim,
      p_x_kp: msg.p_x_kp,
      p_x_ki: msg.p_x_ki,
      p_x_kd: msg.p_x_kd,
      p_x_f_lim: msg.p_x_f_lim,
      p_y_kp: msg.p_y_kp,
      p_y_ki: msg.p_y_ki,
      p_y_kd: msg.p_y_kd,
      p_y_f_lim: msg.p_y_f_lim,
      p_z_kp: msg.p_z_kp,
      p_z_ki: msg.p_z_ki,
      p_z_kd: msg.p_z_kd,
      p_z_f_lim: msg.p_z_f_lim,
      p_roll_kp: msg.p_roll_kp,
      p_roll_ki: msg.p_roll_ki,
      p_roll_kd: msg.p_roll_kd,
      p_roll_t_lim: msg.p_roll_t_lim,
      p_pitch_kp: msg.p_pitch_kp,
      p_pitch_ki: msg.p_pitch_ki,
      p_pitch_kd: msg.p_pitch_kd,
      p_pitch_t_lim: msg.p_pitch_t_lim,
      p_yaw_kp: msg.p_yaw_kp,
      p_yaw_ki: msg.p_yaw_ki,
      p_yaw_kd: msg.p_yaw_kd,
      p_yaw_t_lim: msg.p_yaw_t_lim,
      data_valid: msg.data_valid,
        timestamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.timestamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      robust_mode: msg.robust_mode,
      s_x_k1: msg.s_x_k1,
      s_x_k2: msg.s_x_k2,
      s_x_f_lim: msg.s_x_f_lim,
      s_y_k1: msg.s_y_k1,
      s_y_k2: msg.s_y_k2,
      s_y_f_lim: msg.s_y_f_lim,
      s_z_k1: msg.s_z_k1,
      s_z_k2: msg.s_z_k2,
      s_z_f_lim: msg.s_z_f_lim,
      s_roll_k1: msg.s_roll_k1,
      s_roll_k2: msg.s_roll_k2,
      s_roll_t_lim: msg.s_roll_t_lim,
      s_pitch_k1: msg.s_pitch_k1,
      s_pitch_k2: msg.s_pitch_k2,
      s_pitch_t_lim: msg.s_pitch_t_lim,
      s_yaw_k1: msg.s_yaw_k1,
      s_yaw_k2: msg.s_yaw_k2,
      s_yaw_t_lim: msg.s_yaw_t_lim,
      p_x_kp: msg.p_x_kp,
      p_x_ki: msg.p_x_ki,
      p_x_kd: msg.p_x_kd,
      p_x_f_lim: msg.p_x_f_lim,
      p_y_kp: msg.p_y_kp,
      p_y_ki: msg.p_y_ki,
      p_y_kd: msg.p_y_kd,
      p_y_f_lim: msg.p_y_f_lim,
      p_z_kp: msg.p_z_kp,
      p_z_ki: msg.p_z_ki,
      p_z_kd: msg.p_z_kd,
      p_z_f_lim: msg.p_z_f_lim,
      p_roll_kp: msg.p_roll_kp,
      p_roll_ki: msg.p_roll_ki,
      p_roll_kd: msg.p_roll_kd,
      p_roll_t_lim: msg.p_roll_t_lim,
      p_pitch_kp: msg.p_pitch_kp,
      p_pitch_ki: msg.p_pitch_ki,
      p_pitch_kd: msg.p_pitch_kd,
      p_pitch_t_lim: msg.p_pitch_t_lim,
      p_yaw_kp: msg.p_yaw_kp,
      p_yaw_ki: msg.p_yaw_ki,
      p_yaw_kd: msg.p_yaw_kd,
      p_yaw_t_lim: msg.p_yaw_t_lim,
      data_valid: msg.data_valid,
      timestamp: builtin_interfaces::msg::Time::from_rmw_message(msg.timestamp),
    }
  }
}


