#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "phd_master_slave_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__MtiImu() -> *const std::ffi::c_void;
}

#[link(name = "phd_master_slave_interfaces__rosidl_generator_c")]
extern "C" {
    fn phd_master_slave_interfaces__msg__MtiImu__init(msg: *mut MtiImu) -> bool;
    fn phd_master_slave_interfaces__msg__MtiImu__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<MtiImu>, size: usize) -> bool;
    fn phd_master_slave_interfaces__msg__MtiImu__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<MtiImu>);
    fn phd_master_slave_interfaces__msg__MtiImu__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<MtiImu>, out_seq: *mut rosidl_runtime_rs::Sequence<MtiImu>) -> bool;
}

// Corresponds to phd_master_slave_interfaces__msg__MtiImu
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MtiImu.msg

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MtiImu {
    /// ==================== 姿态数据 ====================
    /// 欧拉角 (度)
    pub roll: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pitch: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub yaw: f32,

    /// 四元数 (w, x, y, z)
    pub q0: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub q1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub q2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub q3: f32,

    /// ==================== 加速度计数据 ====================
    /// 线性加速度 (m/s²)
    pub accel_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub accel_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub accel_z: f32,

    /// ==================== 陀螺仪数据 ====================
    /// 角速度 (rad/s)
    pub gyro_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub gyro_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub gyro_z: f32,

    /// ==================== 磁力计数据 ====================
    /// 磁场强度 (任意单位)
    pub mag_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mag_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mag_z: f32,

    /// ==================== 传感器状态 ====================
    /// 温度 (°C)
    pub temp_imu: f32,

    /// ==================== 时间戳 ====================
    /// 系统时间 (秒)
    pub timestamp: builtin_interfaces::msg::rmw::Time,

    /// ==================== 数据源标记 ====================
    /// 数据来源: 0=PRDID(只有姿态), 1=PSONCMS(完整数据)
    pub data_source: u8,

    /// ==================== 数据质量 ====================
    /// 有效性标记: 0=无效, 1=有效
    pub data_valid: bool,

    /// ==================== 手动计算：积分速度 (m/s) ====================
    pub vel_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vel_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vel_z: f32,

    /// ==================== 手动计算：积分位置 (m) ====================
    pub pos_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pos_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pos_z: f32,

}



impl Default for MtiImu {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !phd_master_slave_interfaces__msg__MtiImu__init(&mut msg as *mut _) {
        panic!("Call to phd_master_slave_interfaces__msg__MtiImu__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for MtiImu {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__MtiImu__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__MtiImu__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__MtiImu__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for MtiImu {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for MtiImu where Self: Sized {
  const TYPE_NAME: &'static str = "phd_master_slave_interfaces/msg/MtiImu";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__MtiImu() }
  }
}


#[link(name = "phd_master_slave_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__Depth() -> *const std::ffi::c_void;
}

#[link(name = "phd_master_slave_interfaces__rosidl_generator_c")]
extern "C" {
    fn phd_master_slave_interfaces__msg__Depth__init(msg: *mut Depth) -> bool;
    fn phd_master_slave_interfaces__msg__Depth__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Depth>, size: usize) -> bool;
    fn phd_master_slave_interfaces__msg__Depth__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Depth>);
    fn phd_master_slave_interfaces__msg__Depth__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Depth>, out_seq: *mut rosidl_runtime_rs::Sequence<Depth>) -> bool;
}

// Corresponds to phd_master_slave_interfaces__msg__Depth
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/Depth.msg

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Depth {
    /// ==================== 深度计数据 ====================
    /// 深度 (米)
    pub depth: f64,

    /// 温度 (°C)
    pub temp_water: f64,

    /// ==================== 时间戳 ====================
    /// 系统时间 (秒)
    pub timestamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for Depth {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !phd_master_slave_interfaces__msg__Depth__init(&mut msg as *mut _) {
        panic!("Call to phd_master_slave_interfaces__msg__Depth__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Depth {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__Depth__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__Depth__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__Depth__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Depth {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Depth where Self: Sized {
  const TYPE_NAME: &'static str = "phd_master_slave_interfaces/msg/Depth";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__Depth() }
  }
}


#[link(name = "phd_master_slave_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__ThrusterStatus() -> *const std::ffi::c_void;
}

#[link(name = "phd_master_slave_interfaces__rosidl_generator_c")]
extern "C" {
    fn phd_master_slave_interfaces__msg__ThrusterStatus__init(msg: *mut ThrusterStatus) -> bool;
    fn phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ThrusterStatus>, size: usize) -> bool;
    fn phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ThrusterStatus>);
    fn phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ThrusterStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<ThrusterStatus>) -> bool;
}

// Corresponds to phd_master_slave_interfaces__msg__ThrusterStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/ThrusterStatus.msg
/// ==================== 推进器状态消息 ====================
/// 时间戳

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ThrusterStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp: builtin_interfaces::msg::rmw::Time,

    /// ==================== 设置功率 (0-200) ====================
    /// 0-99: 反转, 100: 停止, 101-200: 正转
    pub set_power_lfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_lfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_lbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_lbd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_power_rbd: u8,

    /// ==================== 当前实际功率 (0-200) ====================
    pub actual_power_lfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_lfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rfu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rfd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_lbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_lbd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rbu: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_power_rbd: u8,

    /// ==================== 状态标志 ====================
    /// 数据有效性
    pub data_valid: bool,

    /// 控制器温度（可选）
    pub temperature: f32,

}



impl Default for ThrusterStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !phd_master_slave_interfaces__msg__ThrusterStatus__init(&mut msg as *mut _) {
        panic!("Call to phd_master_slave_interfaces__msg__ThrusterStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ThrusterStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ThrusterStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ThrusterStatus where Self: Sized {
  const TYPE_NAME: &'static str = "phd_master_slave_interfaces/msg/ThrusterStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__ThrusterStatus() }
  }
}


#[link(name = "phd_master_slave_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__MasterMachineUI() -> *const std::ffi::c_void;
}

#[link(name = "phd_master_slave_interfaces__rosidl_generator_c")]
extern "C" {
    fn phd_master_slave_interfaces__msg__MasterMachineUI__init(msg: *mut MasterMachineUI) -> bool;
    fn phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<MasterMachineUI>, size: usize) -> bool;
    fn phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<MasterMachineUI>);
    fn phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<MasterMachineUI>, out_seq: *mut rosidl_runtime_rs::Sequence<MasterMachineUI>) -> bool;
}

// Corresponds to phd_master_slave_interfaces__msg__MasterMachineUI
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MasterMachineUI.msg

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MasterMachineUI {
    /// ==================== 控制模式 ====================
    /// 1: 全手操模式 (manual)
    /// 2: 手柄遥控模式 (xboxcontroller)
    /// 3: 键盘遥控模式 (keyboard)
    /// 4: 自动模式 (automatic)
    pub control_mode: i32,

    /// ==================== 全手操模式推进器控制值 (-100 ~ 100) ====================
    /// -100: 最大反转, 0: 停止, 100: 最大正转
    pub manual_lfu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_lfd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rfu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rfd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_lbu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_lbd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rbu: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub manual_rbd: i8,

    /// ==================== 自动模式参数 ====================
    /// 以下字段在control_mode=4时有效
    /// 纵向速度 (m/s)
    pub auto_x_velocity: f32,

    /// 横向速度 (m/s)
    pub auto_y_velocity: f32,

    /// 期望航向角 (度)
    pub auto_yaw: f32,

    /// 期望深度 (米)
    pub auto_depth: f32,

    /// 纵向距离 (米)
    pub auto_x_distance: f32,

    /// 横向距离 (米)
    pub auto_y_distance: f32,

    /// ==================== 保护参数 ====================
    /// 定深保护深度 (米)
    pub protect_depth: f32,

    /// 定高保护高度 (米)
    pub protect_height: f32,

    /// 定时保护时间 (秒)
    pub protect_time: f32,

    /// 上位机计时 (秒)
    pub upper_computer_timer: f32,

    /// 下位机计时 (秒)
    pub lower_machine_timer: f32,

    /// ==================== 时间戳 ====================
    pub timestamp: builtin_interfaces::msg::rmw::Time,

    /// ==================== 状态标志 ====================
    /// 数据有效性
    pub data_valid: bool,

}



impl Default for MasterMachineUI {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !phd_master_slave_interfaces__msg__MasterMachineUI__init(&mut msg as *mut _) {
        panic!("Call to phd_master_slave_interfaces__msg__MasterMachineUI__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for MasterMachineUI {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for MasterMachineUI {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for MasterMachineUI where Self: Sized {
  const TYPE_NAME: &'static str = "phd_master_slave_interfaces/msg/MasterMachineUI";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__MasterMachineUI() }
  }
}


#[link(name = "phd_master_slave_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__SensorStatus() -> *const std::ffi::c_void;
}

#[link(name = "phd_master_slave_interfaces__rosidl_generator_c")]
extern "C" {
    fn phd_master_slave_interfaces__msg__SensorStatus__init(msg: *mut SensorStatus) -> bool;
    fn phd_master_slave_interfaces__msg__SensorStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SensorStatus>, size: usize) -> bool;
    fn phd_master_slave_interfaces__msg__SensorStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SensorStatus>);
    fn phd_master_slave_interfaces__msg__SensorStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SensorStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<SensorStatus>) -> bool;
}

// Corresponds to phd_master_slave_interfaces__msg__SensorStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/SensorStatus.msg

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SensorStatus {
    /// ==================== 传感器开关状态消息 ====================
    /// 用于传感器开关控制和状态反馈
    /// ==================== 设置状态 (来自上位机指令) ====================
    /// 0: 关闭, 1: 开启
    pub dvl_set_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub light_set_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub front_sonar_set_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub scanning_sonar_set_status: u8,

    /// ==================== 当前状态 (从MCU读取) ====================
    /// 0: 关闭, 1: 开启
    pub dvl_cur_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub light_cur_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub front_sonar_cur_status: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub scanning_sonar_cur_status: u8,

    /// ==================== 漏水状态 ====================
    /// 0: 未漏水, 1: 漏水
    pub water_leak_status: u8,

    /// ==================== 状态标志 ====================
    /// 数据有效性
    pub data_valid: bool,

    /// 时间戳
    pub timestamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for SensorStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !phd_master_slave_interfaces__msg__SensorStatus__init(&mut msg as *mut _) {
        panic!("Call to phd_master_slave_interfaces__msg__SensorStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SensorStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__SensorStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__SensorStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__SensorStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SensorStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SensorStatus where Self: Sized {
  const TYPE_NAME: &'static str = "phd_master_slave_interfaces/msg/SensorStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__SensorStatus() }
  }
}


#[link(name = "phd_master_slave_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__RobustCtrlPara() -> *const std::ffi::c_void;
}

#[link(name = "phd_master_slave_interfaces__rosidl_generator_c")]
extern "C" {
    fn phd_master_slave_interfaces__msg__RobustCtrlPara__init(msg: *mut RobustCtrlPara) -> bool;
    fn phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RobustCtrlPara>, size: usize) -> bool;
    fn phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RobustCtrlPara>);
    fn phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RobustCtrlPara>, out_seq: *mut rosidl_runtime_rs::Sequence<RobustCtrlPara>) -> bool;
}

// Corresponds to phd_master_slave_interfaces__msg__RobustCtrlPara
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/RobustCtrlPara.msg
/// ==================== 鲁棒控制器参数消息 ====================
/// 用于S面和PID控制器的参数配置

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobustCtrlPara {
    /// ==================== 控制模式 ====================
    /// 0: S面控制, 1: PID控制, 2: 其他(待开发)
    pub robust_mode: u8,

    /// ==================== S面控制参数 ====================
    /// X方向 (Surge)
    pub s_x_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_x_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_x_f_lim: f32,

    /// Y方向 (Sway)
    pub s_y_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_y_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_y_f_lim: f32,

    /// Z方向 (Heave)
    pub s_z_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_z_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_z_f_lim: f32,

    /// Roll (横滚)
    pub s_roll_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_roll_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_roll_t_lim: f32,

    /// Pitch (俯仰)
    pub s_pitch_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_pitch_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_pitch_t_lim: f32,

    /// Yaw (偏航)
    pub s_yaw_k1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_yaw_k2: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub s_yaw_t_lim: f32,

    /// ==================== PID控制参数 ====================
    /// X方向 (Surge)
    pub p_x_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_x_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_x_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_x_f_lim: f32,

    /// Y方向 (Sway)
    pub p_y_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_y_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_y_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_y_f_lim: f32,

    /// Z方向 (Heave)
    pub p_z_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_z_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_z_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_z_f_lim: f32,

    /// Roll (横滚)
    pub p_roll_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_roll_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_roll_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_roll_t_lim: f32,

    /// Pitch (俯仰)
    pub p_pitch_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_pitch_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_pitch_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_pitch_t_lim: f32,

    /// Yaw (偏航)
    pub p_yaw_kp: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_yaw_ki: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_yaw_kd: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub p_yaw_t_lim: f32,

    /// ==================== 状态标志 ====================
    pub data_valid: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub timestamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for RobustCtrlPara {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !phd_master_slave_interfaces__msg__RobustCtrlPara__init(&mut msg as *mut _) {
        panic!("Call to phd_master_slave_interfaces__msg__RobustCtrlPara__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RobustCtrlPara {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RobustCtrlPara {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RobustCtrlPara where Self: Sized {
  const TYPE_NAME: &'static str = "phd_master_slave_interfaces/msg/RobustCtrlPara";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__phd_master_slave_interfaces__msg__RobustCtrlPara() }
  }
}


