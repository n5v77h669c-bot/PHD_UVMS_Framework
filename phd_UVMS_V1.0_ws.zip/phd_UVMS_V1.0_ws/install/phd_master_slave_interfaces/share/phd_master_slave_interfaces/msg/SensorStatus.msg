# ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/SensorStatus.msg

# ==================== 传感器开关状态消息 ====================
# 用于传感器开关控制和状态反馈

# ==================== 设置状态 (来自上位机指令) ====================
# 0: 关闭, 1: 开启
uint8 dvl_set_status
uint8 light_set_status
uint8 front_sonar_set_status
uint8 scanning_sonar_set_status

# ==================== 当前状态 (从MCU读取) ====================
# 0: 关闭, 1: 开启
uint8 dvl_cur_status
uint8 light_cur_status
uint8 front_sonar_cur_status
uint8 scanning_sonar_cur_status

# ==================== 漏水状态 ====================
# 0: 未漏水, 1: 漏水
uint8 water_leak_status

# ==================== 状态标志 ====================
bool data_valid  # 数据有效性
builtin_interfaces/Time timestamp  # 时间戳