# ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/Depth.msg

# ==================== 深度计数据 ====================
# 深度 (米)
float64 depth

# 温度 (°C)
float64 temp_water

# ==================== 时间戳 ====================
# 系统时间 (秒)
builtin_interfaces/Time timestamp