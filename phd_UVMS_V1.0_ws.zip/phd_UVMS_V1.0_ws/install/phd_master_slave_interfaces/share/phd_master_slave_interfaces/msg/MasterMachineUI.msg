# ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MasterMachineUI.msg

# ==================== 控制模式 ====================
# 1: 全手操模式 (manual)
# 2: 手柄遥控模式 (xboxcontroller)
# 3: 键盘遥控模式 (keyboard)
# 4: 自动模式 (automatic)
int32 control_mode

# ==================== 全手操模式推进器控制值 (-100 ~ 100) ====================
# -100: 最大反转, 0: 停止, 100: 最大正转
int8 manual_lfu
int8 manual_lfd
int8 manual_rfu
int8 manual_rfd
int8 manual_lbu
int8 manual_lbd
int8 manual_rbu
int8 manual_rbd

# ==================== 自动模式参数 ====================
# 以下字段在control_mode=4时有效

# 纵向速度 (m/s)
float32 auto_x_velocity

# 横向速度 (m/s)
float32 auto_y_velocity

# 期望航向角 (度)
float32 auto_yaw

# 期望深度 (米)
float32 auto_depth

# 纵向距离 (米)
float32 auto_x_distance

# 横向距离 (米)
float32 auto_y_distance

# ==================== 保护参数 ====================
# 定深保护深度 (米)
float32 protect_depth

# 定高保护高度 (米)
float32 protect_height

# 定时保护时间 (秒)
float32 protect_time

# 上位机计时 (秒)
float32 upper_computer_timer

# 下位机计时 (秒)
float32 lower_machine_timer

# ==================== 时间戳 ====================
builtin_interfaces/Time timestamp

# ==================== 状态标志 ====================
bool data_valid  # 数据有效性