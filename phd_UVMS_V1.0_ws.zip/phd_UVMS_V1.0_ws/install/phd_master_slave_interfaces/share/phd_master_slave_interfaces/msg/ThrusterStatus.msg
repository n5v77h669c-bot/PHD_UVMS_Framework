# ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/ThrusterStatus.msg
# ==================== 推进器状态消息 ====================
# 时间戳
builtin_interfaces/Time timestamp

# ==================== 设置功率 (0-200) ====================
# 0-99: 反转, 100: 停止, 101-200: 正转
uint8 set_power_lfu
uint8 set_power_lfd
uint8 set_power_rfu
uint8 set_power_rfd
uint8 set_power_lbu
uint8 set_power_lbd
uint8 set_power_rbu
uint8 set_power_rbd

# ==================== 当前实际功率 (0-200) ====================
uint8 actual_power_lfu
uint8 actual_power_lfd
uint8 actual_power_rfu
uint8 actual_power_rfd
uint8 actual_power_lbu
uint8 actual_power_lbd
uint8 actual_power_rbu
uint8 actual_power_rbd

# ==================== 状态标志 ====================
bool data_valid  # 数据有效性
float32 temperature  # 控制器温度（可选）
