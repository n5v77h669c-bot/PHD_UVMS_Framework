# ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MtiImu.msg

# ==================== 姿态数据 ====================
# 欧拉角 (度)
float32 roll
float32 pitch  
float32 yaw

# 四元数 (w, x, y, z)
float32 q0
float32 q1
float32 q2
float32 q3

# ==================== 加速度计数据 ====================
# 线性加速度 (m/s²)
float32 accel_x
float32 accel_y
float32 accel_z

# ==================== 陀螺仪数据 ====================  
# 角速度 (rad/s)
float32 gyro_x
float32 gyro_y
float32 gyro_z

# ==================== 磁力计数据 ====================
# 磁场强度 (任意单位)
float32 mag_x
float32 mag_y
float32 mag_z

# ==================== 传感器状态 ====================
# 温度 (°C)
float32 temp_imu

# ==================== 时间戳 ====================
# 系统时间 (秒)
builtin_interfaces/Time timestamp

# ==================== 数据源标记 ====================
# 数据来源: 0=PRDID(只有姿态), 1=PSONCMS(完整数据)
uint8 data_source

# ==================== 数据质量 ====================
# 有效性标记: 0=无效, 1=有效
bool data_valid

# ==================== 手动计算：积分速度 (m/s) ====================
float32 vel_x
float32 vel_y
float32 vel_z

# ==================== 手动计算：积分位置 (m) ====================
float32 pos_x
float32 pos_y
float32 pos_z