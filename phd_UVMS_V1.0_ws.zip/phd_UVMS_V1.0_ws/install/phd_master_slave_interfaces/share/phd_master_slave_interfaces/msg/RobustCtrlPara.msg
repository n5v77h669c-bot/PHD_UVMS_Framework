# ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/RobustCtrlPara.msg
# ==================== 鲁棒控制器参数消息 ====================
# 用于S面和PID控制器的参数配置

# ==================== 控制模式 ====================
# 0: S面控制, 1: PID控制, 2: 其他(待开发)
uint8 robust_mode

# ==================== S面控制参数 ====================
# X方向 (Surge)
float32 s_x_k1
float32 s_x_k2
float32 s_x_f_lim

# Y方向 (Sway)
float32 s_y_k1
float32 s_y_k2
float32 s_y_f_lim

# Z方向 (Heave)
float32 s_z_k1
float32 s_z_k2
float32 s_z_f_lim

# Roll (横滚)
float32 s_roll_k1
float32 s_roll_k2
float32 s_roll_t_lim

# Pitch (俯仰)
float32 s_pitch_k1
float32 s_pitch_k2
float32 s_pitch_t_lim

# Yaw (偏航)
float32 s_yaw_k1
float32 s_yaw_k2
float32 s_yaw_t_lim

# ==================== PID控制参数 ====================
# X方向 (Surge)
float32 p_x_kp
float32 p_x_ki
float32 p_x_kd
float32 p_x_f_lim

# Y方向 (Sway)
float32 p_y_kp
float32 p_y_ki
float32 p_y_kd
float32 p_y_f_lim

# Z方向 (Heave)
float32 p_z_kp
float32 p_z_ki
float32 p_z_kd
float32 p_z_f_lim

# Roll (横滚)
float32 p_roll_kp
float32 p_roll_ki
float32 p_roll_kd
float32 p_roll_t_lim

# Pitch (俯仰)
float32 p_pitch_kp
float32 p_pitch_ki
float32 p_pitch_kd
float32 p_pitch_t_lim

# Yaw (偏航)
float32 p_yaw_kp
float32 p_yaw_ki
float32 p_yaw_kd
float32 p_yaw_t_lim

# ==================== 状态标志 ====================
bool data_valid
builtin_interfaces/Time timestamp
