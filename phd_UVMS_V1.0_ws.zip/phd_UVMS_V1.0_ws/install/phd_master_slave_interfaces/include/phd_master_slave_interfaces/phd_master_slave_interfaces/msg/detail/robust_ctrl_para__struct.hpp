// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__STRUCT_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__phd_master_slave_interfaces__msg__RobustCtrlPara __attribute__((deprecated))
#else
# define DEPRECATED__phd_master_slave_interfaces__msg__RobustCtrlPara __declspec(deprecated)
#endif

namespace phd_master_slave_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RobustCtrlPara_
{
  using Type = RobustCtrlPara_<ContainerAllocator>;

  explicit RobustCtrlPara_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robust_mode = 0;
      this->s_x_k1 = 0.0f;
      this->s_x_k2 = 0.0f;
      this->s_x_f_lim = 0.0f;
      this->s_y_k1 = 0.0f;
      this->s_y_k2 = 0.0f;
      this->s_y_f_lim = 0.0f;
      this->s_z_k1 = 0.0f;
      this->s_z_k2 = 0.0f;
      this->s_z_f_lim = 0.0f;
      this->s_roll_k1 = 0.0f;
      this->s_roll_k2 = 0.0f;
      this->s_roll_t_lim = 0.0f;
      this->s_pitch_k1 = 0.0f;
      this->s_pitch_k2 = 0.0f;
      this->s_pitch_t_lim = 0.0f;
      this->s_yaw_k1 = 0.0f;
      this->s_yaw_k2 = 0.0f;
      this->s_yaw_t_lim = 0.0f;
      this->p_x_kp = 0.0f;
      this->p_x_ki = 0.0f;
      this->p_x_kd = 0.0f;
      this->p_x_f_lim = 0.0f;
      this->p_y_kp = 0.0f;
      this->p_y_ki = 0.0f;
      this->p_y_kd = 0.0f;
      this->p_y_f_lim = 0.0f;
      this->p_z_kp = 0.0f;
      this->p_z_ki = 0.0f;
      this->p_z_kd = 0.0f;
      this->p_z_f_lim = 0.0f;
      this->p_roll_kp = 0.0f;
      this->p_roll_ki = 0.0f;
      this->p_roll_kd = 0.0f;
      this->p_roll_t_lim = 0.0f;
      this->p_pitch_kp = 0.0f;
      this->p_pitch_ki = 0.0f;
      this->p_pitch_kd = 0.0f;
      this->p_pitch_t_lim = 0.0f;
      this->p_yaw_kp = 0.0f;
      this->p_yaw_ki = 0.0f;
      this->p_yaw_kd = 0.0f;
      this->p_yaw_t_lim = 0.0f;
      this->data_valid = false;
    }
  }

  explicit RobustCtrlPara_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->robust_mode = 0;
      this->s_x_k1 = 0.0f;
      this->s_x_k2 = 0.0f;
      this->s_x_f_lim = 0.0f;
      this->s_y_k1 = 0.0f;
      this->s_y_k2 = 0.0f;
      this->s_y_f_lim = 0.0f;
      this->s_z_k1 = 0.0f;
      this->s_z_k2 = 0.0f;
      this->s_z_f_lim = 0.0f;
      this->s_roll_k1 = 0.0f;
      this->s_roll_k2 = 0.0f;
      this->s_roll_t_lim = 0.0f;
      this->s_pitch_k1 = 0.0f;
      this->s_pitch_k2 = 0.0f;
      this->s_pitch_t_lim = 0.0f;
      this->s_yaw_k1 = 0.0f;
      this->s_yaw_k2 = 0.0f;
      this->s_yaw_t_lim = 0.0f;
      this->p_x_kp = 0.0f;
      this->p_x_ki = 0.0f;
      this->p_x_kd = 0.0f;
      this->p_x_f_lim = 0.0f;
      this->p_y_kp = 0.0f;
      this->p_y_ki = 0.0f;
      this->p_y_kd = 0.0f;
      this->p_y_f_lim = 0.0f;
      this->p_z_kp = 0.0f;
      this->p_z_ki = 0.0f;
      this->p_z_kd = 0.0f;
      this->p_z_f_lim = 0.0f;
      this->p_roll_kp = 0.0f;
      this->p_roll_ki = 0.0f;
      this->p_roll_kd = 0.0f;
      this->p_roll_t_lim = 0.0f;
      this->p_pitch_kp = 0.0f;
      this->p_pitch_ki = 0.0f;
      this->p_pitch_kd = 0.0f;
      this->p_pitch_t_lim = 0.0f;
      this->p_yaw_kp = 0.0f;
      this->p_yaw_ki = 0.0f;
      this->p_yaw_kd = 0.0f;
      this->p_yaw_t_lim = 0.0f;
      this->data_valid = false;
    }
  }

  // field types and members
  using _robust_mode_type =
    uint8_t;
  _robust_mode_type robust_mode;
  using _s_x_k1_type =
    float;
  _s_x_k1_type s_x_k1;
  using _s_x_k2_type =
    float;
  _s_x_k2_type s_x_k2;
  using _s_x_f_lim_type =
    float;
  _s_x_f_lim_type s_x_f_lim;
  using _s_y_k1_type =
    float;
  _s_y_k1_type s_y_k1;
  using _s_y_k2_type =
    float;
  _s_y_k2_type s_y_k2;
  using _s_y_f_lim_type =
    float;
  _s_y_f_lim_type s_y_f_lim;
  using _s_z_k1_type =
    float;
  _s_z_k1_type s_z_k1;
  using _s_z_k2_type =
    float;
  _s_z_k2_type s_z_k2;
  using _s_z_f_lim_type =
    float;
  _s_z_f_lim_type s_z_f_lim;
  using _s_roll_k1_type =
    float;
  _s_roll_k1_type s_roll_k1;
  using _s_roll_k2_type =
    float;
  _s_roll_k2_type s_roll_k2;
  using _s_roll_t_lim_type =
    float;
  _s_roll_t_lim_type s_roll_t_lim;
  using _s_pitch_k1_type =
    float;
  _s_pitch_k1_type s_pitch_k1;
  using _s_pitch_k2_type =
    float;
  _s_pitch_k2_type s_pitch_k2;
  using _s_pitch_t_lim_type =
    float;
  _s_pitch_t_lim_type s_pitch_t_lim;
  using _s_yaw_k1_type =
    float;
  _s_yaw_k1_type s_yaw_k1;
  using _s_yaw_k2_type =
    float;
  _s_yaw_k2_type s_yaw_k2;
  using _s_yaw_t_lim_type =
    float;
  _s_yaw_t_lim_type s_yaw_t_lim;
  using _p_x_kp_type =
    float;
  _p_x_kp_type p_x_kp;
  using _p_x_ki_type =
    float;
  _p_x_ki_type p_x_ki;
  using _p_x_kd_type =
    float;
  _p_x_kd_type p_x_kd;
  using _p_x_f_lim_type =
    float;
  _p_x_f_lim_type p_x_f_lim;
  using _p_y_kp_type =
    float;
  _p_y_kp_type p_y_kp;
  using _p_y_ki_type =
    float;
  _p_y_ki_type p_y_ki;
  using _p_y_kd_type =
    float;
  _p_y_kd_type p_y_kd;
  using _p_y_f_lim_type =
    float;
  _p_y_f_lim_type p_y_f_lim;
  using _p_z_kp_type =
    float;
  _p_z_kp_type p_z_kp;
  using _p_z_ki_type =
    float;
  _p_z_ki_type p_z_ki;
  using _p_z_kd_type =
    float;
  _p_z_kd_type p_z_kd;
  using _p_z_f_lim_type =
    float;
  _p_z_f_lim_type p_z_f_lim;
  using _p_roll_kp_type =
    float;
  _p_roll_kp_type p_roll_kp;
  using _p_roll_ki_type =
    float;
  _p_roll_ki_type p_roll_ki;
  using _p_roll_kd_type =
    float;
  _p_roll_kd_type p_roll_kd;
  using _p_roll_t_lim_type =
    float;
  _p_roll_t_lim_type p_roll_t_lim;
  using _p_pitch_kp_type =
    float;
  _p_pitch_kp_type p_pitch_kp;
  using _p_pitch_ki_type =
    float;
  _p_pitch_ki_type p_pitch_ki;
  using _p_pitch_kd_type =
    float;
  _p_pitch_kd_type p_pitch_kd;
  using _p_pitch_t_lim_type =
    float;
  _p_pitch_t_lim_type p_pitch_t_lim;
  using _p_yaw_kp_type =
    float;
  _p_yaw_kp_type p_yaw_kp;
  using _p_yaw_ki_type =
    float;
  _p_yaw_ki_type p_yaw_ki;
  using _p_yaw_kd_type =
    float;
  _p_yaw_kd_type p_yaw_kd;
  using _p_yaw_t_lim_type =
    float;
  _p_yaw_t_lim_type p_yaw_t_lim;
  using _data_valid_type =
    bool;
  _data_valid_type data_valid;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__robust_mode(
    const uint8_t & _arg)
  {
    this->robust_mode = _arg;
    return *this;
  }
  Type & set__s_x_k1(
    const float & _arg)
  {
    this->s_x_k1 = _arg;
    return *this;
  }
  Type & set__s_x_k2(
    const float & _arg)
  {
    this->s_x_k2 = _arg;
    return *this;
  }
  Type & set__s_x_f_lim(
    const float & _arg)
  {
    this->s_x_f_lim = _arg;
    return *this;
  }
  Type & set__s_y_k1(
    const float & _arg)
  {
    this->s_y_k1 = _arg;
    return *this;
  }
  Type & set__s_y_k2(
    const float & _arg)
  {
    this->s_y_k2 = _arg;
    return *this;
  }
  Type & set__s_y_f_lim(
    const float & _arg)
  {
    this->s_y_f_lim = _arg;
    return *this;
  }
  Type & set__s_z_k1(
    const float & _arg)
  {
    this->s_z_k1 = _arg;
    return *this;
  }
  Type & set__s_z_k2(
    const float & _arg)
  {
    this->s_z_k2 = _arg;
    return *this;
  }
  Type & set__s_z_f_lim(
    const float & _arg)
  {
    this->s_z_f_lim = _arg;
    return *this;
  }
  Type & set__s_roll_k1(
    const float & _arg)
  {
    this->s_roll_k1 = _arg;
    return *this;
  }
  Type & set__s_roll_k2(
    const float & _arg)
  {
    this->s_roll_k2 = _arg;
    return *this;
  }
  Type & set__s_roll_t_lim(
    const float & _arg)
  {
    this->s_roll_t_lim = _arg;
    return *this;
  }
  Type & set__s_pitch_k1(
    const float & _arg)
  {
    this->s_pitch_k1 = _arg;
    return *this;
  }
  Type & set__s_pitch_k2(
    const float & _arg)
  {
    this->s_pitch_k2 = _arg;
    return *this;
  }
  Type & set__s_pitch_t_lim(
    const float & _arg)
  {
    this->s_pitch_t_lim = _arg;
    return *this;
  }
  Type & set__s_yaw_k1(
    const float & _arg)
  {
    this->s_yaw_k1 = _arg;
    return *this;
  }
  Type & set__s_yaw_k2(
    const float & _arg)
  {
    this->s_yaw_k2 = _arg;
    return *this;
  }
  Type & set__s_yaw_t_lim(
    const float & _arg)
  {
    this->s_yaw_t_lim = _arg;
    return *this;
  }
  Type & set__p_x_kp(
    const float & _arg)
  {
    this->p_x_kp = _arg;
    return *this;
  }
  Type & set__p_x_ki(
    const float & _arg)
  {
    this->p_x_ki = _arg;
    return *this;
  }
  Type & set__p_x_kd(
    const float & _arg)
  {
    this->p_x_kd = _arg;
    return *this;
  }
  Type & set__p_x_f_lim(
    const float & _arg)
  {
    this->p_x_f_lim = _arg;
    return *this;
  }
  Type & set__p_y_kp(
    const float & _arg)
  {
    this->p_y_kp = _arg;
    return *this;
  }
  Type & set__p_y_ki(
    const float & _arg)
  {
    this->p_y_ki = _arg;
    return *this;
  }
  Type & set__p_y_kd(
    const float & _arg)
  {
    this->p_y_kd = _arg;
    return *this;
  }
  Type & set__p_y_f_lim(
    const float & _arg)
  {
    this->p_y_f_lim = _arg;
    return *this;
  }
  Type & set__p_z_kp(
    const float & _arg)
  {
    this->p_z_kp = _arg;
    return *this;
  }
  Type & set__p_z_ki(
    const float & _arg)
  {
    this->p_z_ki = _arg;
    return *this;
  }
  Type & set__p_z_kd(
    const float & _arg)
  {
    this->p_z_kd = _arg;
    return *this;
  }
  Type & set__p_z_f_lim(
    const float & _arg)
  {
    this->p_z_f_lim = _arg;
    return *this;
  }
  Type & set__p_roll_kp(
    const float & _arg)
  {
    this->p_roll_kp = _arg;
    return *this;
  }
  Type & set__p_roll_ki(
    const float & _arg)
  {
    this->p_roll_ki = _arg;
    return *this;
  }
  Type & set__p_roll_kd(
    const float & _arg)
  {
    this->p_roll_kd = _arg;
    return *this;
  }
  Type & set__p_roll_t_lim(
    const float & _arg)
  {
    this->p_roll_t_lim = _arg;
    return *this;
  }
  Type & set__p_pitch_kp(
    const float & _arg)
  {
    this->p_pitch_kp = _arg;
    return *this;
  }
  Type & set__p_pitch_ki(
    const float & _arg)
  {
    this->p_pitch_ki = _arg;
    return *this;
  }
  Type & set__p_pitch_kd(
    const float & _arg)
  {
    this->p_pitch_kd = _arg;
    return *this;
  }
  Type & set__p_pitch_t_lim(
    const float & _arg)
  {
    this->p_pitch_t_lim = _arg;
    return *this;
  }
  Type & set__p_yaw_kp(
    const float & _arg)
  {
    this->p_yaw_kp = _arg;
    return *this;
  }
  Type & set__p_yaw_ki(
    const float & _arg)
  {
    this->p_yaw_ki = _arg;
    return *this;
  }
  Type & set__p_yaw_kd(
    const float & _arg)
  {
    this->p_yaw_kd = _arg;
    return *this;
  }
  Type & set__p_yaw_t_lim(
    const float & _arg)
  {
    this->p_yaw_t_lim = _arg;
    return *this;
  }
  Type & set__data_valid(
    const bool & _arg)
  {
    this->data_valid = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator> *;
  using ConstRawPtr =
    const phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__phd_master_slave_interfaces__msg__RobustCtrlPara
    std::shared_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__phd_master_slave_interfaces__msg__RobustCtrlPara
    std::shared_ptr<phd_master_slave_interfaces::msg::RobustCtrlPara_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RobustCtrlPara_ & other) const
  {
    if (this->robust_mode != other.robust_mode) {
      return false;
    }
    if (this->s_x_k1 != other.s_x_k1) {
      return false;
    }
    if (this->s_x_k2 != other.s_x_k2) {
      return false;
    }
    if (this->s_x_f_lim != other.s_x_f_lim) {
      return false;
    }
    if (this->s_y_k1 != other.s_y_k1) {
      return false;
    }
    if (this->s_y_k2 != other.s_y_k2) {
      return false;
    }
    if (this->s_y_f_lim != other.s_y_f_lim) {
      return false;
    }
    if (this->s_z_k1 != other.s_z_k1) {
      return false;
    }
    if (this->s_z_k2 != other.s_z_k2) {
      return false;
    }
    if (this->s_z_f_lim != other.s_z_f_lim) {
      return false;
    }
    if (this->s_roll_k1 != other.s_roll_k1) {
      return false;
    }
    if (this->s_roll_k2 != other.s_roll_k2) {
      return false;
    }
    if (this->s_roll_t_lim != other.s_roll_t_lim) {
      return false;
    }
    if (this->s_pitch_k1 != other.s_pitch_k1) {
      return false;
    }
    if (this->s_pitch_k2 != other.s_pitch_k2) {
      return false;
    }
    if (this->s_pitch_t_lim != other.s_pitch_t_lim) {
      return false;
    }
    if (this->s_yaw_k1 != other.s_yaw_k1) {
      return false;
    }
    if (this->s_yaw_k2 != other.s_yaw_k2) {
      return false;
    }
    if (this->s_yaw_t_lim != other.s_yaw_t_lim) {
      return false;
    }
    if (this->p_x_kp != other.p_x_kp) {
      return false;
    }
    if (this->p_x_ki != other.p_x_ki) {
      return false;
    }
    if (this->p_x_kd != other.p_x_kd) {
      return false;
    }
    if (this->p_x_f_lim != other.p_x_f_lim) {
      return false;
    }
    if (this->p_y_kp != other.p_y_kp) {
      return false;
    }
    if (this->p_y_ki != other.p_y_ki) {
      return false;
    }
    if (this->p_y_kd != other.p_y_kd) {
      return false;
    }
    if (this->p_y_f_lim != other.p_y_f_lim) {
      return false;
    }
    if (this->p_z_kp != other.p_z_kp) {
      return false;
    }
    if (this->p_z_ki != other.p_z_ki) {
      return false;
    }
    if (this->p_z_kd != other.p_z_kd) {
      return false;
    }
    if (this->p_z_f_lim != other.p_z_f_lim) {
      return false;
    }
    if (this->p_roll_kp != other.p_roll_kp) {
      return false;
    }
    if (this->p_roll_ki != other.p_roll_ki) {
      return false;
    }
    if (this->p_roll_kd != other.p_roll_kd) {
      return false;
    }
    if (this->p_roll_t_lim != other.p_roll_t_lim) {
      return false;
    }
    if (this->p_pitch_kp != other.p_pitch_kp) {
      return false;
    }
    if (this->p_pitch_ki != other.p_pitch_ki) {
      return false;
    }
    if (this->p_pitch_kd != other.p_pitch_kd) {
      return false;
    }
    if (this->p_pitch_t_lim != other.p_pitch_t_lim) {
      return false;
    }
    if (this->p_yaw_kp != other.p_yaw_kp) {
      return false;
    }
    if (this->p_yaw_ki != other.p_yaw_ki) {
      return false;
    }
    if (this->p_yaw_kd != other.p_yaw_kd) {
      return false;
    }
    if (this->p_yaw_t_lim != other.p_yaw_t_lim) {
      return false;
    }
    if (this->data_valid != other.data_valid) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const RobustCtrlPara_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RobustCtrlPara_

// alias to use template instance with default allocator
using RobustCtrlPara =
  phd_master_slave_interfaces::msg::RobustCtrlPara_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__STRUCT_HPP_
