// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__MASTER_MACHINE_UI_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__MASTER_MACHINE_UI_HPP_

#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__struct.hpp"
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__builder.hpp"
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__traits.hpp"
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__type_support.hpp"

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__MASTER_MACHINE_UI_HPP_
