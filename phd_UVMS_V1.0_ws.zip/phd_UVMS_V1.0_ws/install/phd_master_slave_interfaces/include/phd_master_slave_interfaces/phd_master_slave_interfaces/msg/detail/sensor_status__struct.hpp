// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from phd_master_slave_interfaces:msg/SensorStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__STRUCT_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__phd_master_slave_interfaces__msg__SensorStatus __attribute__((deprecated))
#else
# define DEPRECATED__phd_master_slave_interfaces__msg__SensorStatus __declspec(deprecated)
#endif

namespace phd_master_slave_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SensorStatus_
{
  using Type = SensorStatus_<ContainerAllocator>;

  explicit SensorStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dvl_set_status = 0;
      this->light_set_status = 0;
      this->front_sonar_set_status = 0;
      this->scanning_sonar_set_status = 0;
      this->dvl_cur_status = 0;
      this->light_cur_status = 0;
      this->front_sonar_cur_status = 0;
      this->scanning_sonar_cur_status = 0;
      this->water_leak_status = 0;
      this->data_valid = false;
    }
  }

  explicit SensorStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dvl_set_status = 0;
      this->light_set_status = 0;
      this->front_sonar_set_status = 0;
      this->scanning_sonar_set_status = 0;
      this->dvl_cur_status = 0;
      this->light_cur_status = 0;
      this->front_sonar_cur_status = 0;
      this->scanning_sonar_cur_status = 0;
      this->water_leak_status = 0;
      this->data_valid = false;
    }
  }

  // field types and members
  using _dvl_set_status_type =
    uint8_t;
  _dvl_set_status_type dvl_set_status;
  using _light_set_status_type =
    uint8_t;
  _light_set_status_type light_set_status;
  using _front_sonar_set_status_type =
    uint8_t;
  _front_sonar_set_status_type front_sonar_set_status;
  using _scanning_sonar_set_status_type =
    uint8_t;
  _scanning_sonar_set_status_type scanning_sonar_set_status;
  using _dvl_cur_status_type =
    uint8_t;
  _dvl_cur_status_type dvl_cur_status;
  using _light_cur_status_type =
    uint8_t;
  _light_cur_status_type light_cur_status;
  using _front_sonar_cur_status_type =
    uint8_t;
  _front_sonar_cur_status_type front_sonar_cur_status;
  using _scanning_sonar_cur_status_type =
    uint8_t;
  _scanning_sonar_cur_status_type scanning_sonar_cur_status;
  using _water_leak_status_type =
    uint8_t;
  _water_leak_status_type water_leak_status;
  using _data_valid_type =
    bool;
  _data_valid_type data_valid;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__dvl_set_status(
    const uint8_t & _arg)
  {
    this->dvl_set_status = _arg;
    return *this;
  }
  Type & set__light_set_status(
    const uint8_t & _arg)
  {
    this->light_set_status = _arg;
    return *this;
  }
  Type & set__front_sonar_set_status(
    const uint8_t & _arg)
  {
    this->front_sonar_set_status = _arg;
    return *this;
  }
  Type & set__scanning_sonar_set_status(
    const uint8_t & _arg)
  {
    this->scanning_sonar_set_status = _arg;
    return *this;
  }
  Type & set__dvl_cur_status(
    const uint8_t & _arg)
  {
    this->dvl_cur_status = _arg;
    return *this;
  }
  Type & set__light_cur_status(
    const uint8_t & _arg)
  {
    this->light_cur_status = _arg;
    return *this;
  }
  Type & set__front_sonar_cur_status(
    const uint8_t & _arg)
  {
    this->front_sonar_cur_status = _arg;
    return *this;
  }
  Type & set__scanning_sonar_cur_status(
    const uint8_t & _arg)
  {
    this->scanning_sonar_cur_status = _arg;
    return *this;
  }
  Type & set__water_leak_status(
    const uint8_t & _arg)
  {
    this->water_leak_status = _arg;
    return *this;
  }
  Type & set__data_valid(
    const bool & _arg)
  {
    this->data_valid = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__phd_master_slave_interfaces__msg__SensorStatus
    std::shared_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__phd_master_slave_interfaces__msg__SensorStatus
    std::shared_ptr<phd_master_slave_interfaces::msg::SensorStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SensorStatus_ & other) const
  {
    if (this->dvl_set_status != other.dvl_set_status) {
      return false;
    }
    if (this->light_set_status != other.light_set_status) {
      return false;
    }
    if (this->front_sonar_set_status != other.front_sonar_set_status) {
      return false;
    }
    if (this->scanning_sonar_set_status != other.scanning_sonar_set_status) {
      return false;
    }
    if (this->dvl_cur_status != other.dvl_cur_status) {
      return false;
    }
    if (this->light_cur_status != other.light_cur_status) {
      return false;
    }
    if (this->front_sonar_cur_status != other.front_sonar_cur_status) {
      return false;
    }
    if (this->scanning_sonar_cur_status != other.scanning_sonar_cur_status) {
      return false;
    }
    if (this->water_leak_status != other.water_leak_status) {
      return false;
    }
    if (this->data_valid != other.data_valid) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const SensorStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SensorStatus_

// alias to use template instance with default allocator
using SensorStatus =
  phd_master_slave_interfaces::msg::SensorStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__STRUCT_HPP_
