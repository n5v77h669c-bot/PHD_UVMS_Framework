﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__STRUCT_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/MasterMachineUI in the package phd_master_slave_interfaces.
/**
  * ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MasterMachineUI.msg
 */
typedef struct phd_master_slave_interfaces__msg__MasterMachineUI
{
  /// ==================== 控制模式 ====================
  /// 1: 全手操模式 (manual)
  /// 2: 手柄遥控模式 (xboxcontroller)
  /// 3: 键盘遥控模式 (keyboard)
  /// 4: 自动模式 (automatic)
  int32_t control_mode;
  /// ==================== 全手操模式推进器控制值 (-100 ~ 100) ====================
  /// -100: 最大反转, 0: 停止, 100: 最大正转
  int8_t manual_lfu;
  int8_t manual_lfd;
  int8_t manual_rfu;
  int8_t manual_rfd;
  int8_t manual_lbu;
  int8_t manual_lbd;
  int8_t manual_rbu;
  int8_t manual_rbd;
  /// ==================== 自动模式参数 ====================
  /// 以下字段在control_mode=4时有效
  /// 纵向速度 (m/s)
  float auto_x_velocity;
  /// 横向速度 (m/s)
  float auto_y_velocity;
  /// 期望航向角 (度)
  float auto_yaw;
  /// 期望深度 (米)
  float auto_depth;
  /// 纵向距离 (米)
  float auto_x_distance;
  /// 横向距离 (米)
  float auto_y_distance;
  /// ==================== 保护参数 ====================
  /// 定深保护深度 (米)
  float protect_depth;
  /// 定高保护高度 (米)
  float protect_height;
  /// 定时保护时间 (秒)
  float protect_time;
  /// 上位机计时 (秒)
  float upper_computer_timer;
  /// 下位机计时 (秒)
  float lower_machine_timer;
  /// ==================== 时间戳 ====================
  builtin_interfaces__msg__Time timestamp;
  /// ==================== 状态标志 ====================
  /// 数据有效性
  bool data_valid;
} phd_master_slave_interfaces__msg__MasterMachineUI;

// Struct for a sequence of phd_master_slave_interfaces__msg__MasterMachineUI.
typedef struct phd_master_slave_interfaces__msg__MasterMachineUI__Sequence
{
  phd_master_slave_interfaces__msg__MasterMachineUI * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} phd_master_slave_interfaces__msg__MasterMachineUI__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__STRUCT_H_
