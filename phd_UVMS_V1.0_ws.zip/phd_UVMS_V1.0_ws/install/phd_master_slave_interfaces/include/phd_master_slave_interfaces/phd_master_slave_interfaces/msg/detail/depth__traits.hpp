// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from phd_master_slave_interfaces:msg/Depth.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__TRAITS_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "phd_master_slave_interfaces/msg/detail/depth__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace phd_master_slave_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const Depth & msg,
  std::ostream & out)
{
  out << "{";
  // member: depth
  {
    out << "depth: ";
    rosidl_generator_traits::value_to_yaml(msg.depth, out);
    out << ", ";
  }

  // member: temp_water
  {
    out << "temp_water: ";
    rosidl_generator_traits::value_to_yaml(msg.temp_water, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Depth & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: depth
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "depth: ";
    rosidl_generator_traits::value_to_yaml(msg.depth, out);
    out << "\n";
  }

  // member: temp_water
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "temp_water: ";
    rosidl_generator_traits::value_to_yaml(msg.temp_water, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Depth & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace phd_master_slave_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use phd_master_slave_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const phd_master_slave_interfaces::msg::Depth & msg,
  std::ostream & out, size_t indentation = 0)
{
  phd_master_slave_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use phd_master_slave_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const phd_master_slave_interfaces::msg::Depth & msg)
{
  return phd_master_slave_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<phd_master_slave_interfaces::msg::Depth>()
{
  return "phd_master_slave_interfaces::msg::Depth";
}

template<>
inline const char * name<phd_master_slave_interfaces::msg::Depth>()
{
  return "phd_master_slave_interfaces/msg/Depth";
}

template<>
struct has_fixed_size<phd_master_slave_interfaces::msg::Depth>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<phd_master_slave_interfaces::msg::Depth>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<phd_master_slave_interfaces::msg::Depth>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__TRAITS_HPP_
