// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__BUILDER_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace phd_master_slave_interfaces
{

namespace msg
{

namespace builder
{

class Init_RobustCtrlPara_timestamp
{
public:
  explicit Init_RobustCtrlPara_timestamp(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  ::phd_master_slave_interfaces::msg::RobustCtrlPara timestamp(::phd_master_slave_interfaces::msg::RobustCtrlPara::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_data_valid
{
public:
  explicit Init_RobustCtrlPara_data_valid(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_timestamp data_valid(::phd_master_slave_interfaces::msg::RobustCtrlPara::_data_valid_type arg)
  {
    msg_.data_valid = std::move(arg);
    return Init_RobustCtrlPara_timestamp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_yaw_t_lim
{
public:
  explicit Init_RobustCtrlPara_p_yaw_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_data_valid p_yaw_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_yaw_t_lim_type arg)
  {
    msg_.p_yaw_t_lim = std::move(arg);
    return Init_RobustCtrlPara_data_valid(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_yaw_kd
{
public:
  explicit Init_RobustCtrlPara_p_yaw_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_yaw_t_lim p_yaw_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_yaw_kd_type arg)
  {
    msg_.p_yaw_kd = std::move(arg);
    return Init_RobustCtrlPara_p_yaw_t_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_yaw_ki
{
public:
  explicit Init_RobustCtrlPara_p_yaw_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_yaw_kd p_yaw_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_yaw_ki_type arg)
  {
    msg_.p_yaw_ki = std::move(arg);
    return Init_RobustCtrlPara_p_yaw_kd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_yaw_kp
{
public:
  explicit Init_RobustCtrlPara_p_yaw_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_yaw_ki p_yaw_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_yaw_kp_type arg)
  {
    msg_.p_yaw_kp = std::move(arg);
    return Init_RobustCtrlPara_p_yaw_ki(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_pitch_t_lim
{
public:
  explicit Init_RobustCtrlPara_p_pitch_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_yaw_kp p_pitch_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_pitch_t_lim_type arg)
  {
    msg_.p_pitch_t_lim = std::move(arg);
    return Init_RobustCtrlPara_p_yaw_kp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_pitch_kd
{
public:
  explicit Init_RobustCtrlPara_p_pitch_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_pitch_t_lim p_pitch_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_pitch_kd_type arg)
  {
    msg_.p_pitch_kd = std::move(arg);
    return Init_RobustCtrlPara_p_pitch_t_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_pitch_ki
{
public:
  explicit Init_RobustCtrlPara_p_pitch_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_pitch_kd p_pitch_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_pitch_ki_type arg)
  {
    msg_.p_pitch_ki = std::move(arg);
    return Init_RobustCtrlPara_p_pitch_kd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_pitch_kp
{
public:
  explicit Init_RobustCtrlPara_p_pitch_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_pitch_ki p_pitch_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_pitch_kp_type arg)
  {
    msg_.p_pitch_kp = std::move(arg);
    return Init_RobustCtrlPara_p_pitch_ki(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_roll_t_lim
{
public:
  explicit Init_RobustCtrlPara_p_roll_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_pitch_kp p_roll_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_roll_t_lim_type arg)
  {
    msg_.p_roll_t_lim = std::move(arg);
    return Init_RobustCtrlPara_p_pitch_kp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_roll_kd
{
public:
  explicit Init_RobustCtrlPara_p_roll_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_roll_t_lim p_roll_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_roll_kd_type arg)
  {
    msg_.p_roll_kd = std::move(arg);
    return Init_RobustCtrlPara_p_roll_t_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_roll_ki
{
public:
  explicit Init_RobustCtrlPara_p_roll_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_roll_kd p_roll_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_roll_ki_type arg)
  {
    msg_.p_roll_ki = std::move(arg);
    return Init_RobustCtrlPara_p_roll_kd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_roll_kp
{
public:
  explicit Init_RobustCtrlPara_p_roll_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_roll_ki p_roll_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_roll_kp_type arg)
  {
    msg_.p_roll_kp = std::move(arg);
    return Init_RobustCtrlPara_p_roll_ki(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_z_f_lim
{
public:
  explicit Init_RobustCtrlPara_p_z_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_roll_kp p_z_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_z_f_lim_type arg)
  {
    msg_.p_z_f_lim = std::move(arg);
    return Init_RobustCtrlPara_p_roll_kp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_z_kd
{
public:
  explicit Init_RobustCtrlPara_p_z_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_z_f_lim p_z_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_z_kd_type arg)
  {
    msg_.p_z_kd = std::move(arg);
    return Init_RobustCtrlPara_p_z_f_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_z_ki
{
public:
  explicit Init_RobustCtrlPara_p_z_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_z_kd p_z_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_z_ki_type arg)
  {
    msg_.p_z_ki = std::move(arg);
    return Init_RobustCtrlPara_p_z_kd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_z_kp
{
public:
  explicit Init_RobustCtrlPara_p_z_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_z_ki p_z_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_z_kp_type arg)
  {
    msg_.p_z_kp = std::move(arg);
    return Init_RobustCtrlPara_p_z_ki(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_y_f_lim
{
public:
  explicit Init_RobustCtrlPara_p_y_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_z_kp p_y_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_y_f_lim_type arg)
  {
    msg_.p_y_f_lim = std::move(arg);
    return Init_RobustCtrlPara_p_z_kp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_y_kd
{
public:
  explicit Init_RobustCtrlPara_p_y_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_y_f_lim p_y_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_y_kd_type arg)
  {
    msg_.p_y_kd = std::move(arg);
    return Init_RobustCtrlPara_p_y_f_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_y_ki
{
public:
  explicit Init_RobustCtrlPara_p_y_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_y_kd p_y_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_y_ki_type arg)
  {
    msg_.p_y_ki = std::move(arg);
    return Init_RobustCtrlPara_p_y_kd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_y_kp
{
public:
  explicit Init_RobustCtrlPara_p_y_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_y_ki p_y_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_y_kp_type arg)
  {
    msg_.p_y_kp = std::move(arg);
    return Init_RobustCtrlPara_p_y_ki(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_x_f_lim
{
public:
  explicit Init_RobustCtrlPara_p_x_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_y_kp p_x_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_x_f_lim_type arg)
  {
    msg_.p_x_f_lim = std::move(arg);
    return Init_RobustCtrlPara_p_y_kp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_x_kd
{
public:
  explicit Init_RobustCtrlPara_p_x_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_x_f_lim p_x_kd(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_x_kd_type arg)
  {
    msg_.p_x_kd = std::move(arg);
    return Init_RobustCtrlPara_p_x_f_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_x_ki
{
public:
  explicit Init_RobustCtrlPara_p_x_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_x_kd p_x_ki(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_x_ki_type arg)
  {
    msg_.p_x_ki = std::move(arg);
    return Init_RobustCtrlPara_p_x_kd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_p_x_kp
{
public:
  explicit Init_RobustCtrlPara_p_x_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_x_ki p_x_kp(::phd_master_slave_interfaces::msg::RobustCtrlPara::_p_x_kp_type arg)
  {
    msg_.p_x_kp = std::move(arg);
    return Init_RobustCtrlPara_p_x_ki(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_yaw_t_lim
{
public:
  explicit Init_RobustCtrlPara_s_yaw_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_p_x_kp s_yaw_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_yaw_t_lim_type arg)
  {
    msg_.s_yaw_t_lim = std::move(arg);
    return Init_RobustCtrlPara_p_x_kp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_yaw_k2
{
public:
  explicit Init_RobustCtrlPara_s_yaw_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_yaw_t_lim s_yaw_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_yaw_k2_type arg)
  {
    msg_.s_yaw_k2 = std::move(arg);
    return Init_RobustCtrlPara_s_yaw_t_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_yaw_k1
{
public:
  explicit Init_RobustCtrlPara_s_yaw_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_yaw_k2 s_yaw_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_yaw_k1_type arg)
  {
    msg_.s_yaw_k1 = std::move(arg);
    return Init_RobustCtrlPara_s_yaw_k2(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_pitch_t_lim
{
public:
  explicit Init_RobustCtrlPara_s_pitch_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_yaw_k1 s_pitch_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_pitch_t_lim_type arg)
  {
    msg_.s_pitch_t_lim = std::move(arg);
    return Init_RobustCtrlPara_s_yaw_k1(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_pitch_k2
{
public:
  explicit Init_RobustCtrlPara_s_pitch_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_pitch_t_lim s_pitch_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_pitch_k2_type arg)
  {
    msg_.s_pitch_k2 = std::move(arg);
    return Init_RobustCtrlPara_s_pitch_t_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_pitch_k1
{
public:
  explicit Init_RobustCtrlPara_s_pitch_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_pitch_k2 s_pitch_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_pitch_k1_type arg)
  {
    msg_.s_pitch_k1 = std::move(arg);
    return Init_RobustCtrlPara_s_pitch_k2(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_roll_t_lim
{
public:
  explicit Init_RobustCtrlPara_s_roll_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_pitch_k1 s_roll_t_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_roll_t_lim_type arg)
  {
    msg_.s_roll_t_lim = std::move(arg);
    return Init_RobustCtrlPara_s_pitch_k1(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_roll_k2
{
public:
  explicit Init_RobustCtrlPara_s_roll_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_roll_t_lim s_roll_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_roll_k2_type arg)
  {
    msg_.s_roll_k2 = std::move(arg);
    return Init_RobustCtrlPara_s_roll_t_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_roll_k1
{
public:
  explicit Init_RobustCtrlPara_s_roll_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_roll_k2 s_roll_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_roll_k1_type arg)
  {
    msg_.s_roll_k1 = std::move(arg);
    return Init_RobustCtrlPara_s_roll_k2(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_z_f_lim
{
public:
  explicit Init_RobustCtrlPara_s_z_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_roll_k1 s_z_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_z_f_lim_type arg)
  {
    msg_.s_z_f_lim = std::move(arg);
    return Init_RobustCtrlPara_s_roll_k1(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_z_k2
{
public:
  explicit Init_RobustCtrlPara_s_z_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_z_f_lim s_z_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_z_k2_type arg)
  {
    msg_.s_z_k2 = std::move(arg);
    return Init_RobustCtrlPara_s_z_f_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_z_k1
{
public:
  explicit Init_RobustCtrlPara_s_z_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_z_k2 s_z_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_z_k1_type arg)
  {
    msg_.s_z_k1 = std::move(arg);
    return Init_RobustCtrlPara_s_z_k2(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_y_f_lim
{
public:
  explicit Init_RobustCtrlPara_s_y_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_z_k1 s_y_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_y_f_lim_type arg)
  {
    msg_.s_y_f_lim = std::move(arg);
    return Init_RobustCtrlPara_s_z_k1(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_y_k2
{
public:
  explicit Init_RobustCtrlPara_s_y_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_y_f_lim s_y_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_y_k2_type arg)
  {
    msg_.s_y_k2 = std::move(arg);
    return Init_RobustCtrlPara_s_y_f_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_y_k1
{
public:
  explicit Init_RobustCtrlPara_s_y_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_y_k2 s_y_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_y_k1_type arg)
  {
    msg_.s_y_k1 = std::move(arg);
    return Init_RobustCtrlPara_s_y_k2(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_x_f_lim
{
public:
  explicit Init_RobustCtrlPara_s_x_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_y_k1 s_x_f_lim(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_x_f_lim_type arg)
  {
    msg_.s_x_f_lim = std::move(arg);
    return Init_RobustCtrlPara_s_y_k1(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_x_k2
{
public:
  explicit Init_RobustCtrlPara_s_x_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_x_f_lim s_x_k2(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_x_k2_type arg)
  {
    msg_.s_x_k2 = std::move(arg);
    return Init_RobustCtrlPara_s_x_f_lim(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_s_x_k1
{
public:
  explicit Init_RobustCtrlPara_s_x_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
  : msg_(msg)
  {}
  Init_RobustCtrlPara_s_x_k2 s_x_k1(::phd_master_slave_interfaces::msg::RobustCtrlPara::_s_x_k1_type arg)
  {
    msg_.s_x_k1 = std::move(arg);
    return Init_RobustCtrlPara_s_x_k2(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

class Init_RobustCtrlPara_robust_mode
{
public:
  Init_RobustCtrlPara_robust_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobustCtrlPara_s_x_k1 robust_mode(::phd_master_slave_interfaces::msg::RobustCtrlPara::_robust_mode_type arg)
  {
    msg_.robust_mode = std::move(arg);
    return Init_RobustCtrlPara_s_x_k1(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::RobustCtrlPara msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::phd_master_slave_interfaces::msg::RobustCtrlPara>()
{
  return phd_master_slave_interfaces::msg::builder::Init_RobustCtrlPara_robust_mode();
}

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__BUILDER_HPP_
