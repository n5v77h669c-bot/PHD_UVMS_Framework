// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from phd_master_slave_interfaces:msg/MtiImu.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__STRUCT_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__phd_master_slave_interfaces__msg__MtiImu __attribute__((deprecated))
#else
# define DEPRECATED__phd_master_slave_interfaces__msg__MtiImu __declspec(deprecated)
#endif

namespace phd_master_slave_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MtiImu_
{
  using Type = MtiImu_<ContainerAllocator>;

  explicit MtiImu_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->roll = 0.0f;
      this->pitch = 0.0f;
      this->yaw = 0.0f;
      this->q0 = 0.0f;
      this->q1 = 0.0f;
      this->q2 = 0.0f;
      this->q3 = 0.0f;
      this->accel_x = 0.0f;
      this->accel_y = 0.0f;
      this->accel_z = 0.0f;
      this->gyro_x = 0.0f;
      this->gyro_y = 0.0f;
      this->gyro_z = 0.0f;
      this->mag_x = 0.0f;
      this->mag_y = 0.0f;
      this->mag_z = 0.0f;
      this->temp_imu = 0.0f;
      this->data_source = 0;
      this->data_valid = false;
      this->vel_x = 0.0f;
      this->vel_y = 0.0f;
      this->vel_z = 0.0f;
      this->pos_x = 0.0f;
      this->pos_y = 0.0f;
      this->pos_z = 0.0f;
    }
  }

  explicit MtiImu_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->roll = 0.0f;
      this->pitch = 0.0f;
      this->yaw = 0.0f;
      this->q0 = 0.0f;
      this->q1 = 0.0f;
      this->q2 = 0.0f;
      this->q3 = 0.0f;
      this->accel_x = 0.0f;
      this->accel_y = 0.0f;
      this->accel_z = 0.0f;
      this->gyro_x = 0.0f;
      this->gyro_y = 0.0f;
      this->gyro_z = 0.0f;
      this->mag_x = 0.0f;
      this->mag_y = 0.0f;
      this->mag_z = 0.0f;
      this->temp_imu = 0.0f;
      this->data_source = 0;
      this->data_valid = false;
      this->vel_x = 0.0f;
      this->vel_y = 0.0f;
      this->vel_z = 0.0f;
      this->pos_x = 0.0f;
      this->pos_y = 0.0f;
      this->pos_z = 0.0f;
    }
  }

  // field types and members
  using _roll_type =
    float;
  _roll_type roll;
  using _pitch_type =
    float;
  _pitch_type pitch;
  using _yaw_type =
    float;
  _yaw_type yaw;
  using _q0_type =
    float;
  _q0_type q0;
  using _q1_type =
    float;
  _q1_type q1;
  using _q2_type =
    float;
  _q2_type q2;
  using _q3_type =
    float;
  _q3_type q3;
  using _accel_x_type =
    float;
  _accel_x_type accel_x;
  using _accel_y_type =
    float;
  _accel_y_type accel_y;
  using _accel_z_type =
    float;
  _accel_z_type accel_z;
  using _gyro_x_type =
    float;
  _gyro_x_type gyro_x;
  using _gyro_y_type =
    float;
  _gyro_y_type gyro_y;
  using _gyro_z_type =
    float;
  _gyro_z_type gyro_z;
  using _mag_x_type =
    float;
  _mag_x_type mag_x;
  using _mag_y_type =
    float;
  _mag_y_type mag_y;
  using _mag_z_type =
    float;
  _mag_z_type mag_z;
  using _temp_imu_type =
    float;
  _temp_imu_type temp_imu;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _data_source_type =
    uint8_t;
  _data_source_type data_source;
  using _data_valid_type =
    bool;
  _data_valid_type data_valid;
  using _vel_x_type =
    float;
  _vel_x_type vel_x;
  using _vel_y_type =
    float;
  _vel_y_type vel_y;
  using _vel_z_type =
    float;
  _vel_z_type vel_z;
  using _pos_x_type =
    float;
  _pos_x_type pos_x;
  using _pos_y_type =
    float;
  _pos_y_type pos_y;
  using _pos_z_type =
    float;
  _pos_z_type pos_z;

  // setters for named parameter idiom
  Type & set__roll(
    const float & _arg)
  {
    this->roll = _arg;
    return *this;
  }
  Type & set__pitch(
    const float & _arg)
  {
    this->pitch = _arg;
    return *this;
  }
  Type & set__yaw(
    const float & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__q0(
    const float & _arg)
  {
    this->q0 = _arg;
    return *this;
  }
  Type & set__q1(
    const float & _arg)
  {
    this->q1 = _arg;
    return *this;
  }
  Type & set__q2(
    const float & _arg)
  {
    this->q2 = _arg;
    return *this;
  }
  Type & set__q3(
    const float & _arg)
  {
    this->q3 = _arg;
    return *this;
  }
  Type & set__accel_x(
    const float & _arg)
  {
    this->accel_x = _arg;
    return *this;
  }
  Type & set__accel_y(
    const float & _arg)
  {
    this->accel_y = _arg;
    return *this;
  }
  Type & set__accel_z(
    const float & _arg)
  {
    this->accel_z = _arg;
    return *this;
  }
  Type & set__gyro_x(
    const float & _arg)
  {
    this->gyro_x = _arg;
    return *this;
  }
  Type & set__gyro_y(
    const float & _arg)
  {
    this->gyro_y = _arg;
    return *this;
  }
  Type & set__gyro_z(
    const float & _arg)
  {
    this->gyro_z = _arg;
    return *this;
  }
  Type & set__mag_x(
    const float & _arg)
  {
    this->mag_x = _arg;
    return *this;
  }
  Type & set__mag_y(
    const float & _arg)
  {
    this->mag_y = _arg;
    return *this;
  }
  Type & set__mag_z(
    const float & _arg)
  {
    this->mag_z = _arg;
    return *this;
  }
  Type & set__temp_imu(
    const float & _arg)
  {
    this->temp_imu = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__data_source(
    const uint8_t & _arg)
  {
    this->data_source = _arg;
    return *this;
  }
  Type & set__data_valid(
    const bool & _arg)
  {
    this->data_valid = _arg;
    return *this;
  }
  Type & set__vel_x(
    const float & _arg)
  {
    this->vel_x = _arg;
    return *this;
  }
  Type & set__vel_y(
    const float & _arg)
  {
    this->vel_y = _arg;
    return *this;
  }
  Type & set__vel_z(
    const float & _arg)
  {
    this->vel_z = _arg;
    return *this;
  }
  Type & set__pos_x(
    const float & _arg)
  {
    this->pos_x = _arg;
    return *this;
  }
  Type & set__pos_y(
    const float & _arg)
  {
    this->pos_y = _arg;
    return *this;
  }
  Type & set__pos_z(
    const float & _arg)
  {
    this->pos_z = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator> *;
  using ConstRawPtr =
    const phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__phd_master_slave_interfaces__msg__MtiImu
    std::shared_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__phd_master_slave_interfaces__msg__MtiImu
    std::shared_ptr<phd_master_slave_interfaces::msg::MtiImu_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MtiImu_ & other) const
  {
    if (this->roll != other.roll) {
      return false;
    }
    if (this->pitch != other.pitch) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->q0 != other.q0) {
      return false;
    }
    if (this->q1 != other.q1) {
      return false;
    }
    if (this->q2 != other.q2) {
      return false;
    }
    if (this->q3 != other.q3) {
      return false;
    }
    if (this->accel_x != other.accel_x) {
      return false;
    }
    if (this->accel_y != other.accel_y) {
      return false;
    }
    if (this->accel_z != other.accel_z) {
      return false;
    }
    if (this->gyro_x != other.gyro_x) {
      return false;
    }
    if (this->gyro_y != other.gyro_y) {
      return false;
    }
    if (this->gyro_z != other.gyro_z) {
      return false;
    }
    if (this->mag_x != other.mag_x) {
      return false;
    }
    if (this->mag_y != other.mag_y) {
      return false;
    }
    if (this->mag_z != other.mag_z) {
      return false;
    }
    if (this->temp_imu != other.temp_imu) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->data_source != other.data_source) {
      return false;
    }
    if (this->data_valid != other.data_valid) {
      return false;
    }
    if (this->vel_x != other.vel_x) {
      return false;
    }
    if (this->vel_y != other.vel_y) {
      return false;
    }
    if (this->vel_z != other.vel_z) {
      return false;
    }
    if (this->pos_x != other.pos_x) {
      return false;
    }
    if (this->pos_y != other.pos_y) {
      return false;
    }
    if (this->pos_z != other.pos_z) {
      return false;
    }
    return true;
  }
  bool operator!=(const MtiImu_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MtiImu_

// alias to use template instance with default allocator
using MtiImu =
  phd_master_slave_interfaces::msg::MtiImu_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__STRUCT_HPP_
