// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
// generated code does not contain a copyright notice
#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
phd_master_slave_interfaces__msg__RobustCtrlPara__init(phd_master_slave_interfaces__msg__RobustCtrlPara * msg)
{
  if (!msg) {
    return false;
  }
  // robust_mode
  // s_x_k1
  // s_x_k2
  // s_x_f_lim
  // s_y_k1
  // s_y_k2
  // s_y_f_lim
  // s_z_k1
  // s_z_k2
  // s_z_f_lim
  // s_roll_k1
  // s_roll_k2
  // s_roll_t_lim
  // s_pitch_k1
  // s_pitch_k2
  // s_pitch_t_lim
  // s_yaw_k1
  // s_yaw_k2
  // s_yaw_t_lim
  // p_x_kp
  // p_x_ki
  // p_x_kd
  // p_x_f_lim
  // p_y_kp
  // p_y_ki
  // p_y_kd
  // p_y_f_lim
  // p_z_kp
  // p_z_ki
  // p_z_kd
  // p_z_f_lim
  // p_roll_kp
  // p_roll_ki
  // p_roll_kd
  // p_roll_t_lim
  // p_pitch_kp
  // p_pitch_ki
  // p_pitch_kd
  // p_pitch_t_lim
  // p_yaw_kp
  // p_yaw_ki
  // p_yaw_kd
  // p_yaw_t_lim
  // data_valid
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    phd_master_slave_interfaces__msg__RobustCtrlPara__fini(msg);
    return false;
  }
  return true;
}

void
phd_master_slave_interfaces__msg__RobustCtrlPara__fini(phd_master_slave_interfaces__msg__RobustCtrlPara * msg)
{
  if (!msg) {
    return;
  }
  // robust_mode
  // s_x_k1
  // s_x_k2
  // s_x_f_lim
  // s_y_k1
  // s_y_k2
  // s_y_f_lim
  // s_z_k1
  // s_z_k2
  // s_z_f_lim
  // s_roll_k1
  // s_roll_k2
  // s_roll_t_lim
  // s_pitch_k1
  // s_pitch_k2
  // s_pitch_t_lim
  // s_yaw_k1
  // s_yaw_k2
  // s_yaw_t_lim
  // p_x_kp
  // p_x_ki
  // p_x_kd
  // p_x_f_lim
  // p_y_kp
  // p_y_ki
  // p_y_kd
  // p_y_f_lim
  // p_z_kp
  // p_z_ki
  // p_z_kd
  // p_z_f_lim
  // p_roll_kp
  // p_roll_ki
  // p_roll_kd
  // p_roll_t_lim
  // p_pitch_kp
  // p_pitch_ki
  // p_pitch_kd
  // p_pitch_t_lim
  // p_yaw_kp
  // p_yaw_ki
  // p_yaw_kd
  // p_yaw_t_lim
  // data_valid
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
}

bool
phd_master_slave_interfaces__msg__RobustCtrlPara__are_equal(const phd_master_slave_interfaces__msg__RobustCtrlPara * lhs, const phd_master_slave_interfaces__msg__RobustCtrlPara * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // robust_mode
  if (lhs->robust_mode != rhs->robust_mode) {
    return false;
  }
  // s_x_k1
  if (lhs->s_x_k1 != rhs->s_x_k1) {
    return false;
  }
  // s_x_k2
  if (lhs->s_x_k2 != rhs->s_x_k2) {
    return false;
  }
  // s_x_f_lim
  if (lhs->s_x_f_lim != rhs->s_x_f_lim) {
    return false;
  }
  // s_y_k1
  if (lhs->s_y_k1 != rhs->s_y_k1) {
    return false;
  }
  // s_y_k2
  if (lhs->s_y_k2 != rhs->s_y_k2) {
    return false;
  }
  // s_y_f_lim
  if (lhs->s_y_f_lim != rhs->s_y_f_lim) {
    return false;
  }
  // s_z_k1
  if (lhs->s_z_k1 != rhs->s_z_k1) {
    return false;
  }
  // s_z_k2
  if (lhs->s_z_k2 != rhs->s_z_k2) {
    return false;
  }
  // s_z_f_lim
  if (lhs->s_z_f_lim != rhs->s_z_f_lim) {
    return false;
  }
  // s_roll_k1
  if (lhs->s_roll_k1 != rhs->s_roll_k1) {
    return false;
  }
  // s_roll_k2
  if (lhs->s_roll_k2 != rhs->s_roll_k2) {
    return false;
  }
  // s_roll_t_lim
  if (lhs->s_roll_t_lim != rhs->s_roll_t_lim) {
    return false;
  }
  // s_pitch_k1
  if (lhs->s_pitch_k1 != rhs->s_pitch_k1) {
    return false;
  }
  // s_pitch_k2
  if (lhs->s_pitch_k2 != rhs->s_pitch_k2) {
    return false;
  }
  // s_pitch_t_lim
  if (lhs->s_pitch_t_lim != rhs->s_pitch_t_lim) {
    return false;
  }
  // s_yaw_k1
  if (lhs->s_yaw_k1 != rhs->s_yaw_k1) {
    return false;
  }
  // s_yaw_k2
  if (lhs->s_yaw_k2 != rhs->s_yaw_k2) {
    return false;
  }
  // s_yaw_t_lim
  if (lhs->s_yaw_t_lim != rhs->s_yaw_t_lim) {
    return false;
  }
  // p_x_kp
  if (lhs->p_x_kp != rhs->p_x_kp) {
    return false;
  }
  // p_x_ki
  if (lhs->p_x_ki != rhs->p_x_ki) {
    return false;
  }
  // p_x_kd
  if (lhs->p_x_kd != rhs->p_x_kd) {
    return false;
  }
  // p_x_f_lim
  if (lhs->p_x_f_lim != rhs->p_x_f_lim) {
    return false;
  }
  // p_y_kp
  if (lhs->p_y_kp != rhs->p_y_kp) {
    return false;
  }
  // p_y_ki
  if (lhs->p_y_ki != rhs->p_y_ki) {
    return false;
  }
  // p_y_kd
  if (lhs->p_y_kd != rhs->p_y_kd) {
    return false;
  }
  // p_y_f_lim
  if (lhs->p_y_f_lim != rhs->p_y_f_lim) {
    return false;
  }
  // p_z_kp
  if (lhs->p_z_kp != rhs->p_z_kp) {
    return false;
  }
  // p_z_ki
  if (lhs->p_z_ki != rhs->p_z_ki) {
    return false;
  }
  // p_z_kd
  if (lhs->p_z_kd != rhs->p_z_kd) {
    return false;
  }
  // p_z_f_lim
  if (lhs->p_z_f_lim != rhs->p_z_f_lim) {
    return false;
  }
  // p_roll_kp
  if (lhs->p_roll_kp != rhs->p_roll_kp) {
    return false;
  }
  // p_roll_ki
  if (lhs->p_roll_ki != rhs->p_roll_ki) {
    return false;
  }
  // p_roll_kd
  if (lhs->p_roll_kd != rhs->p_roll_kd) {
    return false;
  }
  // p_roll_t_lim
  if (lhs->p_roll_t_lim != rhs->p_roll_t_lim) {
    return false;
  }
  // p_pitch_kp
  if (lhs->p_pitch_kp != rhs->p_pitch_kp) {
    return false;
  }
  // p_pitch_ki
  if (lhs->p_pitch_ki != rhs->p_pitch_ki) {
    return false;
  }
  // p_pitch_kd
  if (lhs->p_pitch_kd != rhs->p_pitch_kd) {
    return false;
  }
  // p_pitch_t_lim
  if (lhs->p_pitch_t_lim != rhs->p_pitch_t_lim) {
    return false;
  }
  // p_yaw_kp
  if (lhs->p_yaw_kp != rhs->p_yaw_kp) {
    return false;
  }
  // p_yaw_ki
  if (lhs->p_yaw_ki != rhs->p_yaw_ki) {
    return false;
  }
  // p_yaw_kd
  if (lhs->p_yaw_kd != rhs->p_yaw_kd) {
    return false;
  }
  // p_yaw_t_lim
  if (lhs->p_yaw_t_lim != rhs->p_yaw_t_lim) {
    return false;
  }
  // data_valid
  if (lhs->data_valid != rhs->data_valid) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__RobustCtrlPara__copy(
  const phd_master_slave_interfaces__msg__RobustCtrlPara * input,
  phd_master_slave_interfaces__msg__RobustCtrlPara * output)
{
  if (!input || !output) {
    return false;
  }
  // robust_mode
  output->robust_mode = input->robust_mode;
  // s_x_k1
  output->s_x_k1 = input->s_x_k1;
  // s_x_k2
  output->s_x_k2 = input->s_x_k2;
  // s_x_f_lim
  output->s_x_f_lim = input->s_x_f_lim;
  // s_y_k1
  output->s_y_k1 = input->s_y_k1;
  // s_y_k2
  output->s_y_k2 = input->s_y_k2;
  // s_y_f_lim
  output->s_y_f_lim = input->s_y_f_lim;
  // s_z_k1
  output->s_z_k1 = input->s_z_k1;
  // s_z_k2
  output->s_z_k2 = input->s_z_k2;
  // s_z_f_lim
  output->s_z_f_lim = input->s_z_f_lim;
  // s_roll_k1
  output->s_roll_k1 = input->s_roll_k1;
  // s_roll_k2
  output->s_roll_k2 = input->s_roll_k2;
  // s_roll_t_lim
  output->s_roll_t_lim = input->s_roll_t_lim;
  // s_pitch_k1
  output->s_pitch_k1 = input->s_pitch_k1;
  // s_pitch_k2
  output->s_pitch_k2 = input->s_pitch_k2;
  // s_pitch_t_lim
  output->s_pitch_t_lim = input->s_pitch_t_lim;
  // s_yaw_k1
  output->s_yaw_k1 = input->s_yaw_k1;
  // s_yaw_k2
  output->s_yaw_k2 = input->s_yaw_k2;
  // s_yaw_t_lim
  output->s_yaw_t_lim = input->s_yaw_t_lim;
  // p_x_kp
  output->p_x_kp = input->p_x_kp;
  // p_x_ki
  output->p_x_ki = input->p_x_ki;
  // p_x_kd
  output->p_x_kd = input->p_x_kd;
  // p_x_f_lim
  output->p_x_f_lim = input->p_x_f_lim;
  // p_y_kp
  output->p_y_kp = input->p_y_kp;
  // p_y_ki
  output->p_y_ki = input->p_y_ki;
  // p_y_kd
  output->p_y_kd = input->p_y_kd;
  // p_y_f_lim
  output->p_y_f_lim = input->p_y_f_lim;
  // p_z_kp
  output->p_z_kp = input->p_z_kp;
  // p_z_ki
  output->p_z_ki = input->p_z_ki;
  // p_z_kd
  output->p_z_kd = input->p_z_kd;
  // p_z_f_lim
  output->p_z_f_lim = input->p_z_f_lim;
  // p_roll_kp
  output->p_roll_kp = input->p_roll_kp;
  // p_roll_ki
  output->p_roll_ki = input->p_roll_ki;
  // p_roll_kd
  output->p_roll_kd = input->p_roll_kd;
  // p_roll_t_lim
  output->p_roll_t_lim = input->p_roll_t_lim;
  // p_pitch_kp
  output->p_pitch_kp = input->p_pitch_kp;
  // p_pitch_ki
  output->p_pitch_ki = input->p_pitch_ki;
  // p_pitch_kd
  output->p_pitch_kd = input->p_pitch_kd;
  // p_pitch_t_lim
  output->p_pitch_t_lim = input->p_pitch_t_lim;
  // p_yaw_kp
  output->p_yaw_kp = input->p_yaw_kp;
  // p_yaw_ki
  output->p_yaw_ki = input->p_yaw_ki;
  // p_yaw_kd
  output->p_yaw_kd = input->p_yaw_kd;
  // p_yaw_t_lim
  output->p_yaw_t_lim = input->p_yaw_t_lim;
  // data_valid
  output->data_valid = input->data_valid;
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  return true;
}

phd_master_slave_interfaces__msg__RobustCtrlPara *
phd_master_slave_interfaces__msg__RobustCtrlPara__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__RobustCtrlPara * msg = (phd_master_slave_interfaces__msg__RobustCtrlPara *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__RobustCtrlPara), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(phd_master_slave_interfaces__msg__RobustCtrlPara));
  bool success = phd_master_slave_interfaces__msg__RobustCtrlPara__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
phd_master_slave_interfaces__msg__RobustCtrlPara__destroy(phd_master_slave_interfaces__msg__RobustCtrlPara * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    phd_master_slave_interfaces__msg__RobustCtrlPara__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__init(phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__RobustCtrlPara * data = NULL;

  if (size) {
    data = (phd_master_slave_interfaces__msg__RobustCtrlPara *)allocator.zero_allocate(size, sizeof(phd_master_slave_interfaces__msg__RobustCtrlPara), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = phd_master_slave_interfaces__msg__RobustCtrlPara__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        phd_master_slave_interfaces__msg__RobustCtrlPara__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__fini(phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      phd_master_slave_interfaces__msg__RobustCtrlPara__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence *
phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * array = (phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__destroy(phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__are_equal(const phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * lhs, const phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!phd_master_slave_interfaces__msg__RobustCtrlPara__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence__copy(
  const phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * input,
  phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(phd_master_slave_interfaces__msg__RobustCtrlPara);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    phd_master_slave_interfaces__msg__RobustCtrlPara * data =
      (phd_master_slave_interfaces__msg__RobustCtrlPara *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!phd_master_slave_interfaces__msg__RobustCtrlPara__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          phd_master_slave_interfaces__msg__RobustCtrlPara__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!phd_master_slave_interfaces__msg__RobustCtrlPara__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
