// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from phd_master_slave_interfaces:msg/Depth.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__BUILDER_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "phd_master_slave_interfaces/msg/detail/depth__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace phd_master_slave_interfaces
{

namespace msg
{

namespace builder
{

class Init_Depth_timestamp
{
public:
  explicit Init_Depth_timestamp(::phd_master_slave_interfaces::msg::Depth & msg)
  : msg_(msg)
  {}
  ::phd_master_slave_interfaces::msg::Depth timestamp(::phd_master_slave_interfaces::msg::Depth::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::Depth msg_;
};

class Init_Depth_temp_water
{
public:
  explicit Init_Depth_temp_water(::phd_master_slave_interfaces::msg::Depth & msg)
  : msg_(msg)
  {}
  Init_Depth_timestamp temp_water(::phd_master_slave_interfaces::msg::Depth::_temp_water_type arg)
  {
    msg_.temp_water = std::move(arg);
    return Init_Depth_timestamp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::Depth msg_;
};

class Init_Depth_depth
{
public:
  Init_Depth_depth()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Depth_temp_water depth(::phd_master_slave_interfaces::msg::Depth::_depth_type arg)
  {
    msg_.depth = std::move(arg);
    return Init_Depth_temp_water(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::Depth msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::phd_master_slave_interfaces::msg::Depth>()
{
  return phd_master_slave_interfaces::msg::builder::Init_Depth_depth();
}

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__BUILDER_HPP_
