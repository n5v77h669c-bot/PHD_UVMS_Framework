// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__TRAITS_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace phd_master_slave_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const RobustCtrlPara & msg,
  std::ostream & out)
{
  out << "{";
  // member: robust_mode
  {
    out << "robust_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.robust_mode, out);
    out << ", ";
  }

  // member: s_x_k1
  {
    out << "s_x_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_x_k1, out);
    out << ", ";
  }

  // member: s_x_k2
  {
    out << "s_x_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_x_k2, out);
    out << ", ";
  }

  // member: s_x_f_lim
  {
    out << "s_x_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_x_f_lim, out);
    out << ", ";
  }

  // member: s_y_k1
  {
    out << "s_y_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_y_k1, out);
    out << ", ";
  }

  // member: s_y_k2
  {
    out << "s_y_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_y_k2, out);
    out << ", ";
  }

  // member: s_y_f_lim
  {
    out << "s_y_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_y_f_lim, out);
    out << ", ";
  }

  // member: s_z_k1
  {
    out << "s_z_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_z_k1, out);
    out << ", ";
  }

  // member: s_z_k2
  {
    out << "s_z_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_z_k2, out);
    out << ", ";
  }

  // member: s_z_f_lim
  {
    out << "s_z_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_z_f_lim, out);
    out << ", ";
  }

  // member: s_roll_k1
  {
    out << "s_roll_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_roll_k1, out);
    out << ", ";
  }

  // member: s_roll_k2
  {
    out << "s_roll_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_roll_k2, out);
    out << ", ";
  }

  // member: s_roll_t_lim
  {
    out << "s_roll_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_roll_t_lim, out);
    out << ", ";
  }

  // member: s_pitch_k1
  {
    out << "s_pitch_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_pitch_k1, out);
    out << ", ";
  }

  // member: s_pitch_k2
  {
    out << "s_pitch_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_pitch_k2, out);
    out << ", ";
  }

  // member: s_pitch_t_lim
  {
    out << "s_pitch_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_pitch_t_lim, out);
    out << ", ";
  }

  // member: s_yaw_k1
  {
    out << "s_yaw_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_yaw_k1, out);
    out << ", ";
  }

  // member: s_yaw_k2
  {
    out << "s_yaw_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_yaw_k2, out);
    out << ", ";
  }

  // member: s_yaw_t_lim
  {
    out << "s_yaw_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_yaw_t_lim, out);
    out << ", ";
  }

  // member: p_x_kp
  {
    out << "p_x_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_kp, out);
    out << ", ";
  }

  // member: p_x_ki
  {
    out << "p_x_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_ki, out);
    out << ", ";
  }

  // member: p_x_kd
  {
    out << "p_x_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_kd, out);
    out << ", ";
  }

  // member: p_x_f_lim
  {
    out << "p_x_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_f_lim, out);
    out << ", ";
  }

  // member: p_y_kp
  {
    out << "p_y_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_kp, out);
    out << ", ";
  }

  // member: p_y_ki
  {
    out << "p_y_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_ki, out);
    out << ", ";
  }

  // member: p_y_kd
  {
    out << "p_y_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_kd, out);
    out << ", ";
  }

  // member: p_y_f_lim
  {
    out << "p_y_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_f_lim, out);
    out << ", ";
  }

  // member: p_z_kp
  {
    out << "p_z_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_kp, out);
    out << ", ";
  }

  // member: p_z_ki
  {
    out << "p_z_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_ki, out);
    out << ", ";
  }

  // member: p_z_kd
  {
    out << "p_z_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_kd, out);
    out << ", ";
  }

  // member: p_z_f_lim
  {
    out << "p_z_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_f_lim, out);
    out << ", ";
  }

  // member: p_roll_kp
  {
    out << "p_roll_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_kp, out);
    out << ", ";
  }

  // member: p_roll_ki
  {
    out << "p_roll_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_ki, out);
    out << ", ";
  }

  // member: p_roll_kd
  {
    out << "p_roll_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_kd, out);
    out << ", ";
  }

  // member: p_roll_t_lim
  {
    out << "p_roll_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_t_lim, out);
    out << ", ";
  }

  // member: p_pitch_kp
  {
    out << "p_pitch_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_kp, out);
    out << ", ";
  }

  // member: p_pitch_ki
  {
    out << "p_pitch_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_ki, out);
    out << ", ";
  }

  // member: p_pitch_kd
  {
    out << "p_pitch_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_kd, out);
    out << ", ";
  }

  // member: p_pitch_t_lim
  {
    out << "p_pitch_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_t_lim, out);
    out << ", ";
  }

  // member: p_yaw_kp
  {
    out << "p_yaw_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_kp, out);
    out << ", ";
  }

  // member: p_yaw_ki
  {
    out << "p_yaw_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_ki, out);
    out << ", ";
  }

  // member: p_yaw_kd
  {
    out << "p_yaw_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_kd, out);
    out << ", ";
  }

  // member: p_yaw_t_lim
  {
    out << "p_yaw_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_t_lim, out);
    out << ", ";
  }

  // member: data_valid
  {
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RobustCtrlPara & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: robust_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "robust_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.robust_mode, out);
    out << "\n";
  }

  // member: s_x_k1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_x_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_x_k1, out);
    out << "\n";
  }

  // member: s_x_k2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_x_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_x_k2, out);
    out << "\n";
  }

  // member: s_x_f_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_x_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_x_f_lim, out);
    out << "\n";
  }

  // member: s_y_k1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_y_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_y_k1, out);
    out << "\n";
  }

  // member: s_y_k2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_y_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_y_k2, out);
    out << "\n";
  }

  // member: s_y_f_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_y_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_y_f_lim, out);
    out << "\n";
  }

  // member: s_z_k1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_z_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_z_k1, out);
    out << "\n";
  }

  // member: s_z_k2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_z_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_z_k2, out);
    out << "\n";
  }

  // member: s_z_f_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_z_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_z_f_lim, out);
    out << "\n";
  }

  // member: s_roll_k1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_roll_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_roll_k1, out);
    out << "\n";
  }

  // member: s_roll_k2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_roll_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_roll_k2, out);
    out << "\n";
  }

  // member: s_roll_t_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_roll_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_roll_t_lim, out);
    out << "\n";
  }

  // member: s_pitch_k1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_pitch_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_pitch_k1, out);
    out << "\n";
  }

  // member: s_pitch_k2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_pitch_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_pitch_k2, out);
    out << "\n";
  }

  // member: s_pitch_t_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_pitch_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_pitch_t_lim, out);
    out << "\n";
  }

  // member: s_yaw_k1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_yaw_k1: ";
    rosidl_generator_traits::value_to_yaml(msg.s_yaw_k1, out);
    out << "\n";
  }

  // member: s_yaw_k2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_yaw_k2: ";
    rosidl_generator_traits::value_to_yaml(msg.s_yaw_k2, out);
    out << "\n";
  }

  // member: s_yaw_t_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "s_yaw_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.s_yaw_t_lim, out);
    out << "\n";
  }

  // member: p_x_kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_x_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_kp, out);
    out << "\n";
  }

  // member: p_x_ki
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_x_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_ki, out);
    out << "\n";
  }

  // member: p_x_kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_x_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_kd, out);
    out << "\n";
  }

  // member: p_x_f_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_x_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_x_f_lim, out);
    out << "\n";
  }

  // member: p_y_kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_y_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_kp, out);
    out << "\n";
  }

  // member: p_y_ki
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_y_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_ki, out);
    out << "\n";
  }

  // member: p_y_kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_y_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_kd, out);
    out << "\n";
  }

  // member: p_y_f_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_y_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_y_f_lim, out);
    out << "\n";
  }

  // member: p_z_kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_z_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_kp, out);
    out << "\n";
  }

  // member: p_z_ki
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_z_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_ki, out);
    out << "\n";
  }

  // member: p_z_kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_z_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_kd, out);
    out << "\n";
  }

  // member: p_z_f_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_z_f_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_z_f_lim, out);
    out << "\n";
  }

  // member: p_roll_kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_roll_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_kp, out);
    out << "\n";
  }

  // member: p_roll_ki
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_roll_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_ki, out);
    out << "\n";
  }

  // member: p_roll_kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_roll_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_kd, out);
    out << "\n";
  }

  // member: p_roll_t_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_roll_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_roll_t_lim, out);
    out << "\n";
  }

  // member: p_pitch_kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_pitch_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_kp, out);
    out << "\n";
  }

  // member: p_pitch_ki
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_pitch_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_ki, out);
    out << "\n";
  }

  // member: p_pitch_kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_pitch_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_kd, out);
    out << "\n";
  }

  // member: p_pitch_t_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_pitch_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_pitch_t_lim, out);
    out << "\n";
  }

  // member: p_yaw_kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_yaw_kp: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_kp, out);
    out << "\n";
  }

  // member: p_yaw_ki
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_yaw_ki: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_ki, out);
    out << "\n";
  }

  // member: p_yaw_kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_yaw_kd: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_kd, out);
    out << "\n";
  }

  // member: p_yaw_t_lim
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "p_yaw_t_lim: ";
    rosidl_generator_traits::value_to_yaml(msg.p_yaw_t_lim, out);
    out << "\n";
  }

  // member: data_valid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RobustCtrlPara & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace phd_master_slave_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use phd_master_slave_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const phd_master_slave_interfaces::msg::RobustCtrlPara & msg,
  std::ostream & out, size_t indentation = 0)
{
  phd_master_slave_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use phd_master_slave_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const phd_master_slave_interfaces::msg::RobustCtrlPara & msg)
{
  return phd_master_slave_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<phd_master_slave_interfaces::msg::RobustCtrlPara>()
{
  return "phd_master_slave_interfaces::msg::RobustCtrlPara";
}

template<>
inline const char * name<phd_master_slave_interfaces::msg::RobustCtrlPara>()
{
  return "phd_master_slave_interfaces/msg/RobustCtrlPara";
}

template<>
struct has_fixed_size<phd_master_slave_interfaces::msg::RobustCtrlPara>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<phd_master_slave_interfaces::msg::RobustCtrlPara>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<phd_master_slave_interfaces::msg::RobustCtrlPara>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__TRAITS_HPP_
