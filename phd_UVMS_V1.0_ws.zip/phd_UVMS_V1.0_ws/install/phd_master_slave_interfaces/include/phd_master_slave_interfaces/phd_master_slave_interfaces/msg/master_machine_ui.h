// generated from rosidl_generator_c/resource/idl.h.em
// with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__MASTER_MACHINE_UI_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__MASTER_MACHINE_UI_H_

#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__struct.h"
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__functions.h"
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__type_support.h"

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__MASTER_MACHINE_UI_H_
