// generated from rosidl_generator_c/resource/idl.h.em
// with input from phd_master_slave_interfaces:msg/Depth.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DEPTH_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DEPTH_H_

#include "phd_master_slave_interfaces/msg/detail/depth__struct.h"
#include "phd_master_slave_interfaces/msg/detail/depth__functions.h"
#include "phd_master_slave_interfaces/msg/detail/depth__type_support.h"

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DEPTH_H_
