// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__BUILDER_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "phd_master_slave_interfaces/msg/detail/thruster_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace phd_master_slave_interfaces
{

namespace msg
{

namespace builder
{

class Init_ThrusterStatus_temperature
{
public:
  explicit Init_ThrusterStatus_temperature(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  ::phd_master_slave_interfaces::msg::ThrusterStatus temperature(::phd_master_slave_interfaces::msg::ThrusterStatus::_temperature_type arg)
  {
    msg_.temperature = std::move(arg);
    return std::move(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_data_valid
{
public:
  explicit Init_ThrusterStatus_data_valid(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_temperature data_valid(::phd_master_slave_interfaces::msg::ThrusterStatus::_data_valid_type arg)
  {
    msg_.data_valid = std::move(arg);
    return Init_ThrusterStatus_temperature(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_rbd
{
public:
  explicit Init_ThrusterStatus_actual_power_rbd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_data_valid actual_power_rbd(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_rbd_type arg)
  {
    msg_.actual_power_rbd = std::move(arg);
    return Init_ThrusterStatus_data_valid(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_rbu
{
public:
  explicit Init_ThrusterStatus_actual_power_rbu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_rbd actual_power_rbu(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_rbu_type arg)
  {
    msg_.actual_power_rbu = std::move(arg);
    return Init_ThrusterStatus_actual_power_rbd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_lbd
{
public:
  explicit Init_ThrusterStatus_actual_power_lbd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_rbu actual_power_lbd(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_lbd_type arg)
  {
    msg_.actual_power_lbd = std::move(arg);
    return Init_ThrusterStatus_actual_power_rbu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_lbu
{
public:
  explicit Init_ThrusterStatus_actual_power_lbu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_lbd actual_power_lbu(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_lbu_type arg)
  {
    msg_.actual_power_lbu = std::move(arg);
    return Init_ThrusterStatus_actual_power_lbd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_rfd
{
public:
  explicit Init_ThrusterStatus_actual_power_rfd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_lbu actual_power_rfd(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_rfd_type arg)
  {
    msg_.actual_power_rfd = std::move(arg);
    return Init_ThrusterStatus_actual_power_lbu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_rfu
{
public:
  explicit Init_ThrusterStatus_actual_power_rfu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_rfd actual_power_rfu(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_rfu_type arg)
  {
    msg_.actual_power_rfu = std::move(arg);
    return Init_ThrusterStatus_actual_power_rfd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_lfd
{
public:
  explicit Init_ThrusterStatus_actual_power_lfd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_rfu actual_power_lfd(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_lfd_type arg)
  {
    msg_.actual_power_lfd = std::move(arg);
    return Init_ThrusterStatus_actual_power_rfu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_actual_power_lfu
{
public:
  explicit Init_ThrusterStatus_actual_power_lfu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_lfd actual_power_lfu(::phd_master_slave_interfaces::msg::ThrusterStatus::_actual_power_lfu_type arg)
  {
    msg_.actual_power_lfu = std::move(arg);
    return Init_ThrusterStatus_actual_power_lfd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_rbd
{
public:
  explicit Init_ThrusterStatus_set_power_rbd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_actual_power_lfu set_power_rbd(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_rbd_type arg)
  {
    msg_.set_power_rbd = std::move(arg);
    return Init_ThrusterStatus_actual_power_lfu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_rbu
{
public:
  explicit Init_ThrusterStatus_set_power_rbu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_set_power_rbd set_power_rbu(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_rbu_type arg)
  {
    msg_.set_power_rbu = std::move(arg);
    return Init_ThrusterStatus_set_power_rbd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_lbd
{
public:
  explicit Init_ThrusterStatus_set_power_lbd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_set_power_rbu set_power_lbd(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_lbd_type arg)
  {
    msg_.set_power_lbd = std::move(arg);
    return Init_ThrusterStatus_set_power_rbu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_lbu
{
public:
  explicit Init_ThrusterStatus_set_power_lbu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_set_power_lbd set_power_lbu(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_lbu_type arg)
  {
    msg_.set_power_lbu = std::move(arg);
    return Init_ThrusterStatus_set_power_lbd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_rfd
{
public:
  explicit Init_ThrusterStatus_set_power_rfd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_set_power_lbu set_power_rfd(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_rfd_type arg)
  {
    msg_.set_power_rfd = std::move(arg);
    return Init_ThrusterStatus_set_power_lbu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_rfu
{
public:
  explicit Init_ThrusterStatus_set_power_rfu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_set_power_rfd set_power_rfu(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_rfu_type arg)
  {
    msg_.set_power_rfu = std::move(arg);
    return Init_ThrusterStatus_set_power_rfd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_lfd
{
public:
  explicit Init_ThrusterStatus_set_power_lfd(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_set_power_rfu set_power_lfd(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_lfd_type arg)
  {
    msg_.set_power_lfd = std::move(arg);
    return Init_ThrusterStatus_set_power_rfu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_set_power_lfu
{
public:
  explicit Init_ThrusterStatus_set_power_lfu(::phd_master_slave_interfaces::msg::ThrusterStatus & msg)
  : msg_(msg)
  {}
  Init_ThrusterStatus_set_power_lfd set_power_lfu(::phd_master_slave_interfaces::msg::ThrusterStatus::_set_power_lfu_type arg)
  {
    msg_.set_power_lfu = std::move(arg);
    return Init_ThrusterStatus_set_power_lfd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

class Init_ThrusterStatus_timestamp
{
public:
  Init_ThrusterStatus_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ThrusterStatus_set_power_lfu timestamp(::phd_master_slave_interfaces::msg::ThrusterStatus::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_ThrusterStatus_set_power_lfu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::ThrusterStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::phd_master_slave_interfaces::msg::ThrusterStatus>()
{
  return phd_master_slave_interfaces::msg::builder::Init_ThrusterStatus_timestamp();
}

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__BUILDER_HPP_
