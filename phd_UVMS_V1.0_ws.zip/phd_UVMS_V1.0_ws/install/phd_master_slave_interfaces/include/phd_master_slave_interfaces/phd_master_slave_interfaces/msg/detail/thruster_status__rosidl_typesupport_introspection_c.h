// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "phd_master_slave_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_phd_master_slave_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, phd_master_slave_interfaces, msg, ThrusterStatus)();

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
