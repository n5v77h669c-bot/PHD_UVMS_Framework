// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from phd_master_slave_interfaces:msg/SensorStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__TRAITS_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "phd_master_slave_interfaces/msg/detail/sensor_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace phd_master_slave_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const SensorStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: dvl_set_status
  {
    out << "dvl_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.dvl_set_status, out);
    out << ", ";
  }

  // member: light_set_status
  {
    out << "light_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.light_set_status, out);
    out << ", ";
  }

  // member: front_sonar_set_status
  {
    out << "front_sonar_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.front_sonar_set_status, out);
    out << ", ";
  }

  // member: scanning_sonar_set_status
  {
    out << "scanning_sonar_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.scanning_sonar_set_status, out);
    out << ", ";
  }

  // member: dvl_cur_status
  {
    out << "dvl_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.dvl_cur_status, out);
    out << ", ";
  }

  // member: light_cur_status
  {
    out << "light_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.light_cur_status, out);
    out << ", ";
  }

  // member: front_sonar_cur_status
  {
    out << "front_sonar_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.front_sonar_cur_status, out);
    out << ", ";
  }

  // member: scanning_sonar_cur_status
  {
    out << "scanning_sonar_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.scanning_sonar_cur_status, out);
    out << ", ";
  }

  // member: water_leak_status
  {
    out << "water_leak_status: ";
    rosidl_generator_traits::value_to_yaml(msg.water_leak_status, out);
    out << ", ";
  }

  // member: data_valid
  {
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SensorStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: dvl_set_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dvl_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.dvl_set_status, out);
    out << "\n";
  }

  // member: light_set_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "light_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.light_set_status, out);
    out << "\n";
  }

  // member: front_sonar_set_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "front_sonar_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.front_sonar_set_status, out);
    out << "\n";
  }

  // member: scanning_sonar_set_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "scanning_sonar_set_status: ";
    rosidl_generator_traits::value_to_yaml(msg.scanning_sonar_set_status, out);
    out << "\n";
  }

  // member: dvl_cur_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dvl_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.dvl_cur_status, out);
    out << "\n";
  }

  // member: light_cur_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "light_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.light_cur_status, out);
    out << "\n";
  }

  // member: front_sonar_cur_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "front_sonar_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.front_sonar_cur_status, out);
    out << "\n";
  }

  // member: scanning_sonar_cur_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "scanning_sonar_cur_status: ";
    rosidl_generator_traits::value_to_yaml(msg.scanning_sonar_cur_status, out);
    out << "\n";
  }

  // member: water_leak_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "water_leak_status: ";
    rosidl_generator_traits::value_to_yaml(msg.water_leak_status, out);
    out << "\n";
  }

  // member: data_valid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SensorStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace phd_master_slave_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use phd_master_slave_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const phd_master_slave_interfaces::msg::SensorStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  phd_master_slave_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use phd_master_slave_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const phd_master_slave_interfaces::msg::SensorStatus & msg)
{
  return phd_master_slave_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<phd_master_slave_interfaces::msg::SensorStatus>()
{
  return "phd_master_slave_interfaces::msg::SensorStatus";
}

template<>
inline const char * name<phd_master_slave_interfaces::msg::SensorStatus>()
{
  return "phd_master_slave_interfaces/msg/SensorStatus";
}

template<>
struct has_fixed_size<phd_master_slave_interfaces::msg::SensorStatus>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<phd_master_slave_interfaces::msg::SensorStatus>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<phd_master_slave_interfaces::msg::SensorStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__TRAITS_HPP_
