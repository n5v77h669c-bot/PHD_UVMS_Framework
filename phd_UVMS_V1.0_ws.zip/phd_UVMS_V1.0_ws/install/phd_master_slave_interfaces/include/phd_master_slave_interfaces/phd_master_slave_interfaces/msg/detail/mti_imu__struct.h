﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from phd_master_slave_interfaces:msg/MtiImu.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__STRUCT_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/MtiImu in the package phd_master_slave_interfaces.
/**
  * ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/MtiImu.msg
 */
typedef struct phd_master_slave_interfaces__msg__MtiImu
{
  /// ==================== 姿态数据 ====================
  /// 欧拉角 (度)
  float roll;
  float pitch;
  float yaw;
  /// 四元数 (w, x, y, z)
  float q0;
  float q1;
  float q2;
  float q3;
  /// ==================== 加速度计数据 ====================
  /// 线性加速度 (m/s²)
  float accel_x;
  float accel_y;
  float accel_z;
  /// ==================== 陀螺仪数据 ====================
  /// 角速度 (rad/s)
  float gyro_x;
  float gyro_y;
  float gyro_z;
  /// ==================== 磁力计数据 ====================
  /// 磁场强度 (任意单位)
  float mag_x;
  float mag_y;
  float mag_z;
  /// ==================== 传感器状态 ====================
  /// 温度 (°C)
  float temp_imu;
  /// ==================== 时间戳 ====================
  /// 系统时间 (秒)
  builtin_interfaces__msg__Time timestamp;
  /// ==================== 数据源标记 ====================
  /// 数据来源: 0=PRDID(只有姿态), 1=PSONCMS(完整数据)
  uint8_t data_source;
  /// ==================== 数据质量 ====================
  /// 有效性标记: 0=无效, 1=有效
  bool data_valid;
  /// ==================== 手动计算：积分速度 (m/s) ====================
  float vel_x;
  float vel_y;
  float vel_z;
  /// ==================== 手动计算：积分位置 (m) ====================
  float pos_x;
  float pos_y;
  float pos_z;
} phd_master_slave_interfaces__msg__MtiImu;

// Struct for a sequence of phd_master_slave_interfaces__msg__MtiImu.
typedef struct phd_master_slave_interfaces__msg__MtiImu__Sequence
{
  phd_master_slave_interfaces__msg__MtiImu * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} phd_master_slave_interfaces__msg__MtiImu__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__STRUCT_H_
