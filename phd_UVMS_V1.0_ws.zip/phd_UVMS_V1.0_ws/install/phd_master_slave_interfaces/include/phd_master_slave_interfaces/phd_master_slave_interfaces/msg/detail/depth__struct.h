﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from phd_master_slave_interfaces:msg/Depth.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__STRUCT_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/Depth in the package phd_master_slave_interfaces.
/**
  * ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/Depth.msg
 */
typedef struct phd_master_slave_interfaces__msg__Depth
{
  /// ==================== 深度计数据 ====================
  /// 深度 (米)
  double depth;
  /// 温度 (°C)
  double temp_water;
  /// ==================== 时间戳 ====================
  /// 系统时间 (秒)
  builtin_interfaces__msg__Time timestamp;
} phd_master_slave_interfaces__msg__Depth;

// Struct for a sequence of phd_master_slave_interfaces__msg__Depth.
typedef struct phd_master_slave_interfaces__msg__Depth__Sequence
{
  phd_master_slave_interfaces__msg__Depth * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} phd_master_slave_interfaces__msg__Depth__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__STRUCT_H_
