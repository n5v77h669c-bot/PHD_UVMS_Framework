﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__STRUCT_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/RobustCtrlPara in the package phd_master_slave_interfaces.
/**
  * ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/RobustCtrlPara.msg
  * ==================== 鲁棒控制器参数消息 ====================
  * 用于S面和PID控制器的参数配置
 */
typedef struct phd_master_slave_interfaces__msg__RobustCtrlPara
{
  /// ==================== 控制模式 ====================
  /// 0: S面控制, 1: PID控制, 2: 其他(待开发)
  uint8_t robust_mode;
  /// ==================== S面控制参数 ====================
  /// X方向 (Surge)
  float s_x_k1;
  float s_x_k2;
  float s_x_f_lim;
  /// Y方向 (Sway)
  float s_y_k1;
  float s_y_k2;
  float s_y_f_lim;
  /// Z方向 (Heave)
  float s_z_k1;
  float s_z_k2;
  float s_z_f_lim;
  /// Roll (横滚)
  float s_roll_k1;
  float s_roll_k2;
  float s_roll_t_lim;
  /// Pitch (俯仰)
  float s_pitch_k1;
  float s_pitch_k2;
  float s_pitch_t_lim;
  /// Yaw (偏航)
  float s_yaw_k1;
  float s_yaw_k2;
  float s_yaw_t_lim;
  /// ==================== PID控制参数 ====================
  /// X方向 (Surge)
  float p_x_kp;
  float p_x_ki;
  float p_x_kd;
  float p_x_f_lim;
  /// Y方向 (Sway)
  float p_y_kp;
  float p_y_ki;
  float p_y_kd;
  float p_y_f_lim;
  /// Z方向 (Heave)
  float p_z_kp;
  float p_z_ki;
  float p_z_kd;
  float p_z_f_lim;
  /// Roll (横滚)
  float p_roll_kp;
  float p_roll_ki;
  float p_roll_kd;
  float p_roll_t_lim;
  /// Pitch (俯仰)
  float p_pitch_kp;
  float p_pitch_ki;
  float p_pitch_kd;
  float p_pitch_t_lim;
  /// Yaw (偏航)
  float p_yaw_kp;
  float p_yaw_ki;
  float p_yaw_kd;
  float p_yaw_t_lim;
  /// ==================== 状态标志 ====================
  bool data_valid;
  builtin_interfaces__msg__Time timestamp;
} phd_master_slave_interfaces__msg__RobustCtrlPara;

// Struct for a sequence of phd_master_slave_interfaces__msg__RobustCtrlPara.
typedef struct phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence
{
  phd_master_slave_interfaces__msg__RobustCtrlPara * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} phd_master_slave_interfaces__msg__RobustCtrlPara__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__ROBUST_CTRL_PARA__STRUCT_H_
