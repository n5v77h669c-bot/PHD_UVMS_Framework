// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__STRUCT_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__phd_master_slave_interfaces__msg__ThrusterStatus __attribute__((deprecated))
#else
# define DEPRECATED__phd_master_slave_interfaces__msg__ThrusterStatus __declspec(deprecated)
#endif

namespace phd_master_slave_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ThrusterStatus_
{
  using Type = ThrusterStatus_<ContainerAllocator>;

  explicit ThrusterStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->set_power_lfu = 0;
      this->set_power_lfd = 0;
      this->set_power_rfu = 0;
      this->set_power_rfd = 0;
      this->set_power_lbu = 0;
      this->set_power_lbd = 0;
      this->set_power_rbu = 0;
      this->set_power_rbd = 0;
      this->actual_power_lfu = 0;
      this->actual_power_lfd = 0;
      this->actual_power_rfu = 0;
      this->actual_power_rfd = 0;
      this->actual_power_lbu = 0;
      this->actual_power_lbd = 0;
      this->actual_power_rbu = 0;
      this->actual_power_rbd = 0;
      this->data_valid = false;
      this->temperature = 0.0f;
    }
  }

  explicit ThrusterStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->set_power_lfu = 0;
      this->set_power_lfd = 0;
      this->set_power_rfu = 0;
      this->set_power_rfd = 0;
      this->set_power_lbu = 0;
      this->set_power_lbd = 0;
      this->set_power_rbu = 0;
      this->set_power_rbd = 0;
      this->actual_power_lfu = 0;
      this->actual_power_lfd = 0;
      this->actual_power_rfu = 0;
      this->actual_power_rfd = 0;
      this->actual_power_lbu = 0;
      this->actual_power_lbd = 0;
      this->actual_power_rbu = 0;
      this->actual_power_rbd = 0;
      this->data_valid = false;
      this->temperature = 0.0f;
    }
  }

  // field types and members
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _set_power_lfu_type =
    uint8_t;
  _set_power_lfu_type set_power_lfu;
  using _set_power_lfd_type =
    uint8_t;
  _set_power_lfd_type set_power_lfd;
  using _set_power_rfu_type =
    uint8_t;
  _set_power_rfu_type set_power_rfu;
  using _set_power_rfd_type =
    uint8_t;
  _set_power_rfd_type set_power_rfd;
  using _set_power_lbu_type =
    uint8_t;
  _set_power_lbu_type set_power_lbu;
  using _set_power_lbd_type =
    uint8_t;
  _set_power_lbd_type set_power_lbd;
  using _set_power_rbu_type =
    uint8_t;
  _set_power_rbu_type set_power_rbu;
  using _set_power_rbd_type =
    uint8_t;
  _set_power_rbd_type set_power_rbd;
  using _actual_power_lfu_type =
    uint8_t;
  _actual_power_lfu_type actual_power_lfu;
  using _actual_power_lfd_type =
    uint8_t;
  _actual_power_lfd_type actual_power_lfd;
  using _actual_power_rfu_type =
    uint8_t;
  _actual_power_rfu_type actual_power_rfu;
  using _actual_power_rfd_type =
    uint8_t;
  _actual_power_rfd_type actual_power_rfd;
  using _actual_power_lbu_type =
    uint8_t;
  _actual_power_lbu_type actual_power_lbu;
  using _actual_power_lbd_type =
    uint8_t;
  _actual_power_lbd_type actual_power_lbd;
  using _actual_power_rbu_type =
    uint8_t;
  _actual_power_rbu_type actual_power_rbu;
  using _actual_power_rbd_type =
    uint8_t;
  _actual_power_rbd_type actual_power_rbd;
  using _data_valid_type =
    bool;
  _data_valid_type data_valid;
  using _temperature_type =
    float;
  _temperature_type temperature;

  // setters for named parameter idiom
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__set_power_lfu(
    const uint8_t & _arg)
  {
    this->set_power_lfu = _arg;
    return *this;
  }
  Type & set__set_power_lfd(
    const uint8_t & _arg)
  {
    this->set_power_lfd = _arg;
    return *this;
  }
  Type & set__set_power_rfu(
    const uint8_t & _arg)
  {
    this->set_power_rfu = _arg;
    return *this;
  }
  Type & set__set_power_rfd(
    const uint8_t & _arg)
  {
    this->set_power_rfd = _arg;
    return *this;
  }
  Type & set__set_power_lbu(
    const uint8_t & _arg)
  {
    this->set_power_lbu = _arg;
    return *this;
  }
  Type & set__set_power_lbd(
    const uint8_t & _arg)
  {
    this->set_power_lbd = _arg;
    return *this;
  }
  Type & set__set_power_rbu(
    const uint8_t & _arg)
  {
    this->set_power_rbu = _arg;
    return *this;
  }
  Type & set__set_power_rbd(
    const uint8_t & _arg)
  {
    this->set_power_rbd = _arg;
    return *this;
  }
  Type & set__actual_power_lfu(
    const uint8_t & _arg)
  {
    this->actual_power_lfu = _arg;
    return *this;
  }
  Type & set__actual_power_lfd(
    const uint8_t & _arg)
  {
    this->actual_power_lfd = _arg;
    return *this;
  }
  Type & set__actual_power_rfu(
    const uint8_t & _arg)
  {
    this->actual_power_rfu = _arg;
    return *this;
  }
  Type & set__actual_power_rfd(
    const uint8_t & _arg)
  {
    this->actual_power_rfd = _arg;
    return *this;
  }
  Type & set__actual_power_lbu(
    const uint8_t & _arg)
  {
    this->actual_power_lbu = _arg;
    return *this;
  }
  Type & set__actual_power_lbd(
    const uint8_t & _arg)
  {
    this->actual_power_lbd = _arg;
    return *this;
  }
  Type & set__actual_power_rbu(
    const uint8_t & _arg)
  {
    this->actual_power_rbu = _arg;
    return *this;
  }
  Type & set__actual_power_rbd(
    const uint8_t & _arg)
  {
    this->actual_power_rbd = _arg;
    return *this;
  }
  Type & set__data_valid(
    const bool & _arg)
  {
    this->data_valid = _arg;
    return *this;
  }
  Type & set__temperature(
    const float & _arg)
  {
    this->temperature = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__phd_master_slave_interfaces__msg__ThrusterStatus
    std::shared_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__phd_master_slave_interfaces__msg__ThrusterStatus
    std::shared_ptr<phd_master_slave_interfaces::msg::ThrusterStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ThrusterStatus_ & other) const
  {
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->set_power_lfu != other.set_power_lfu) {
      return false;
    }
    if (this->set_power_lfd != other.set_power_lfd) {
      return false;
    }
    if (this->set_power_rfu != other.set_power_rfu) {
      return false;
    }
    if (this->set_power_rfd != other.set_power_rfd) {
      return false;
    }
    if (this->set_power_lbu != other.set_power_lbu) {
      return false;
    }
    if (this->set_power_lbd != other.set_power_lbd) {
      return false;
    }
    if (this->set_power_rbu != other.set_power_rbu) {
      return false;
    }
    if (this->set_power_rbd != other.set_power_rbd) {
      return false;
    }
    if (this->actual_power_lfu != other.actual_power_lfu) {
      return false;
    }
    if (this->actual_power_lfd != other.actual_power_lfd) {
      return false;
    }
    if (this->actual_power_rfu != other.actual_power_rfu) {
      return false;
    }
    if (this->actual_power_rfd != other.actual_power_rfd) {
      return false;
    }
    if (this->actual_power_lbu != other.actual_power_lbu) {
      return false;
    }
    if (this->actual_power_lbd != other.actual_power_lbd) {
      return false;
    }
    if (this->actual_power_rbu != other.actual_power_rbu) {
      return false;
    }
    if (this->actual_power_rbd != other.actual_power_rbd) {
      return false;
    }
    if (this->data_valid != other.data_valid) {
      return false;
    }
    if (this->temperature != other.temperature) {
      return false;
    }
    return true;
  }
  bool operator!=(const ThrusterStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ThrusterStatus_

// alias to use template instance with default allocator
using ThrusterStatus =
  phd_master_slave_interfaces::msg::ThrusterStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__STRUCT_HPP_
