// generated from rosidl_generator_c/resource/idl.h.em
// with input from phd_master_slave_interfaces:msg/RobustCtrlPara.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__ROBUST_CTRL_PARA_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__ROBUST_CTRL_PARA_H_

#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__struct.h"
#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__functions.h"
#include "phd_master_slave_interfaces/msg/detail/robust_ctrl_para__type_support.h"

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__ROBUST_CTRL_PARA_H_
