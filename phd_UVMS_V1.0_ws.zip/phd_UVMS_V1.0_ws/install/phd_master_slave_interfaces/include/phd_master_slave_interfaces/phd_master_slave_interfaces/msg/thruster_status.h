// generated from rosidl_generator_c/resource/idl.h.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__THRUSTER_STATUS_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__THRUSTER_STATUS_H_

#include "phd_master_slave_interfaces/msg/detail/thruster_status__struct.h"
#include "phd_master_slave_interfaces/msg/detail/thruster_status__functions.h"
#include "phd_master_slave_interfaces/msg/detail/thruster_status__type_support.h"

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__THRUSTER_STATUS_H_
