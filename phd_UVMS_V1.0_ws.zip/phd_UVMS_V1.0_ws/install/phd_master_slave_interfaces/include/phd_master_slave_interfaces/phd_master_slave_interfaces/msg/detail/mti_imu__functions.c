// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from phd_master_slave_interfaces:msg/MtiImu.idl
// generated code does not contain a copyright notice
#include "phd_master_slave_interfaces/msg/detail/mti_imu__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
phd_master_slave_interfaces__msg__MtiImu__init(phd_master_slave_interfaces__msg__MtiImu * msg)
{
  if (!msg) {
    return false;
  }
  // roll
  // pitch
  // yaw
  // q0
  // q1
  // q2
  // q3
  // accel_x
  // accel_y
  // accel_z
  // gyro_x
  // gyro_y
  // gyro_z
  // mag_x
  // mag_y
  // mag_z
  // temp_imu
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    phd_master_slave_interfaces__msg__MtiImu__fini(msg);
    return false;
  }
  // data_source
  // data_valid
  // vel_x
  // vel_y
  // vel_z
  // pos_x
  // pos_y
  // pos_z
  return true;
}

void
phd_master_slave_interfaces__msg__MtiImu__fini(phd_master_slave_interfaces__msg__MtiImu * msg)
{
  if (!msg) {
    return;
  }
  // roll
  // pitch
  // yaw
  // q0
  // q1
  // q2
  // q3
  // accel_x
  // accel_y
  // accel_z
  // gyro_x
  // gyro_y
  // gyro_z
  // mag_x
  // mag_y
  // mag_z
  // temp_imu
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
  // data_source
  // data_valid
  // vel_x
  // vel_y
  // vel_z
  // pos_x
  // pos_y
  // pos_z
}

bool
phd_master_slave_interfaces__msg__MtiImu__are_equal(const phd_master_slave_interfaces__msg__MtiImu * lhs, const phd_master_slave_interfaces__msg__MtiImu * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // roll
  if (lhs->roll != rhs->roll) {
    return false;
  }
  // pitch
  if (lhs->pitch != rhs->pitch) {
    return false;
  }
  // yaw
  if (lhs->yaw != rhs->yaw) {
    return false;
  }
  // q0
  if (lhs->q0 != rhs->q0) {
    return false;
  }
  // q1
  if (lhs->q1 != rhs->q1) {
    return false;
  }
  // q2
  if (lhs->q2 != rhs->q2) {
    return false;
  }
  // q3
  if (lhs->q3 != rhs->q3) {
    return false;
  }
  // accel_x
  if (lhs->accel_x != rhs->accel_x) {
    return false;
  }
  // accel_y
  if (lhs->accel_y != rhs->accel_y) {
    return false;
  }
  // accel_z
  if (lhs->accel_z != rhs->accel_z) {
    return false;
  }
  // gyro_x
  if (lhs->gyro_x != rhs->gyro_x) {
    return false;
  }
  // gyro_y
  if (lhs->gyro_y != rhs->gyro_y) {
    return false;
  }
  // gyro_z
  if (lhs->gyro_z != rhs->gyro_z) {
    return false;
  }
  // mag_x
  if (lhs->mag_x != rhs->mag_x) {
    return false;
  }
  // mag_y
  if (lhs->mag_y != rhs->mag_y) {
    return false;
  }
  // mag_z
  if (lhs->mag_z != rhs->mag_z) {
    return false;
  }
  // temp_imu
  if (lhs->temp_imu != rhs->temp_imu) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  // data_source
  if (lhs->data_source != rhs->data_source) {
    return false;
  }
  // data_valid
  if (lhs->data_valid != rhs->data_valid) {
    return false;
  }
  // vel_x
  if (lhs->vel_x != rhs->vel_x) {
    return false;
  }
  // vel_y
  if (lhs->vel_y != rhs->vel_y) {
    return false;
  }
  // vel_z
  if (lhs->vel_z != rhs->vel_z) {
    return false;
  }
  // pos_x
  if (lhs->pos_x != rhs->pos_x) {
    return false;
  }
  // pos_y
  if (lhs->pos_y != rhs->pos_y) {
    return false;
  }
  // pos_z
  if (lhs->pos_z != rhs->pos_z) {
    return false;
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__MtiImu__copy(
  const phd_master_slave_interfaces__msg__MtiImu * input,
  phd_master_slave_interfaces__msg__MtiImu * output)
{
  if (!input || !output) {
    return false;
  }
  // roll
  output->roll = input->roll;
  // pitch
  output->pitch = input->pitch;
  // yaw
  output->yaw = input->yaw;
  // q0
  output->q0 = input->q0;
  // q1
  output->q1 = input->q1;
  // q2
  output->q2 = input->q2;
  // q3
  output->q3 = input->q3;
  // accel_x
  output->accel_x = input->accel_x;
  // accel_y
  output->accel_y = input->accel_y;
  // accel_z
  output->accel_z = input->accel_z;
  // gyro_x
  output->gyro_x = input->gyro_x;
  // gyro_y
  output->gyro_y = input->gyro_y;
  // gyro_z
  output->gyro_z = input->gyro_z;
  // mag_x
  output->mag_x = input->mag_x;
  // mag_y
  output->mag_y = input->mag_y;
  // mag_z
  output->mag_z = input->mag_z;
  // temp_imu
  output->temp_imu = input->temp_imu;
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  // data_source
  output->data_source = input->data_source;
  // data_valid
  output->data_valid = input->data_valid;
  // vel_x
  output->vel_x = input->vel_x;
  // vel_y
  output->vel_y = input->vel_y;
  // vel_z
  output->vel_z = input->vel_z;
  // pos_x
  output->pos_x = input->pos_x;
  // pos_y
  output->pos_y = input->pos_y;
  // pos_z
  output->pos_z = input->pos_z;
  return true;
}

phd_master_slave_interfaces__msg__MtiImu *
phd_master_slave_interfaces__msg__MtiImu__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__MtiImu * msg = (phd_master_slave_interfaces__msg__MtiImu *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__MtiImu), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(phd_master_slave_interfaces__msg__MtiImu));
  bool success = phd_master_slave_interfaces__msg__MtiImu__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
phd_master_slave_interfaces__msg__MtiImu__destroy(phd_master_slave_interfaces__msg__MtiImu * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    phd_master_slave_interfaces__msg__MtiImu__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
phd_master_slave_interfaces__msg__MtiImu__Sequence__init(phd_master_slave_interfaces__msg__MtiImu__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__MtiImu * data = NULL;

  if (size) {
    data = (phd_master_slave_interfaces__msg__MtiImu *)allocator.zero_allocate(size, sizeof(phd_master_slave_interfaces__msg__MtiImu), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = phd_master_slave_interfaces__msg__MtiImu__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        phd_master_slave_interfaces__msg__MtiImu__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
phd_master_slave_interfaces__msg__MtiImu__Sequence__fini(phd_master_slave_interfaces__msg__MtiImu__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      phd_master_slave_interfaces__msg__MtiImu__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

phd_master_slave_interfaces__msg__MtiImu__Sequence *
phd_master_slave_interfaces__msg__MtiImu__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__MtiImu__Sequence * array = (phd_master_slave_interfaces__msg__MtiImu__Sequence *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__MtiImu__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = phd_master_slave_interfaces__msg__MtiImu__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
phd_master_slave_interfaces__msg__MtiImu__Sequence__destroy(phd_master_slave_interfaces__msg__MtiImu__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    phd_master_slave_interfaces__msg__MtiImu__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
phd_master_slave_interfaces__msg__MtiImu__Sequence__are_equal(const phd_master_slave_interfaces__msg__MtiImu__Sequence * lhs, const phd_master_slave_interfaces__msg__MtiImu__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!phd_master_slave_interfaces__msg__MtiImu__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__MtiImu__Sequence__copy(
  const phd_master_slave_interfaces__msg__MtiImu__Sequence * input,
  phd_master_slave_interfaces__msg__MtiImu__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(phd_master_slave_interfaces__msg__MtiImu);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    phd_master_slave_interfaces__msg__MtiImu * data =
      (phd_master_slave_interfaces__msg__MtiImu *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!phd_master_slave_interfaces__msg__MtiImu__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          phd_master_slave_interfaces__msg__MtiImu__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!phd_master_slave_interfaces__msg__MtiImu__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
