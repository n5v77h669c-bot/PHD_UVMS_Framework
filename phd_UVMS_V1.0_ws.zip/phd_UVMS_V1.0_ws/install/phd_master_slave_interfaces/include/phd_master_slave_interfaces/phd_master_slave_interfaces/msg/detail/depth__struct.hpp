// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from phd_master_slave_interfaces:msg/Depth.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__STRUCT_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__phd_master_slave_interfaces__msg__Depth __attribute__((deprecated))
#else
# define DEPRECATED__phd_master_slave_interfaces__msg__Depth __declspec(deprecated)
#endif

namespace phd_master_slave_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Depth_
{
  using Type = Depth_<ContainerAllocator>;

  explicit Depth_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->depth = 0.0;
      this->temp_water = 0.0;
    }
  }

  explicit Depth_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->depth = 0.0;
      this->temp_water = 0.0;
    }
  }

  // field types and members
  using _depth_type =
    double;
  _depth_type depth;
  using _temp_water_type =
    double;
  _temp_water_type temp_water;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__depth(
    const double & _arg)
  {
    this->depth = _arg;
    return *this;
  }
  Type & set__temp_water(
    const double & _arg)
  {
    this->temp_water = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    phd_master_slave_interfaces::msg::Depth_<ContainerAllocator> *;
  using ConstRawPtr =
    const phd_master_slave_interfaces::msg::Depth_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::Depth_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::Depth_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__phd_master_slave_interfaces__msg__Depth
    std::shared_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__phd_master_slave_interfaces__msg__Depth
    std::shared_ptr<phd_master_slave_interfaces::msg::Depth_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Depth_ & other) const
  {
    if (this->depth != other.depth) {
      return false;
    }
    if (this->temp_water != other.temp_water) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const Depth_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Depth_

// alias to use template instance with default allocator
using Depth =
  phd_master_slave_interfaces::msg::Depth_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__DEPTH__STRUCT_HPP_
