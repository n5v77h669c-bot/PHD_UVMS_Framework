﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__STRUCT_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/ThrusterStatus in the package phd_master_slave_interfaces.
/**
  * ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/ThrusterStatus.msg
  * ==================== 推进器状态消息 ====================
  * 时间戳
 */
typedef struct phd_master_slave_interfaces__msg__ThrusterStatus
{
  builtin_interfaces__msg__Time timestamp;
  /// ==================== 设置功率 (0-200) ====================
  /// 0-99: 反转, 100: 停止, 101-200: 正转
  uint8_t set_power_lfu;
  uint8_t set_power_lfd;
  uint8_t set_power_rfu;
  uint8_t set_power_rfd;
  uint8_t set_power_lbu;
  uint8_t set_power_lbd;
  uint8_t set_power_rbu;
  uint8_t set_power_rbd;
  /// ==================== 当前实际功率 (0-200) ====================
  uint8_t actual_power_lfu;
  uint8_t actual_power_lfd;
  uint8_t actual_power_rfu;
  uint8_t actual_power_rfd;
  uint8_t actual_power_lbu;
  uint8_t actual_power_lbd;
  uint8_t actual_power_rbu;
  uint8_t actual_power_rbd;
  /// ==================== 状态标志 ====================
  /// 数据有效性
  bool data_valid;
  /// 控制器温度（可选）
  float temperature;
} phd_master_slave_interfaces__msg__ThrusterStatus;

// Struct for a sequence of phd_master_slave_interfaces__msg__ThrusterStatus.
typedef struct phd_master_slave_interfaces__msg__ThrusterStatus__Sequence
{
  phd_master_slave_interfaces__msg__ThrusterStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} phd_master_slave_interfaces__msg__ThrusterStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__STRUCT_H_
