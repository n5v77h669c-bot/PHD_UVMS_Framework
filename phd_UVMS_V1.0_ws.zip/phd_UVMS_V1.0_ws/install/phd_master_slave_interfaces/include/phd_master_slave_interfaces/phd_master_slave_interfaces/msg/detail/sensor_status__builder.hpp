// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from phd_master_slave_interfaces:msg/SensorStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__BUILDER_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "phd_master_slave_interfaces/msg/detail/sensor_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace phd_master_slave_interfaces
{

namespace msg
{

namespace builder
{

class Init_SensorStatus_timestamp
{
public:
  explicit Init_SensorStatus_timestamp(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  ::phd_master_slave_interfaces::msg::SensorStatus timestamp(::phd_master_slave_interfaces::msg::SensorStatus::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_data_valid
{
public:
  explicit Init_SensorStatus_data_valid(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_timestamp data_valid(::phd_master_slave_interfaces::msg::SensorStatus::_data_valid_type arg)
  {
    msg_.data_valid = std::move(arg);
    return Init_SensorStatus_timestamp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_water_leak_status
{
public:
  explicit Init_SensorStatus_water_leak_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_data_valid water_leak_status(::phd_master_slave_interfaces::msg::SensorStatus::_water_leak_status_type arg)
  {
    msg_.water_leak_status = std::move(arg);
    return Init_SensorStatus_data_valid(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_scanning_sonar_cur_status
{
public:
  explicit Init_SensorStatus_scanning_sonar_cur_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_water_leak_status scanning_sonar_cur_status(::phd_master_slave_interfaces::msg::SensorStatus::_scanning_sonar_cur_status_type arg)
  {
    msg_.scanning_sonar_cur_status = std::move(arg);
    return Init_SensorStatus_water_leak_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_front_sonar_cur_status
{
public:
  explicit Init_SensorStatus_front_sonar_cur_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_scanning_sonar_cur_status front_sonar_cur_status(::phd_master_slave_interfaces::msg::SensorStatus::_front_sonar_cur_status_type arg)
  {
    msg_.front_sonar_cur_status = std::move(arg);
    return Init_SensorStatus_scanning_sonar_cur_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_light_cur_status
{
public:
  explicit Init_SensorStatus_light_cur_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_front_sonar_cur_status light_cur_status(::phd_master_slave_interfaces::msg::SensorStatus::_light_cur_status_type arg)
  {
    msg_.light_cur_status = std::move(arg);
    return Init_SensorStatus_front_sonar_cur_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_dvl_cur_status
{
public:
  explicit Init_SensorStatus_dvl_cur_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_light_cur_status dvl_cur_status(::phd_master_slave_interfaces::msg::SensorStatus::_dvl_cur_status_type arg)
  {
    msg_.dvl_cur_status = std::move(arg);
    return Init_SensorStatus_light_cur_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_scanning_sonar_set_status
{
public:
  explicit Init_SensorStatus_scanning_sonar_set_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_dvl_cur_status scanning_sonar_set_status(::phd_master_slave_interfaces::msg::SensorStatus::_scanning_sonar_set_status_type arg)
  {
    msg_.scanning_sonar_set_status = std::move(arg);
    return Init_SensorStatus_dvl_cur_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_front_sonar_set_status
{
public:
  explicit Init_SensorStatus_front_sonar_set_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_scanning_sonar_set_status front_sonar_set_status(::phd_master_slave_interfaces::msg::SensorStatus::_front_sonar_set_status_type arg)
  {
    msg_.front_sonar_set_status = std::move(arg);
    return Init_SensorStatus_scanning_sonar_set_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_light_set_status
{
public:
  explicit Init_SensorStatus_light_set_status(::phd_master_slave_interfaces::msg::SensorStatus & msg)
  : msg_(msg)
  {}
  Init_SensorStatus_front_sonar_set_status light_set_status(::phd_master_slave_interfaces::msg::SensorStatus::_light_set_status_type arg)
  {
    msg_.light_set_status = std::move(arg);
    return Init_SensorStatus_front_sonar_set_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

class Init_SensorStatus_dvl_set_status
{
public:
  Init_SensorStatus_dvl_set_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SensorStatus_light_set_status dvl_set_status(::phd_master_slave_interfaces::msg::SensorStatus::_dvl_set_status_type arg)
  {
    msg_.dvl_set_status = std::move(arg);
    return Init_SensorStatus_light_set_status(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::SensorStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::phd_master_slave_interfaces::msg::SensorStatus>()
{
  return phd_master_slave_interfaces::msg::builder::Init_SensorStatus_dvl_set_status();
}

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__BUILDER_HPP_
