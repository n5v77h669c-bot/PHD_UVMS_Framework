// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__TRAITS_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "phd_master_slave_interfaces/msg/detail/thruster_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace phd_master_slave_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ThrusterStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: set_power_lfu
  {
    out << "set_power_lfu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lfu, out);
    out << ", ";
  }

  // member: set_power_lfd
  {
    out << "set_power_lfd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lfd, out);
    out << ", ";
  }

  // member: set_power_rfu
  {
    out << "set_power_rfu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rfu, out);
    out << ", ";
  }

  // member: set_power_rfd
  {
    out << "set_power_rfd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rfd, out);
    out << ", ";
  }

  // member: set_power_lbu
  {
    out << "set_power_lbu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lbu, out);
    out << ", ";
  }

  // member: set_power_lbd
  {
    out << "set_power_lbd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lbd, out);
    out << ", ";
  }

  // member: set_power_rbu
  {
    out << "set_power_rbu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rbu, out);
    out << ", ";
  }

  // member: set_power_rbd
  {
    out << "set_power_rbd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rbd, out);
    out << ", ";
  }

  // member: actual_power_lfu
  {
    out << "actual_power_lfu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lfu, out);
    out << ", ";
  }

  // member: actual_power_lfd
  {
    out << "actual_power_lfd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lfd, out);
    out << ", ";
  }

  // member: actual_power_rfu
  {
    out << "actual_power_rfu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rfu, out);
    out << ", ";
  }

  // member: actual_power_rfd
  {
    out << "actual_power_rfd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rfd, out);
    out << ", ";
  }

  // member: actual_power_lbu
  {
    out << "actual_power_lbu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lbu, out);
    out << ", ";
  }

  // member: actual_power_lbd
  {
    out << "actual_power_lbd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lbd, out);
    out << ", ";
  }

  // member: actual_power_rbu
  {
    out << "actual_power_rbu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rbu, out);
    out << ", ";
  }

  // member: actual_power_rbd
  {
    out << "actual_power_rbd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rbd, out);
    out << ", ";
  }

  // member: data_valid
  {
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
    out << ", ";
  }

  // member: temperature
  {
    out << "temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.temperature, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ThrusterStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }

  // member: set_power_lfu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_lfu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lfu, out);
    out << "\n";
  }

  // member: set_power_lfd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_lfd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lfd, out);
    out << "\n";
  }

  // member: set_power_rfu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_rfu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rfu, out);
    out << "\n";
  }

  // member: set_power_rfd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_rfd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rfd, out);
    out << "\n";
  }

  // member: set_power_lbu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_lbu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lbu, out);
    out << "\n";
  }

  // member: set_power_lbd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_lbd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_lbd, out);
    out << "\n";
  }

  // member: set_power_rbu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_rbu: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rbu, out);
    out << "\n";
  }

  // member: set_power_rbd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_power_rbd: ";
    rosidl_generator_traits::value_to_yaml(msg.set_power_rbd, out);
    out << "\n";
  }

  // member: actual_power_lfu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_lfu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lfu, out);
    out << "\n";
  }

  // member: actual_power_lfd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_lfd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lfd, out);
    out << "\n";
  }

  // member: actual_power_rfu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_rfu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rfu, out);
    out << "\n";
  }

  // member: actual_power_rfd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_rfd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rfd, out);
    out << "\n";
  }

  // member: actual_power_lbu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_lbu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lbu, out);
    out << "\n";
  }

  // member: actual_power_lbd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_lbd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_lbd, out);
    out << "\n";
  }

  // member: actual_power_rbu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_rbu: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rbu, out);
    out << "\n";
  }

  // member: actual_power_rbd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "actual_power_rbd: ";
    rosidl_generator_traits::value_to_yaml(msg.actual_power_rbd, out);
    out << "\n";
  }

  // member: data_valid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
    out << "\n";
  }

  // member: temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.temperature, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ThrusterStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace phd_master_slave_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use phd_master_slave_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const phd_master_slave_interfaces::msg::ThrusterStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  phd_master_slave_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use phd_master_slave_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const phd_master_slave_interfaces::msg::ThrusterStatus & msg)
{
  return phd_master_slave_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<phd_master_slave_interfaces::msg::ThrusterStatus>()
{
  return "phd_master_slave_interfaces::msg::ThrusterStatus";
}

template<>
inline const char * name<phd_master_slave_interfaces::msg::ThrusterStatus>()
{
  return "phd_master_slave_interfaces/msg/ThrusterStatus";
}

template<>
struct has_fixed_size<phd_master_slave_interfaces::msg::ThrusterStatus>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<phd_master_slave_interfaces::msg::ThrusterStatus>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<phd_master_slave_interfaces::msg::ThrusterStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__THRUSTER_STATUS__TRAITS_HPP_
