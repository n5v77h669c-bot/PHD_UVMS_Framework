// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__STRUCT_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__phd_master_slave_interfaces__msg__MasterMachineUI __attribute__((deprecated))
#else
# define DEPRECATED__phd_master_slave_interfaces__msg__MasterMachineUI __declspec(deprecated)
#endif

namespace phd_master_slave_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MasterMachineUI_
{
  using Type = MasterMachineUI_<ContainerAllocator>;

  explicit MasterMachineUI_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->control_mode = 0l;
      this->manual_lfu = 0;
      this->manual_lfd = 0;
      this->manual_rfu = 0;
      this->manual_rfd = 0;
      this->manual_lbu = 0;
      this->manual_lbd = 0;
      this->manual_rbu = 0;
      this->manual_rbd = 0;
      this->auto_x_velocity = 0.0f;
      this->auto_y_velocity = 0.0f;
      this->auto_yaw = 0.0f;
      this->auto_depth = 0.0f;
      this->auto_x_distance = 0.0f;
      this->auto_y_distance = 0.0f;
      this->protect_depth = 0.0f;
      this->protect_height = 0.0f;
      this->protect_time = 0.0f;
      this->upper_computer_timer = 0.0f;
      this->lower_machine_timer = 0.0f;
      this->data_valid = false;
    }
  }

  explicit MasterMachineUI_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->control_mode = 0l;
      this->manual_lfu = 0;
      this->manual_lfd = 0;
      this->manual_rfu = 0;
      this->manual_rfd = 0;
      this->manual_lbu = 0;
      this->manual_lbd = 0;
      this->manual_rbu = 0;
      this->manual_rbd = 0;
      this->auto_x_velocity = 0.0f;
      this->auto_y_velocity = 0.0f;
      this->auto_yaw = 0.0f;
      this->auto_depth = 0.0f;
      this->auto_x_distance = 0.0f;
      this->auto_y_distance = 0.0f;
      this->protect_depth = 0.0f;
      this->protect_height = 0.0f;
      this->protect_time = 0.0f;
      this->upper_computer_timer = 0.0f;
      this->lower_machine_timer = 0.0f;
      this->data_valid = false;
    }
  }

  // field types and members
  using _control_mode_type =
    int32_t;
  _control_mode_type control_mode;
  using _manual_lfu_type =
    int8_t;
  _manual_lfu_type manual_lfu;
  using _manual_lfd_type =
    int8_t;
  _manual_lfd_type manual_lfd;
  using _manual_rfu_type =
    int8_t;
  _manual_rfu_type manual_rfu;
  using _manual_rfd_type =
    int8_t;
  _manual_rfd_type manual_rfd;
  using _manual_lbu_type =
    int8_t;
  _manual_lbu_type manual_lbu;
  using _manual_lbd_type =
    int8_t;
  _manual_lbd_type manual_lbd;
  using _manual_rbu_type =
    int8_t;
  _manual_rbu_type manual_rbu;
  using _manual_rbd_type =
    int8_t;
  _manual_rbd_type manual_rbd;
  using _auto_x_velocity_type =
    float;
  _auto_x_velocity_type auto_x_velocity;
  using _auto_y_velocity_type =
    float;
  _auto_y_velocity_type auto_y_velocity;
  using _auto_yaw_type =
    float;
  _auto_yaw_type auto_yaw;
  using _auto_depth_type =
    float;
  _auto_depth_type auto_depth;
  using _auto_x_distance_type =
    float;
  _auto_x_distance_type auto_x_distance;
  using _auto_y_distance_type =
    float;
  _auto_y_distance_type auto_y_distance;
  using _protect_depth_type =
    float;
  _protect_depth_type protect_depth;
  using _protect_height_type =
    float;
  _protect_height_type protect_height;
  using _protect_time_type =
    float;
  _protect_time_type protect_time;
  using _upper_computer_timer_type =
    float;
  _upper_computer_timer_type upper_computer_timer;
  using _lower_machine_timer_type =
    float;
  _lower_machine_timer_type lower_machine_timer;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _data_valid_type =
    bool;
  _data_valid_type data_valid;

  // setters for named parameter idiom
  Type & set__control_mode(
    const int32_t & _arg)
  {
    this->control_mode = _arg;
    return *this;
  }
  Type & set__manual_lfu(
    const int8_t & _arg)
  {
    this->manual_lfu = _arg;
    return *this;
  }
  Type & set__manual_lfd(
    const int8_t & _arg)
  {
    this->manual_lfd = _arg;
    return *this;
  }
  Type & set__manual_rfu(
    const int8_t & _arg)
  {
    this->manual_rfu = _arg;
    return *this;
  }
  Type & set__manual_rfd(
    const int8_t & _arg)
  {
    this->manual_rfd = _arg;
    return *this;
  }
  Type & set__manual_lbu(
    const int8_t & _arg)
  {
    this->manual_lbu = _arg;
    return *this;
  }
  Type & set__manual_lbd(
    const int8_t & _arg)
  {
    this->manual_lbd = _arg;
    return *this;
  }
  Type & set__manual_rbu(
    const int8_t & _arg)
  {
    this->manual_rbu = _arg;
    return *this;
  }
  Type & set__manual_rbd(
    const int8_t & _arg)
  {
    this->manual_rbd = _arg;
    return *this;
  }
  Type & set__auto_x_velocity(
    const float & _arg)
  {
    this->auto_x_velocity = _arg;
    return *this;
  }
  Type & set__auto_y_velocity(
    const float & _arg)
  {
    this->auto_y_velocity = _arg;
    return *this;
  }
  Type & set__auto_yaw(
    const float & _arg)
  {
    this->auto_yaw = _arg;
    return *this;
  }
  Type & set__auto_depth(
    const float & _arg)
  {
    this->auto_depth = _arg;
    return *this;
  }
  Type & set__auto_x_distance(
    const float & _arg)
  {
    this->auto_x_distance = _arg;
    return *this;
  }
  Type & set__auto_y_distance(
    const float & _arg)
  {
    this->auto_y_distance = _arg;
    return *this;
  }
  Type & set__protect_depth(
    const float & _arg)
  {
    this->protect_depth = _arg;
    return *this;
  }
  Type & set__protect_height(
    const float & _arg)
  {
    this->protect_height = _arg;
    return *this;
  }
  Type & set__protect_time(
    const float & _arg)
  {
    this->protect_time = _arg;
    return *this;
  }
  Type & set__upper_computer_timer(
    const float & _arg)
  {
    this->upper_computer_timer = _arg;
    return *this;
  }
  Type & set__lower_machine_timer(
    const float & _arg)
  {
    this->lower_machine_timer = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__data_valid(
    const bool & _arg)
  {
    this->data_valid = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator> *;
  using ConstRawPtr =
    const phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__phd_master_slave_interfaces__msg__MasterMachineUI
    std::shared_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__phd_master_slave_interfaces__msg__MasterMachineUI
    std::shared_ptr<phd_master_slave_interfaces::msg::MasterMachineUI_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MasterMachineUI_ & other) const
  {
    if (this->control_mode != other.control_mode) {
      return false;
    }
    if (this->manual_lfu != other.manual_lfu) {
      return false;
    }
    if (this->manual_lfd != other.manual_lfd) {
      return false;
    }
    if (this->manual_rfu != other.manual_rfu) {
      return false;
    }
    if (this->manual_rfd != other.manual_rfd) {
      return false;
    }
    if (this->manual_lbu != other.manual_lbu) {
      return false;
    }
    if (this->manual_lbd != other.manual_lbd) {
      return false;
    }
    if (this->manual_rbu != other.manual_rbu) {
      return false;
    }
    if (this->manual_rbd != other.manual_rbd) {
      return false;
    }
    if (this->auto_x_velocity != other.auto_x_velocity) {
      return false;
    }
    if (this->auto_y_velocity != other.auto_y_velocity) {
      return false;
    }
    if (this->auto_yaw != other.auto_yaw) {
      return false;
    }
    if (this->auto_depth != other.auto_depth) {
      return false;
    }
    if (this->auto_x_distance != other.auto_x_distance) {
      return false;
    }
    if (this->auto_y_distance != other.auto_y_distance) {
      return false;
    }
    if (this->protect_depth != other.protect_depth) {
      return false;
    }
    if (this->protect_height != other.protect_height) {
      return false;
    }
    if (this->protect_time != other.protect_time) {
      return false;
    }
    if (this->upper_computer_timer != other.upper_computer_timer) {
      return false;
    }
    if (this->lower_machine_timer != other.lower_machine_timer) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->data_valid != other.data_valid) {
      return false;
    }
    return true;
  }
  bool operator!=(const MasterMachineUI_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MasterMachineUI_

// alias to use template instance with default allocator
using MasterMachineUI =
  phd_master_slave_interfaces::msg::MasterMachineUI_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__STRUCT_HPP_
