// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from phd_master_slave_interfaces:msg/MtiImu.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__BUILDER_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "phd_master_slave_interfaces/msg/detail/mti_imu__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace phd_master_slave_interfaces
{

namespace msg
{

namespace builder
{

class Init_MtiImu_pos_z
{
public:
  explicit Init_MtiImu_pos_z(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  ::phd_master_slave_interfaces::msg::MtiImu pos_z(::phd_master_slave_interfaces::msg::MtiImu::_pos_z_type arg)
  {
    msg_.pos_z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_pos_y
{
public:
  explicit Init_MtiImu_pos_y(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_pos_z pos_y(::phd_master_slave_interfaces::msg::MtiImu::_pos_y_type arg)
  {
    msg_.pos_y = std::move(arg);
    return Init_MtiImu_pos_z(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_pos_x
{
public:
  explicit Init_MtiImu_pos_x(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_pos_y pos_x(::phd_master_slave_interfaces::msg::MtiImu::_pos_x_type arg)
  {
    msg_.pos_x = std::move(arg);
    return Init_MtiImu_pos_y(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_vel_z
{
public:
  explicit Init_MtiImu_vel_z(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_pos_x vel_z(::phd_master_slave_interfaces::msg::MtiImu::_vel_z_type arg)
  {
    msg_.vel_z = std::move(arg);
    return Init_MtiImu_pos_x(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_vel_y
{
public:
  explicit Init_MtiImu_vel_y(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_vel_z vel_y(::phd_master_slave_interfaces::msg::MtiImu::_vel_y_type arg)
  {
    msg_.vel_y = std::move(arg);
    return Init_MtiImu_vel_z(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_vel_x
{
public:
  explicit Init_MtiImu_vel_x(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_vel_y vel_x(::phd_master_slave_interfaces::msg::MtiImu::_vel_x_type arg)
  {
    msg_.vel_x = std::move(arg);
    return Init_MtiImu_vel_y(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_data_valid
{
public:
  explicit Init_MtiImu_data_valid(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_vel_x data_valid(::phd_master_slave_interfaces::msg::MtiImu::_data_valid_type arg)
  {
    msg_.data_valid = std::move(arg);
    return Init_MtiImu_vel_x(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_data_source
{
public:
  explicit Init_MtiImu_data_source(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_data_valid data_source(::phd_master_slave_interfaces::msg::MtiImu::_data_source_type arg)
  {
    msg_.data_source = std::move(arg);
    return Init_MtiImu_data_valid(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_timestamp
{
public:
  explicit Init_MtiImu_timestamp(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_data_source timestamp(::phd_master_slave_interfaces::msg::MtiImu::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_MtiImu_data_source(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_temp_imu
{
public:
  explicit Init_MtiImu_temp_imu(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_timestamp temp_imu(::phd_master_slave_interfaces::msg::MtiImu::_temp_imu_type arg)
  {
    msg_.temp_imu = std::move(arg);
    return Init_MtiImu_timestamp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_mag_z
{
public:
  explicit Init_MtiImu_mag_z(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_temp_imu mag_z(::phd_master_slave_interfaces::msg::MtiImu::_mag_z_type arg)
  {
    msg_.mag_z = std::move(arg);
    return Init_MtiImu_temp_imu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_mag_y
{
public:
  explicit Init_MtiImu_mag_y(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_mag_z mag_y(::phd_master_slave_interfaces::msg::MtiImu::_mag_y_type arg)
  {
    msg_.mag_y = std::move(arg);
    return Init_MtiImu_mag_z(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_mag_x
{
public:
  explicit Init_MtiImu_mag_x(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_mag_y mag_x(::phd_master_slave_interfaces::msg::MtiImu::_mag_x_type arg)
  {
    msg_.mag_x = std::move(arg);
    return Init_MtiImu_mag_y(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_gyro_z
{
public:
  explicit Init_MtiImu_gyro_z(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_mag_x gyro_z(::phd_master_slave_interfaces::msg::MtiImu::_gyro_z_type arg)
  {
    msg_.gyro_z = std::move(arg);
    return Init_MtiImu_mag_x(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_gyro_y
{
public:
  explicit Init_MtiImu_gyro_y(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_gyro_z gyro_y(::phd_master_slave_interfaces::msg::MtiImu::_gyro_y_type arg)
  {
    msg_.gyro_y = std::move(arg);
    return Init_MtiImu_gyro_z(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_gyro_x
{
public:
  explicit Init_MtiImu_gyro_x(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_gyro_y gyro_x(::phd_master_slave_interfaces::msg::MtiImu::_gyro_x_type arg)
  {
    msg_.gyro_x = std::move(arg);
    return Init_MtiImu_gyro_y(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_accel_z
{
public:
  explicit Init_MtiImu_accel_z(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_gyro_x accel_z(::phd_master_slave_interfaces::msg::MtiImu::_accel_z_type arg)
  {
    msg_.accel_z = std::move(arg);
    return Init_MtiImu_gyro_x(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_accel_y
{
public:
  explicit Init_MtiImu_accel_y(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_accel_z accel_y(::phd_master_slave_interfaces::msg::MtiImu::_accel_y_type arg)
  {
    msg_.accel_y = std::move(arg);
    return Init_MtiImu_accel_z(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_accel_x
{
public:
  explicit Init_MtiImu_accel_x(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_accel_y accel_x(::phd_master_slave_interfaces::msg::MtiImu::_accel_x_type arg)
  {
    msg_.accel_x = std::move(arg);
    return Init_MtiImu_accel_y(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_q3
{
public:
  explicit Init_MtiImu_q3(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_accel_x q3(::phd_master_slave_interfaces::msg::MtiImu::_q3_type arg)
  {
    msg_.q3 = std::move(arg);
    return Init_MtiImu_accel_x(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_q2
{
public:
  explicit Init_MtiImu_q2(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_q3 q2(::phd_master_slave_interfaces::msg::MtiImu::_q2_type arg)
  {
    msg_.q2 = std::move(arg);
    return Init_MtiImu_q3(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_q1
{
public:
  explicit Init_MtiImu_q1(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_q2 q1(::phd_master_slave_interfaces::msg::MtiImu::_q1_type arg)
  {
    msg_.q1 = std::move(arg);
    return Init_MtiImu_q2(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_q0
{
public:
  explicit Init_MtiImu_q0(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_q1 q0(::phd_master_slave_interfaces::msg::MtiImu::_q0_type arg)
  {
    msg_.q0 = std::move(arg);
    return Init_MtiImu_q1(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_yaw
{
public:
  explicit Init_MtiImu_yaw(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_q0 yaw(::phd_master_slave_interfaces::msg::MtiImu::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_MtiImu_q0(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_pitch
{
public:
  explicit Init_MtiImu_pitch(::phd_master_slave_interfaces::msg::MtiImu & msg)
  : msg_(msg)
  {}
  Init_MtiImu_yaw pitch(::phd_master_slave_interfaces::msg::MtiImu::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_MtiImu_yaw(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

class Init_MtiImu_roll
{
public:
  Init_MtiImu_roll()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MtiImu_pitch roll(::phd_master_slave_interfaces::msg::MtiImu::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_MtiImu_pitch(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MtiImu msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::phd_master_slave_interfaces::msg::MtiImu>()
{
  return phd_master_slave_interfaces::msg::builder::Init_MtiImu_roll();
}

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__BUILDER_HPP_
