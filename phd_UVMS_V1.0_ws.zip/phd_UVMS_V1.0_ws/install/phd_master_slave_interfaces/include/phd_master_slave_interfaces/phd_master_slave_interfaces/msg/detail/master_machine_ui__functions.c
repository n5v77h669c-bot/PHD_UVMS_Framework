// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
// generated code does not contain a copyright notice
#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
phd_master_slave_interfaces__msg__MasterMachineUI__init(phd_master_slave_interfaces__msg__MasterMachineUI * msg)
{
  if (!msg) {
    return false;
  }
  // control_mode
  // manual_lfu
  // manual_lfd
  // manual_rfu
  // manual_rfd
  // manual_lbu
  // manual_lbd
  // manual_rbu
  // manual_rbd
  // auto_x_velocity
  // auto_y_velocity
  // auto_yaw
  // auto_depth
  // auto_x_distance
  // auto_y_distance
  // protect_depth
  // protect_height
  // protect_time
  // upper_computer_timer
  // lower_machine_timer
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    phd_master_slave_interfaces__msg__MasterMachineUI__fini(msg);
    return false;
  }
  // data_valid
  return true;
}

void
phd_master_slave_interfaces__msg__MasterMachineUI__fini(phd_master_slave_interfaces__msg__MasterMachineUI * msg)
{
  if (!msg) {
    return;
  }
  // control_mode
  // manual_lfu
  // manual_lfd
  // manual_rfu
  // manual_rfd
  // manual_lbu
  // manual_lbd
  // manual_rbu
  // manual_rbd
  // auto_x_velocity
  // auto_y_velocity
  // auto_yaw
  // auto_depth
  // auto_x_distance
  // auto_y_distance
  // protect_depth
  // protect_height
  // protect_time
  // upper_computer_timer
  // lower_machine_timer
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
  // data_valid
}

bool
phd_master_slave_interfaces__msg__MasterMachineUI__are_equal(const phd_master_slave_interfaces__msg__MasterMachineUI * lhs, const phd_master_slave_interfaces__msg__MasterMachineUI * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // control_mode
  if (lhs->control_mode != rhs->control_mode) {
    return false;
  }
  // manual_lfu
  if (lhs->manual_lfu != rhs->manual_lfu) {
    return false;
  }
  // manual_lfd
  if (lhs->manual_lfd != rhs->manual_lfd) {
    return false;
  }
  // manual_rfu
  if (lhs->manual_rfu != rhs->manual_rfu) {
    return false;
  }
  // manual_rfd
  if (lhs->manual_rfd != rhs->manual_rfd) {
    return false;
  }
  // manual_lbu
  if (lhs->manual_lbu != rhs->manual_lbu) {
    return false;
  }
  // manual_lbd
  if (lhs->manual_lbd != rhs->manual_lbd) {
    return false;
  }
  // manual_rbu
  if (lhs->manual_rbu != rhs->manual_rbu) {
    return false;
  }
  // manual_rbd
  if (lhs->manual_rbd != rhs->manual_rbd) {
    return false;
  }
  // auto_x_velocity
  if (lhs->auto_x_velocity != rhs->auto_x_velocity) {
    return false;
  }
  // auto_y_velocity
  if (lhs->auto_y_velocity != rhs->auto_y_velocity) {
    return false;
  }
  // auto_yaw
  if (lhs->auto_yaw != rhs->auto_yaw) {
    return false;
  }
  // auto_depth
  if (lhs->auto_depth != rhs->auto_depth) {
    return false;
  }
  // auto_x_distance
  if (lhs->auto_x_distance != rhs->auto_x_distance) {
    return false;
  }
  // auto_y_distance
  if (lhs->auto_y_distance != rhs->auto_y_distance) {
    return false;
  }
  // protect_depth
  if (lhs->protect_depth != rhs->protect_depth) {
    return false;
  }
  // protect_height
  if (lhs->protect_height != rhs->protect_height) {
    return false;
  }
  // protect_time
  if (lhs->protect_time != rhs->protect_time) {
    return false;
  }
  // upper_computer_timer
  if (lhs->upper_computer_timer != rhs->upper_computer_timer) {
    return false;
  }
  // lower_machine_timer
  if (lhs->lower_machine_timer != rhs->lower_machine_timer) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  // data_valid
  if (lhs->data_valid != rhs->data_valid) {
    return false;
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__MasterMachineUI__copy(
  const phd_master_slave_interfaces__msg__MasterMachineUI * input,
  phd_master_slave_interfaces__msg__MasterMachineUI * output)
{
  if (!input || !output) {
    return false;
  }
  // control_mode
  output->control_mode = input->control_mode;
  // manual_lfu
  output->manual_lfu = input->manual_lfu;
  // manual_lfd
  output->manual_lfd = input->manual_lfd;
  // manual_rfu
  output->manual_rfu = input->manual_rfu;
  // manual_rfd
  output->manual_rfd = input->manual_rfd;
  // manual_lbu
  output->manual_lbu = input->manual_lbu;
  // manual_lbd
  output->manual_lbd = input->manual_lbd;
  // manual_rbu
  output->manual_rbu = input->manual_rbu;
  // manual_rbd
  output->manual_rbd = input->manual_rbd;
  // auto_x_velocity
  output->auto_x_velocity = input->auto_x_velocity;
  // auto_y_velocity
  output->auto_y_velocity = input->auto_y_velocity;
  // auto_yaw
  output->auto_yaw = input->auto_yaw;
  // auto_depth
  output->auto_depth = input->auto_depth;
  // auto_x_distance
  output->auto_x_distance = input->auto_x_distance;
  // auto_y_distance
  output->auto_y_distance = input->auto_y_distance;
  // protect_depth
  output->protect_depth = input->protect_depth;
  // protect_height
  output->protect_height = input->protect_height;
  // protect_time
  output->protect_time = input->protect_time;
  // upper_computer_timer
  output->upper_computer_timer = input->upper_computer_timer;
  // lower_machine_timer
  output->lower_machine_timer = input->lower_machine_timer;
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  // data_valid
  output->data_valid = input->data_valid;
  return true;
}

phd_master_slave_interfaces__msg__MasterMachineUI *
phd_master_slave_interfaces__msg__MasterMachineUI__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__MasterMachineUI * msg = (phd_master_slave_interfaces__msg__MasterMachineUI *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__MasterMachineUI), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(phd_master_slave_interfaces__msg__MasterMachineUI));
  bool success = phd_master_slave_interfaces__msg__MasterMachineUI__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
phd_master_slave_interfaces__msg__MasterMachineUI__destroy(phd_master_slave_interfaces__msg__MasterMachineUI * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    phd_master_slave_interfaces__msg__MasterMachineUI__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__init(phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__MasterMachineUI * data = NULL;

  if (size) {
    data = (phd_master_slave_interfaces__msg__MasterMachineUI *)allocator.zero_allocate(size, sizeof(phd_master_slave_interfaces__msg__MasterMachineUI), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = phd_master_slave_interfaces__msg__MasterMachineUI__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        phd_master_slave_interfaces__msg__MasterMachineUI__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__fini(phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      phd_master_slave_interfaces__msg__MasterMachineUI__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

phd_master_slave_interfaces__msg__MasterMachineUI__Sequence *
phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * array = (phd_master_slave_interfaces__msg__MasterMachineUI__Sequence *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__MasterMachineUI__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__destroy(phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__are_equal(const phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * lhs, const phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!phd_master_slave_interfaces__msg__MasterMachineUI__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__MasterMachineUI__Sequence__copy(
  const phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * input,
  phd_master_slave_interfaces__msg__MasterMachineUI__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(phd_master_slave_interfaces__msg__MasterMachineUI);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    phd_master_slave_interfaces__msg__MasterMachineUI * data =
      (phd_master_slave_interfaces__msg__MasterMachineUI *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!phd_master_slave_interfaces__msg__MasterMachineUI__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          phd_master_slave_interfaces__msg__MasterMachineUI__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!phd_master_slave_interfaces__msg__MasterMachineUI__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
