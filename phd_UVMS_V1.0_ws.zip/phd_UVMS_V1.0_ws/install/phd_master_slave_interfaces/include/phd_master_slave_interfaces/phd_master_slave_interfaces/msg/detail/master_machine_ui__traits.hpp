// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__TRAITS_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace phd_master_slave_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const MasterMachineUI & msg,
  std::ostream & out)
{
  out << "{";
  // member: control_mode
  {
    out << "control_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.control_mode, out);
    out << ", ";
  }

  // member: manual_lfu
  {
    out << "manual_lfu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lfu, out);
    out << ", ";
  }

  // member: manual_lfd
  {
    out << "manual_lfd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lfd, out);
    out << ", ";
  }

  // member: manual_rfu
  {
    out << "manual_rfu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rfu, out);
    out << ", ";
  }

  // member: manual_rfd
  {
    out << "manual_rfd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rfd, out);
    out << ", ";
  }

  // member: manual_lbu
  {
    out << "manual_lbu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lbu, out);
    out << ", ";
  }

  // member: manual_lbd
  {
    out << "manual_lbd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lbd, out);
    out << ", ";
  }

  // member: manual_rbu
  {
    out << "manual_rbu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rbu, out);
    out << ", ";
  }

  // member: manual_rbd
  {
    out << "manual_rbd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rbd, out);
    out << ", ";
  }

  // member: auto_x_velocity
  {
    out << "auto_x_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_x_velocity, out);
    out << ", ";
  }

  // member: auto_y_velocity
  {
    out << "auto_y_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_y_velocity, out);
    out << ", ";
  }

  // member: auto_yaw
  {
    out << "auto_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_yaw, out);
    out << ", ";
  }

  // member: auto_depth
  {
    out << "auto_depth: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_depth, out);
    out << ", ";
  }

  // member: auto_x_distance
  {
    out << "auto_x_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_x_distance, out);
    out << ", ";
  }

  // member: auto_y_distance
  {
    out << "auto_y_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_y_distance, out);
    out << ", ";
  }

  // member: protect_depth
  {
    out << "protect_depth: ";
    rosidl_generator_traits::value_to_yaml(msg.protect_depth, out);
    out << ", ";
  }

  // member: protect_height
  {
    out << "protect_height: ";
    rosidl_generator_traits::value_to_yaml(msg.protect_height, out);
    out << ", ";
  }

  // member: protect_time
  {
    out << "protect_time: ";
    rosidl_generator_traits::value_to_yaml(msg.protect_time, out);
    out << ", ";
  }

  // member: upper_computer_timer
  {
    out << "upper_computer_timer: ";
    rosidl_generator_traits::value_to_yaml(msg.upper_computer_timer, out);
    out << ", ";
  }

  // member: lower_machine_timer
  {
    out << "lower_machine_timer: ";
    rosidl_generator_traits::value_to_yaml(msg.lower_machine_timer, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: data_valid
  {
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MasterMachineUI & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: control_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.control_mode, out);
    out << "\n";
  }

  // member: manual_lfu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_lfu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lfu, out);
    out << "\n";
  }

  // member: manual_lfd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_lfd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lfd, out);
    out << "\n";
  }

  // member: manual_rfu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_rfu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rfu, out);
    out << "\n";
  }

  // member: manual_rfd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_rfd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rfd, out);
    out << "\n";
  }

  // member: manual_lbu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_lbu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lbu, out);
    out << "\n";
  }

  // member: manual_lbd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_lbd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_lbd, out);
    out << "\n";
  }

  // member: manual_rbu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_rbu: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rbu, out);
    out << "\n";
  }

  // member: manual_rbd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "manual_rbd: ";
    rosidl_generator_traits::value_to_yaml(msg.manual_rbd, out);
    out << "\n";
  }

  // member: auto_x_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "auto_x_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_x_velocity, out);
    out << "\n";
  }

  // member: auto_y_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "auto_y_velocity: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_y_velocity, out);
    out << "\n";
  }

  // member: auto_yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "auto_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_yaw, out);
    out << "\n";
  }

  // member: auto_depth
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "auto_depth: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_depth, out);
    out << "\n";
  }

  // member: auto_x_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "auto_x_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_x_distance, out);
    out << "\n";
  }

  // member: auto_y_distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "auto_y_distance: ";
    rosidl_generator_traits::value_to_yaml(msg.auto_y_distance, out);
    out << "\n";
  }

  // member: protect_depth
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "protect_depth: ";
    rosidl_generator_traits::value_to_yaml(msg.protect_depth, out);
    out << "\n";
  }

  // member: protect_height
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "protect_height: ";
    rosidl_generator_traits::value_to_yaml(msg.protect_height, out);
    out << "\n";
  }

  // member: protect_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "protect_time: ";
    rosidl_generator_traits::value_to_yaml(msg.protect_time, out);
    out << "\n";
  }

  // member: upper_computer_timer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "upper_computer_timer: ";
    rosidl_generator_traits::value_to_yaml(msg.upper_computer_timer, out);
    out << "\n";
  }

  // member: lower_machine_timer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lower_machine_timer: ";
    rosidl_generator_traits::value_to_yaml(msg.lower_machine_timer, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }

  // member: data_valid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.data_valid, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MasterMachineUI & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace phd_master_slave_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use phd_master_slave_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const phd_master_slave_interfaces::msg::MasterMachineUI & msg,
  std::ostream & out, size_t indentation = 0)
{
  phd_master_slave_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use phd_master_slave_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const phd_master_slave_interfaces::msg::MasterMachineUI & msg)
{
  return phd_master_slave_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<phd_master_slave_interfaces::msg::MasterMachineUI>()
{
  return "phd_master_slave_interfaces::msg::MasterMachineUI";
}

template<>
inline const char * name<phd_master_slave_interfaces::msg::MasterMachineUI>()
{
  return "phd_master_slave_interfaces/msg/MasterMachineUI";
}

template<>
struct has_fixed_size<phd_master_slave_interfaces::msg::MasterMachineUI>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<phd_master_slave_interfaces::msg::MasterMachineUI>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<phd_master_slave_interfaces::msg::MasterMachineUI>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__TRAITS_HPP_
