﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from phd_master_slave_interfaces:msg/SensorStatus.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__STRUCT_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/SensorStatus in the package phd_master_slave_interfaces.
/**
  * ~/ROS2_humble_master/phd_UVMS_RealMachine_ws/src/phd_master_slave_interfaces/msg/SensorStatus.msg
 */
typedef struct phd_master_slave_interfaces__msg__SensorStatus
{
  /// ==================== 传感器开关状态消息 ====================
  /// 用于传感器开关控制和状态反馈
  /// ==================== 设置状态 (来自上位机指令) ====================
  /// 0: 关闭, 1: 开启
  uint8_t dvl_set_status;
  uint8_t light_set_status;
  uint8_t front_sonar_set_status;
  uint8_t scanning_sonar_set_status;
  /// ==================== 当前状态 (从MCU读取) ====================
  /// 0: 关闭, 1: 开启
  uint8_t dvl_cur_status;
  uint8_t light_cur_status;
  uint8_t front_sonar_cur_status;
  uint8_t scanning_sonar_cur_status;
  /// ==================== 漏水状态 ====================
  /// 0: 未漏水, 1: 漏水
  uint8_t water_leak_status;
  /// ==================== 状态标志 ====================
  /// 数据有效性
  bool data_valid;
  /// 时间戳
  builtin_interfaces__msg__Time timestamp;
} phd_master_slave_interfaces__msg__SensorStatus;

// Struct for a sequence of phd_master_slave_interfaces__msg__SensorStatus.
typedef struct phd_master_slave_interfaces__msg__SensorStatus__Sequence
{
  phd_master_slave_interfaces__msg__SensorStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} phd_master_slave_interfaces__msg__SensorStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__SENSOR_STATUS__STRUCT_H_
