// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from phd_master_slave_interfaces:msg/MtiImu.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__FUNCTIONS_H_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "phd_master_slave_interfaces/msg/rosidl_generator_c__visibility_control.h"

#include "phd_master_slave_interfaces/msg/detail/mti_imu__struct.h"

/// Initialize msg/MtiImu message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * phd_master_slave_interfaces__msg__MtiImu
 * )) before or use
 * phd_master_slave_interfaces__msg__MtiImu__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
bool
phd_master_slave_interfaces__msg__MtiImu__init(phd_master_slave_interfaces__msg__MtiImu * msg);

/// Finalize msg/MtiImu message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
void
phd_master_slave_interfaces__msg__MtiImu__fini(phd_master_slave_interfaces__msg__MtiImu * msg);

/// Create msg/MtiImu message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * phd_master_slave_interfaces__msg__MtiImu__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
phd_master_slave_interfaces__msg__MtiImu *
phd_master_slave_interfaces__msg__MtiImu__create();

/// Destroy msg/MtiImu message.
/**
 * It calls
 * phd_master_slave_interfaces__msg__MtiImu__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
void
phd_master_slave_interfaces__msg__MtiImu__destroy(phd_master_slave_interfaces__msg__MtiImu * msg);

/// Check for msg/MtiImu message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
bool
phd_master_slave_interfaces__msg__MtiImu__are_equal(const phd_master_slave_interfaces__msg__MtiImu * lhs, const phd_master_slave_interfaces__msg__MtiImu * rhs);

/// Copy a msg/MtiImu message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
bool
phd_master_slave_interfaces__msg__MtiImu__copy(
  const phd_master_slave_interfaces__msg__MtiImu * input,
  phd_master_slave_interfaces__msg__MtiImu * output);

/// Initialize array of msg/MtiImu messages.
/**
 * It allocates the memory for the number of elements and calls
 * phd_master_slave_interfaces__msg__MtiImu__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
bool
phd_master_slave_interfaces__msg__MtiImu__Sequence__init(phd_master_slave_interfaces__msg__MtiImu__Sequence * array, size_t size);

/// Finalize array of msg/MtiImu messages.
/**
 * It calls
 * phd_master_slave_interfaces__msg__MtiImu__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
void
phd_master_slave_interfaces__msg__MtiImu__Sequence__fini(phd_master_slave_interfaces__msg__MtiImu__Sequence * array);

/// Create array of msg/MtiImu messages.
/**
 * It allocates the memory for the array and calls
 * phd_master_slave_interfaces__msg__MtiImu__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
phd_master_slave_interfaces__msg__MtiImu__Sequence *
phd_master_slave_interfaces__msg__MtiImu__Sequence__create(size_t size);

/// Destroy array of msg/MtiImu messages.
/**
 * It calls
 * phd_master_slave_interfaces__msg__MtiImu__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
void
phd_master_slave_interfaces__msg__MtiImu__Sequence__destroy(phd_master_slave_interfaces__msg__MtiImu__Sequence * array);

/// Check for msg/MtiImu message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
bool
phd_master_slave_interfaces__msg__MtiImu__Sequence__are_equal(const phd_master_slave_interfaces__msg__MtiImu__Sequence * lhs, const phd_master_slave_interfaces__msg__MtiImu__Sequence * rhs);

/// Copy an array of msg/MtiImu messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_phd_master_slave_interfaces
bool
phd_master_slave_interfaces__msg__MtiImu__Sequence__copy(
  const phd_master_slave_interfaces__msg__MtiImu__Sequence * input,
  phd_master_slave_interfaces__msg__MtiImu__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MTI_IMU__FUNCTIONS_H_
