// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from phd_master_slave_interfaces:msg/MasterMachineUI.idl
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__BUILDER_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "phd_master_slave_interfaces/msg/detail/master_machine_ui__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace phd_master_slave_interfaces
{

namespace msg
{

namespace builder
{

class Init_MasterMachineUI_data_valid
{
public:
  explicit Init_MasterMachineUI_data_valid(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  ::phd_master_slave_interfaces::msg::MasterMachineUI data_valid(::phd_master_slave_interfaces::msg::MasterMachineUI::_data_valid_type arg)
  {
    msg_.data_valid = std::move(arg);
    return std::move(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_timestamp
{
public:
  explicit Init_MasterMachineUI_timestamp(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_data_valid timestamp(::phd_master_slave_interfaces::msg::MasterMachineUI::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_MasterMachineUI_data_valid(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_lower_machine_timer
{
public:
  explicit Init_MasterMachineUI_lower_machine_timer(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_timestamp lower_machine_timer(::phd_master_slave_interfaces::msg::MasterMachineUI::_lower_machine_timer_type arg)
  {
    msg_.lower_machine_timer = std::move(arg);
    return Init_MasterMachineUI_timestamp(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_upper_computer_timer
{
public:
  explicit Init_MasterMachineUI_upper_computer_timer(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_lower_machine_timer upper_computer_timer(::phd_master_slave_interfaces::msg::MasterMachineUI::_upper_computer_timer_type arg)
  {
    msg_.upper_computer_timer = std::move(arg);
    return Init_MasterMachineUI_lower_machine_timer(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_protect_time
{
public:
  explicit Init_MasterMachineUI_protect_time(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_upper_computer_timer protect_time(::phd_master_slave_interfaces::msg::MasterMachineUI::_protect_time_type arg)
  {
    msg_.protect_time = std::move(arg);
    return Init_MasterMachineUI_upper_computer_timer(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_protect_height
{
public:
  explicit Init_MasterMachineUI_protect_height(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_protect_time protect_height(::phd_master_slave_interfaces::msg::MasterMachineUI::_protect_height_type arg)
  {
    msg_.protect_height = std::move(arg);
    return Init_MasterMachineUI_protect_time(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_protect_depth
{
public:
  explicit Init_MasterMachineUI_protect_depth(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_protect_height protect_depth(::phd_master_slave_interfaces::msg::MasterMachineUI::_protect_depth_type arg)
  {
    msg_.protect_depth = std::move(arg);
    return Init_MasterMachineUI_protect_height(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_auto_y_distance
{
public:
  explicit Init_MasterMachineUI_auto_y_distance(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_protect_depth auto_y_distance(::phd_master_slave_interfaces::msg::MasterMachineUI::_auto_y_distance_type arg)
  {
    msg_.auto_y_distance = std::move(arg);
    return Init_MasterMachineUI_protect_depth(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_auto_x_distance
{
public:
  explicit Init_MasterMachineUI_auto_x_distance(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_auto_y_distance auto_x_distance(::phd_master_slave_interfaces::msg::MasterMachineUI::_auto_x_distance_type arg)
  {
    msg_.auto_x_distance = std::move(arg);
    return Init_MasterMachineUI_auto_y_distance(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_auto_depth
{
public:
  explicit Init_MasterMachineUI_auto_depth(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_auto_x_distance auto_depth(::phd_master_slave_interfaces::msg::MasterMachineUI::_auto_depth_type arg)
  {
    msg_.auto_depth = std::move(arg);
    return Init_MasterMachineUI_auto_x_distance(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_auto_yaw
{
public:
  explicit Init_MasterMachineUI_auto_yaw(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_auto_depth auto_yaw(::phd_master_slave_interfaces::msg::MasterMachineUI::_auto_yaw_type arg)
  {
    msg_.auto_yaw = std::move(arg);
    return Init_MasterMachineUI_auto_depth(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_auto_y_velocity
{
public:
  explicit Init_MasterMachineUI_auto_y_velocity(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_auto_yaw auto_y_velocity(::phd_master_slave_interfaces::msg::MasterMachineUI::_auto_y_velocity_type arg)
  {
    msg_.auto_y_velocity = std::move(arg);
    return Init_MasterMachineUI_auto_yaw(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_auto_x_velocity
{
public:
  explicit Init_MasterMachineUI_auto_x_velocity(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_auto_y_velocity auto_x_velocity(::phd_master_slave_interfaces::msg::MasterMachineUI::_auto_x_velocity_type arg)
  {
    msg_.auto_x_velocity = std::move(arg);
    return Init_MasterMachineUI_auto_y_velocity(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_rbd
{
public:
  explicit Init_MasterMachineUI_manual_rbd(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_auto_x_velocity manual_rbd(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_rbd_type arg)
  {
    msg_.manual_rbd = std::move(arg);
    return Init_MasterMachineUI_auto_x_velocity(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_rbu
{
public:
  explicit Init_MasterMachineUI_manual_rbu(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_manual_rbd manual_rbu(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_rbu_type arg)
  {
    msg_.manual_rbu = std::move(arg);
    return Init_MasterMachineUI_manual_rbd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_lbd
{
public:
  explicit Init_MasterMachineUI_manual_lbd(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_manual_rbu manual_lbd(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_lbd_type arg)
  {
    msg_.manual_lbd = std::move(arg);
    return Init_MasterMachineUI_manual_rbu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_lbu
{
public:
  explicit Init_MasterMachineUI_manual_lbu(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_manual_lbd manual_lbu(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_lbu_type arg)
  {
    msg_.manual_lbu = std::move(arg);
    return Init_MasterMachineUI_manual_lbd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_rfd
{
public:
  explicit Init_MasterMachineUI_manual_rfd(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_manual_lbu manual_rfd(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_rfd_type arg)
  {
    msg_.manual_rfd = std::move(arg);
    return Init_MasterMachineUI_manual_lbu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_rfu
{
public:
  explicit Init_MasterMachineUI_manual_rfu(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_manual_rfd manual_rfu(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_rfu_type arg)
  {
    msg_.manual_rfu = std::move(arg);
    return Init_MasterMachineUI_manual_rfd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_lfd
{
public:
  explicit Init_MasterMachineUI_manual_lfd(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_manual_rfu manual_lfd(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_lfd_type arg)
  {
    msg_.manual_lfd = std::move(arg);
    return Init_MasterMachineUI_manual_rfu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_manual_lfu
{
public:
  explicit Init_MasterMachineUI_manual_lfu(::phd_master_slave_interfaces::msg::MasterMachineUI & msg)
  : msg_(msg)
  {}
  Init_MasterMachineUI_manual_lfd manual_lfu(::phd_master_slave_interfaces::msg::MasterMachineUI::_manual_lfu_type arg)
  {
    msg_.manual_lfu = std::move(arg);
    return Init_MasterMachineUI_manual_lfd(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

class Init_MasterMachineUI_control_mode
{
public:
  Init_MasterMachineUI_control_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MasterMachineUI_manual_lfu control_mode(::phd_master_slave_interfaces::msg::MasterMachineUI::_control_mode_type arg)
  {
    msg_.control_mode = std::move(arg);
    return Init_MasterMachineUI_manual_lfu(msg_);
  }

private:
  ::phd_master_slave_interfaces::msg::MasterMachineUI msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::phd_master_slave_interfaces::msg::MasterMachineUI>()
{
  return phd_master_slave_interfaces::msg::builder::Init_MasterMachineUI_control_mode();
}

}  // namespace phd_master_slave_interfaces

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__DETAIL__MASTER_MACHINE_UI__BUILDER_HPP_
