// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from phd_master_slave_interfaces:msg/ThrusterStatus.idl
// generated code does not contain a copyright notice
#include "phd_master_slave_interfaces/msg/detail/thruster_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
phd_master_slave_interfaces__msg__ThrusterStatus__init(phd_master_slave_interfaces__msg__ThrusterStatus * msg)
{
  if (!msg) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    phd_master_slave_interfaces__msg__ThrusterStatus__fini(msg);
    return false;
  }
  // set_power_lfu
  // set_power_lfd
  // set_power_rfu
  // set_power_rfd
  // set_power_lbu
  // set_power_lbd
  // set_power_rbu
  // set_power_rbd
  // actual_power_lfu
  // actual_power_lfd
  // actual_power_rfu
  // actual_power_rfd
  // actual_power_lbu
  // actual_power_lbd
  // actual_power_rbu
  // actual_power_rbd
  // data_valid
  // temperature
  return true;
}

void
phd_master_slave_interfaces__msg__ThrusterStatus__fini(phd_master_slave_interfaces__msg__ThrusterStatus * msg)
{
  if (!msg) {
    return;
  }
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
  // set_power_lfu
  // set_power_lfd
  // set_power_rfu
  // set_power_rfd
  // set_power_lbu
  // set_power_lbd
  // set_power_rbu
  // set_power_rbd
  // actual_power_lfu
  // actual_power_lfd
  // actual_power_rfu
  // actual_power_rfd
  // actual_power_lbu
  // actual_power_lbd
  // actual_power_rbu
  // actual_power_rbd
  // data_valid
  // temperature
}

bool
phd_master_slave_interfaces__msg__ThrusterStatus__are_equal(const phd_master_slave_interfaces__msg__ThrusterStatus * lhs, const phd_master_slave_interfaces__msg__ThrusterStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  // set_power_lfu
  if (lhs->set_power_lfu != rhs->set_power_lfu) {
    return false;
  }
  // set_power_lfd
  if (lhs->set_power_lfd != rhs->set_power_lfd) {
    return false;
  }
  // set_power_rfu
  if (lhs->set_power_rfu != rhs->set_power_rfu) {
    return false;
  }
  // set_power_rfd
  if (lhs->set_power_rfd != rhs->set_power_rfd) {
    return false;
  }
  // set_power_lbu
  if (lhs->set_power_lbu != rhs->set_power_lbu) {
    return false;
  }
  // set_power_lbd
  if (lhs->set_power_lbd != rhs->set_power_lbd) {
    return false;
  }
  // set_power_rbu
  if (lhs->set_power_rbu != rhs->set_power_rbu) {
    return false;
  }
  // set_power_rbd
  if (lhs->set_power_rbd != rhs->set_power_rbd) {
    return false;
  }
  // actual_power_lfu
  if (lhs->actual_power_lfu != rhs->actual_power_lfu) {
    return false;
  }
  // actual_power_lfd
  if (lhs->actual_power_lfd != rhs->actual_power_lfd) {
    return false;
  }
  // actual_power_rfu
  if (lhs->actual_power_rfu != rhs->actual_power_rfu) {
    return false;
  }
  // actual_power_rfd
  if (lhs->actual_power_rfd != rhs->actual_power_rfd) {
    return false;
  }
  // actual_power_lbu
  if (lhs->actual_power_lbu != rhs->actual_power_lbu) {
    return false;
  }
  // actual_power_lbd
  if (lhs->actual_power_lbd != rhs->actual_power_lbd) {
    return false;
  }
  // actual_power_rbu
  if (lhs->actual_power_rbu != rhs->actual_power_rbu) {
    return false;
  }
  // actual_power_rbd
  if (lhs->actual_power_rbd != rhs->actual_power_rbd) {
    return false;
  }
  // data_valid
  if (lhs->data_valid != rhs->data_valid) {
    return false;
  }
  // temperature
  if (lhs->temperature != rhs->temperature) {
    return false;
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__ThrusterStatus__copy(
  const phd_master_slave_interfaces__msg__ThrusterStatus * input,
  phd_master_slave_interfaces__msg__ThrusterStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  // set_power_lfu
  output->set_power_lfu = input->set_power_lfu;
  // set_power_lfd
  output->set_power_lfd = input->set_power_lfd;
  // set_power_rfu
  output->set_power_rfu = input->set_power_rfu;
  // set_power_rfd
  output->set_power_rfd = input->set_power_rfd;
  // set_power_lbu
  output->set_power_lbu = input->set_power_lbu;
  // set_power_lbd
  output->set_power_lbd = input->set_power_lbd;
  // set_power_rbu
  output->set_power_rbu = input->set_power_rbu;
  // set_power_rbd
  output->set_power_rbd = input->set_power_rbd;
  // actual_power_lfu
  output->actual_power_lfu = input->actual_power_lfu;
  // actual_power_lfd
  output->actual_power_lfd = input->actual_power_lfd;
  // actual_power_rfu
  output->actual_power_rfu = input->actual_power_rfu;
  // actual_power_rfd
  output->actual_power_rfd = input->actual_power_rfd;
  // actual_power_lbu
  output->actual_power_lbu = input->actual_power_lbu;
  // actual_power_lbd
  output->actual_power_lbd = input->actual_power_lbd;
  // actual_power_rbu
  output->actual_power_rbu = input->actual_power_rbu;
  // actual_power_rbd
  output->actual_power_rbd = input->actual_power_rbd;
  // data_valid
  output->data_valid = input->data_valid;
  // temperature
  output->temperature = input->temperature;
  return true;
}

phd_master_slave_interfaces__msg__ThrusterStatus *
phd_master_slave_interfaces__msg__ThrusterStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__ThrusterStatus * msg = (phd_master_slave_interfaces__msg__ThrusterStatus *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__ThrusterStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(phd_master_slave_interfaces__msg__ThrusterStatus));
  bool success = phd_master_slave_interfaces__msg__ThrusterStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
phd_master_slave_interfaces__msg__ThrusterStatus__destroy(phd_master_slave_interfaces__msg__ThrusterStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    phd_master_slave_interfaces__msg__ThrusterStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__init(phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__ThrusterStatus * data = NULL;

  if (size) {
    data = (phd_master_slave_interfaces__msg__ThrusterStatus *)allocator.zero_allocate(size, sizeof(phd_master_slave_interfaces__msg__ThrusterStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = phd_master_slave_interfaces__msg__ThrusterStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        phd_master_slave_interfaces__msg__ThrusterStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__fini(phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      phd_master_slave_interfaces__msg__ThrusterStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

phd_master_slave_interfaces__msg__ThrusterStatus__Sequence *
phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * array = (phd_master_slave_interfaces__msg__ThrusterStatus__Sequence *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__ThrusterStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__destroy(phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__are_equal(const phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * lhs, const phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!phd_master_slave_interfaces__msg__ThrusterStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__ThrusterStatus__Sequence__copy(
  const phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * input,
  phd_master_slave_interfaces__msg__ThrusterStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(phd_master_slave_interfaces__msg__ThrusterStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    phd_master_slave_interfaces__msg__ThrusterStatus * data =
      (phd_master_slave_interfaces__msg__ThrusterStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!phd_master_slave_interfaces__msg__ThrusterStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          phd_master_slave_interfaces__msg__ThrusterStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!phd_master_slave_interfaces__msg__ThrusterStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
