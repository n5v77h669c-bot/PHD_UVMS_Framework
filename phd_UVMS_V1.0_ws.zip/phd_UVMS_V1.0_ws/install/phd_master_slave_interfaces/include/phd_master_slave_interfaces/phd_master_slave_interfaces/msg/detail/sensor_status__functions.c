// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from phd_master_slave_interfaces:msg/SensorStatus.idl
// generated code does not contain a copyright notice
#include "phd_master_slave_interfaces/msg/detail/sensor_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
phd_master_slave_interfaces__msg__SensorStatus__init(phd_master_slave_interfaces__msg__SensorStatus * msg)
{
  if (!msg) {
    return false;
  }
  // dvl_set_status
  // light_set_status
  // front_sonar_set_status
  // scanning_sonar_set_status
  // dvl_cur_status
  // light_cur_status
  // front_sonar_cur_status
  // scanning_sonar_cur_status
  // water_leak_status
  // data_valid
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    phd_master_slave_interfaces__msg__SensorStatus__fini(msg);
    return false;
  }
  return true;
}

void
phd_master_slave_interfaces__msg__SensorStatus__fini(phd_master_slave_interfaces__msg__SensorStatus * msg)
{
  if (!msg) {
    return;
  }
  // dvl_set_status
  // light_set_status
  // front_sonar_set_status
  // scanning_sonar_set_status
  // dvl_cur_status
  // light_cur_status
  // front_sonar_cur_status
  // scanning_sonar_cur_status
  // water_leak_status
  // data_valid
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
}

bool
phd_master_slave_interfaces__msg__SensorStatus__are_equal(const phd_master_slave_interfaces__msg__SensorStatus * lhs, const phd_master_slave_interfaces__msg__SensorStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // dvl_set_status
  if (lhs->dvl_set_status != rhs->dvl_set_status) {
    return false;
  }
  // light_set_status
  if (lhs->light_set_status != rhs->light_set_status) {
    return false;
  }
  // front_sonar_set_status
  if (lhs->front_sonar_set_status != rhs->front_sonar_set_status) {
    return false;
  }
  // scanning_sonar_set_status
  if (lhs->scanning_sonar_set_status != rhs->scanning_sonar_set_status) {
    return false;
  }
  // dvl_cur_status
  if (lhs->dvl_cur_status != rhs->dvl_cur_status) {
    return false;
  }
  // light_cur_status
  if (lhs->light_cur_status != rhs->light_cur_status) {
    return false;
  }
  // front_sonar_cur_status
  if (lhs->front_sonar_cur_status != rhs->front_sonar_cur_status) {
    return false;
  }
  // scanning_sonar_cur_status
  if (lhs->scanning_sonar_cur_status != rhs->scanning_sonar_cur_status) {
    return false;
  }
  // water_leak_status
  if (lhs->water_leak_status != rhs->water_leak_status) {
    return false;
  }
  // data_valid
  if (lhs->data_valid != rhs->data_valid) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__SensorStatus__copy(
  const phd_master_slave_interfaces__msg__SensorStatus * input,
  phd_master_slave_interfaces__msg__SensorStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // dvl_set_status
  output->dvl_set_status = input->dvl_set_status;
  // light_set_status
  output->light_set_status = input->light_set_status;
  // front_sonar_set_status
  output->front_sonar_set_status = input->front_sonar_set_status;
  // scanning_sonar_set_status
  output->scanning_sonar_set_status = input->scanning_sonar_set_status;
  // dvl_cur_status
  output->dvl_cur_status = input->dvl_cur_status;
  // light_cur_status
  output->light_cur_status = input->light_cur_status;
  // front_sonar_cur_status
  output->front_sonar_cur_status = input->front_sonar_cur_status;
  // scanning_sonar_cur_status
  output->scanning_sonar_cur_status = input->scanning_sonar_cur_status;
  // water_leak_status
  output->water_leak_status = input->water_leak_status;
  // data_valid
  output->data_valid = input->data_valid;
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  return true;
}

phd_master_slave_interfaces__msg__SensorStatus *
phd_master_slave_interfaces__msg__SensorStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__SensorStatus * msg = (phd_master_slave_interfaces__msg__SensorStatus *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__SensorStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(phd_master_slave_interfaces__msg__SensorStatus));
  bool success = phd_master_slave_interfaces__msg__SensorStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
phd_master_slave_interfaces__msg__SensorStatus__destroy(phd_master_slave_interfaces__msg__SensorStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    phd_master_slave_interfaces__msg__SensorStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
phd_master_slave_interfaces__msg__SensorStatus__Sequence__init(phd_master_slave_interfaces__msg__SensorStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__SensorStatus * data = NULL;

  if (size) {
    data = (phd_master_slave_interfaces__msg__SensorStatus *)allocator.zero_allocate(size, sizeof(phd_master_slave_interfaces__msg__SensorStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = phd_master_slave_interfaces__msg__SensorStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        phd_master_slave_interfaces__msg__SensorStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
phd_master_slave_interfaces__msg__SensorStatus__Sequence__fini(phd_master_slave_interfaces__msg__SensorStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      phd_master_slave_interfaces__msg__SensorStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

phd_master_slave_interfaces__msg__SensorStatus__Sequence *
phd_master_slave_interfaces__msg__SensorStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  phd_master_slave_interfaces__msg__SensorStatus__Sequence * array = (phd_master_slave_interfaces__msg__SensorStatus__Sequence *)allocator.allocate(sizeof(phd_master_slave_interfaces__msg__SensorStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = phd_master_slave_interfaces__msg__SensorStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
phd_master_slave_interfaces__msg__SensorStatus__Sequence__destroy(phd_master_slave_interfaces__msg__SensorStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    phd_master_slave_interfaces__msg__SensorStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
phd_master_slave_interfaces__msg__SensorStatus__Sequence__are_equal(const phd_master_slave_interfaces__msg__SensorStatus__Sequence * lhs, const phd_master_slave_interfaces__msg__SensorStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!phd_master_slave_interfaces__msg__SensorStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
phd_master_slave_interfaces__msg__SensorStatus__Sequence__copy(
  const phd_master_slave_interfaces__msg__SensorStatus__Sequence * input,
  phd_master_slave_interfaces__msg__SensorStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(phd_master_slave_interfaces__msg__SensorStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    phd_master_slave_interfaces__msg__SensorStatus * data =
      (phd_master_slave_interfaces__msg__SensorStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!phd_master_slave_interfaces__msg__SensorStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          phd_master_slave_interfaces__msg__SensorStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!phd_master_slave_interfaces__msg__SensorStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
