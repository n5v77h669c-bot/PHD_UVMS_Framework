// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PHD_MASTER_SLAVE_INTERFACES__MSG__MTI_IMU_HPP_
#define PHD_MASTER_SLAVE_INTERFACES__MSG__MTI_IMU_HPP_

#include "phd_master_slave_interfaces/msg/detail/mti_imu__struct.hpp"
#include "phd_master_slave_interfaces/msg/detail/mti_imu__builder.hpp"
#include "phd_master_slave_interfaces/msg/detail/mti_imu__traits.hpp"
#include "phd_master_slave_interfaces/msg/detail/mti_imu__type_support.hpp"

#endif  // PHD_MASTER_SLAVE_INTERFACES__MSG__MTI_IMU_HPP_
