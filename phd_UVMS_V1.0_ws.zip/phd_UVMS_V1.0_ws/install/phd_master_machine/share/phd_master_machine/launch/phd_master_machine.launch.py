#!/usr/bin/env python3
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    rqt_main_launch = Node(
        package='phd_master_machine',
        executable='rqt_main',
        name='rqt_main',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info'],
        parameters=[{
            'status_update_rate': 20.0,
            'rov_name': 'heu_rov',
            }],
        remappings=[
            ('/motionCtrl', '/masterMachine/motionCtrl'),
            ]
    )

    thrusters_ctrl_interfaces_launch = Node(
        package='phd_master_machine',
        executable='thrusters_ctrl_interfaces',
        name='thrusters_ctrl_interfaces',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info'],
        parameters=[{
            # 话题名称
            'motion_ctrl_topic': '/masterMachine/motionCtrl',
            'thrusters_command_topic': '/masterMachine/thrusters_command',
            'force_to_power_scale': 0.1,
            'max_power': 100.0,
            'min_power': -100.0,
            'deadband_enabled': True,
            'force_deadband': 1.0,
            'default_mode': 0,
            'command_publish_hz': 50.0,
            'timeout_seconds': 1.0,
        }],
        remappings=[
            ('/thrusters_command', '/masterMachine/thrusters_command'),
            ]
    )

    pose_sensor_interfaces_launch = Node(
        package='phd_master_machine',
        executable='pose_sensor_interfaces',
        name='pose_sensor_interfaces',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info'],
        parameters=[{
            'imu_topic': '/sensors/imu_data',
            'depth_topic': '/sensors/depth_data',
            'odom_topic': '/odom',
            'odom_frame_id': 'odom',
            'base_frame_id': 'base_footprint',
            'publish_hz': 50.0,
        }],
    )
    
    
    return LaunchDescription([
        rqt_main_launch,
        thrusters_ctrl_interfaces_launch,
        pose_sensor_interfaces_launch,
    ])