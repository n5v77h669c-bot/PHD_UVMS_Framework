#!/usr/bin/env python3
"""
ROV状态监控模块
负责更新显示所有状态信息，包括位姿、速度、电源、推力器等
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
from PyQt5.QtCore import QObject, QTimer, Qt, pyqtSignal
from PyQt5.QtWidgets import QLabel, QLineEdit, QGroupBox
from PyQt5.QtGui import QColor, QPalette

from geometry_msgs.msg import Twist, Pose, Vector3
from sensor_msgs.msg import Imu, NavSatFix, FluidPressure
from std_msgs.msg import Float32, Float64, Int32, Bool, String
from nav_msgs.msg import Odometry
import math
import threading
from typing import Dict, Optional
from phd_master_slave_interfaces.msg import MtiImu
from phd_master_slave_interfaces.msg import Depth
from phd_master_slave_interfaces.msg import ThrusterStatus

class ROVStatusMonitor(QObject):
    """
    ROV状态监控模块
    实时更新UI显示的所有状态信息
    """
    
    # 信号定义（用于线程间通信）
    update_signal = pyqtSignal(dict)  # 更新UI的信号
    
    def __init__(self, ui_widget, ros_node: Node, update_rate: float = 20.0):
        super().__init__()
        
        self.ui = ui_widget  # UI控件
        self.ros_node = ros_node  # ROS节点
        self.update_rate = update_rate  # 更新频率
        
        # 线程安全锁
        self.lock = threading.Lock()
        
        # 状态数据存储
        self.status_data = {
            # 姿态信息
            'status_cur_yaw': 0.0, 'status_cur_pitch': 0.0, 'status_cur_roll': 0.0,
            'status_exp_yaw': 0.0, 'status_exp_pitch': 0.0, 'status_exp_roll': 0.0,

            'status_cur_depth': 0.0, 'status_exp_depth': 0.0, 

            # 位置信息

            # 速度信息

            # 电源信息
            
            # 推力器信息
            'status_prop_lfu': 0.0, 'status_prop_lfd': 0.0,  # 左前
            'status_prop_rfu': 0.0, 'status_prop_rfd': 0.0,  # 右前
            'status_prop_lbu': 0.0, 'status_prop_lbd': 0.0,  # 左后
            'status_prop_rbu': 0.0, 'status_prop_rbd': 0.0,  # 右后
            
            # 其他信息
            'status_ctrl_mode': '手动', 'sonar_type': '未知',
            'dis_sonar': 0.0, 'is_leak': '未漏水',
        }
        
        # UI控件映射字典
        self.ui_controls = {}
        
        # 初始化
        self.setup_ui_controls()

        # QoS配置 - 修复：使用正确的枚举值
        self.qos_profile = QoSProfile(
            depth=50,  # 较大的缓冲区
            reliability=QoSReliabilityPolicy.BEST_EFFORT,  # 允许丢包
            history=QoSHistoryPolicy.KEEP_LAST,
            durability=QoSDurabilityPolicy.VOLATILE 
        )
        # self.setup_ros_subscribers()

        self.ros_node.imu_sub = self.ros_node.create_subscription(
            MtiImu,
            '/sensors/imu_data',
            self.imu_callback,
            self.qos_profile,
        )
            
        # 深度传感器
        self.ros_node.depth_sub = self.ros_node.create_subscription(
            Depth,
            '/sensors/depth_data',
            self.depth_callback,
            self.qos_profile,
        )
        
        self.ros_node.prop_sub = self.ros_node.create_subscription(
            ThrusterStatus,
            '/thrusters/status',
            self.thrusters_callback,
            self.qos_profile,
        )
        self.ros_node.get_logger().info("ROS订阅器设置完成")
        
        self.setup_update_timer()
        
        # 连接更新信号
        self.update_signal.connect(self.update_ui_from_data)
        
        self.ros_node.get_logger().info(f"ROV状态监控模块初始化完成，更新频率: {update_rate}Hz")
    
    def setup_ui_controls(self):
        """设置UI控件映射"""
        
        # ==================== 姿态信息 ====================
        self.ui_controls.update({
            'status_cur_yaw': self.ui.findChild(QLineEdit, 'status_cur_yaw'),
            'status_cur_pitch': self.ui.findChild(QLineEdit, 'status_cur_pitch'),
            'status_cur_roll': self.ui.findChild(QLineEdit, 'status_cur_roll'),
            'status_exp_yaw': self.ui.findChild(QLineEdit, 'status_exp_yaw'),
            'status_exp_pitch': self.ui.findChild(QLineEdit, 'status_exp_pitch'),
            'status_exp_roll': self.ui.findChild(QLineEdit, 'status_exp_roll'),
            
            # 位置信息 
            
            # 速度信息
            
            # 电源信息
            
            # 推力器信息
            'status_prop_lfu': self.ui.findChild(QLineEdit, 'status_prop_lfu'),
            'status_prop_lfd': self.ui.findChild(QLineEdit, 'status_prop_lfd'),
            'status_prop_rfu': self.ui.findChild(QLineEdit, 'status_prop_rfu'),
            'status_prop_rfd': self.ui.findChild(QLineEdit, 'status_prop_rfd'),
            'status_prop_lbu': self.ui.findChild(QLineEdit, 'status_prop_lbu'),
            'status_prop_lbd': self.ui.findChild(QLineEdit, 'status_prop_lbd'),
            'status_prop_rbu': self.ui.findChild(QLineEdit, 'status_prop_rbu'),
            'status_prop_rbd': self.ui.findChild(QLineEdit, 'status_prop_rbd'),
            
            # 其他信息
            'status_ctrl_mode': self.ui.findChild(QLineEdit, 'status_ctrl_mode'),
            'sonar_type': self.ui.findChild(QLineEdit, 'sonar_type'),
            'dis_sonar': self.ui.findChild(QLineEdit, 'dis_sonar'),
            'is_leak': self.ui.findChild(QLineEdit, 'is_leak'),
        })
        
        # 验证所有控件是否找到
        missing = [key for key, ctrl in self.ui_controls.items() if ctrl is None]
        if missing:
            self.ros_node.get_logger().warn(f"未找到UI控件: {missing}")
        else:
            self.ros_node.get_logger().info(f"找到 {len(self.ui_controls)} 个UI控件")
    

    
    def setup_update_timer(self):
        """设置更新定时器"""
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.on_update_timeout)
        interval_ms = int(1000 / self.update_rate)
        self.update_timer.start(interval_ms)
        self.ros_node.get_logger().info(f"UI更新定时器启动: {interval_ms}ms间隔")
    
    def on_update_timeout(self):
        """定时器触发时调用"""
        # 使用线程锁保护数据
        with self.lock:
            data_copy = self.status_data.copy()
        # 通过信号发送到UI线程更新
        self.update_signal.emit(data_copy)
    
    # ==================== ROS回调函数 ====================
    
    def imu_callback(self, msg):
        with self.lock:
            # imu调整过位置，imu坐标系跟rviz坐标系不同
            self.status_data['status_cur_yaw'] = msg.yaw
            self.status_data['status_cur_pitch'] = msg.roll
            self.status_data['status_cur_roll'] = msg.pitch
            # self.ros_node.get_logger().info(
            #     f"yaw:{self.status_data['status_cur_yaw']:.1f} | "
            #     f"pitch:{self.status_data['status_cur_pitch']:.1f} | "
            #     f"roll:self.status_data['status_cur_roll']",
            #     throttle_duration_sec=1.0
            # )
    
    def depth_callback(self, msg):
        with self.lock:
            self.status_data['status_cur_depth'] = msg.depth
    
    def thrusters_callback(self, msg):
        """推力器状态回调"""
        with self.lock:
            self.status_data['status_prop_lfu'] = msg.actual_power_lfu - 100
            self.status_data['status_prop_lfd'] = msg.actual_power_lfd - 100
            self.status_data['status_prop_rfu'] = msg.actual_power_rfu - 100
            self.status_data['status_prop_rfd'] = msg.actual_power_rfd - 100
            self.status_data['status_prop_lbu'] = msg.actual_power_lbu - 100
            self.status_data['status_prop_lbd'] = msg.actual_power_lbd - 100
            self.status_data['status_prop_rbu'] = msg.actual_power_rbu - 100
            self.status_data['status_prop_rbd'] = msg.actual_power_rbd - 100

    def leak_callback(self, msg: Bool):
        """漏水检测回调"""
        with self.lock:
            self.status_data['is_leak'] = '漏水' if msg.data else '未漏水'
    
    # ==================== UI更新函数 ====================
    
    def update_ui_from_data(self):
        """从数据字典更新UI"""
        try:
            self.ui.status_cur_yaw.setText(f"{self.status_data['status_cur_yaw']:.1f}°")
            self.ui.status_cur_pitch.setText(f"{self.status_data['status_cur_pitch']:.1f}°")
            self.ui.status_cur_roll.setText(f"{self.status_data['status_cur_roll']:.1f}°")

            self.ui.status_cur_depth.setText(f"{self.status_data['status_cur_depth']:.2f} m")

            self.ui.status_prop_lfu.setText(f"{self.status_data['status_prop_lfu']:.0f}%")
            self.ui.status_prop_lfd.setText(f"{self.status_data['status_prop_lfd']:.0f}%")
            self.ui.status_prop_rfu.setText(f"{self.status_data['status_prop_rfu']:.0f}%")
            self.ui.status_prop_rfd.setText(f"{self.status_data['status_prop_rfd']:.0f}%")
            self.ui.status_prop_lbu.setText(f"{self.status_data['status_prop_lbu']:.0f}%")
            self.ui.status_prop_lbd.setText(f"{self.status_data['status_prop_lbd']:.0f}%")
            self.ui.status_prop_rbu.setText(f"{self.status_data['status_prop_rbu']:.0f}%")
            self.ui.status_prop_rbd.setText(f"{self.status_data['status_prop_rbd']:.0f}%")

        except Exception as e:
            print(f"更新UI出错: {e}")
                

    
    def set_value_warning_color(self, ctrl: QLineEdit, key: str, value):
        """根据值设置警告颜色"""
        if isinstance(value, (int, float)):
            # 深度警告
            if 'depth' in key:
                if value > 300.0:  # 深度超过300米
                    self.set_control_color(ctrl, QColor(255, 0, 0))  # 红色
                elif value > 200.0:
                    self.set_control_color(ctrl, QColor(255, 165, 0))  # 橙色
                else:
                    self.set_control_color(ctrl, QColor(0, 255, 0))  # 绿色

            # 漏水检测
            elif key == 'ad':
                if '漏水' in str(value):
                    self.set_control_color(ctrl, QColor(255, 0, 0))
                else:
                    self.set_control_color(ctrl, QColor(0, 255, 0))
    
    def set_control_color(self, ctrl: QLineEdit, color: QColor):
        """设置控件文本颜色"""
        palette = ctrl.palette()
        palette.setColor(QPalette.Text, color)
        ctrl.setPalette(palette)
    
    def update_rate_changed(self, new_rate: float):
        """更改更新频率"""
        self.update_rate = new_rate
        interval_ms = int(1000 / new_rate)
        self.update_timer.setInterval(interval_ms)
        self.ros_node.get_logger().info(f"更新频率改为: {new_rate}Hz")
    
    def shutdown(self):
        """关闭模块"""
        self.update_timer.stop()
        self.ros_node.get_logger().info("状态监控模块已关闭")