#!/usr/bin/env python3
"""
传感器控制模块
负责显示传感器状态并发送开关指令
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
from PyQt5.QtCore import QObject, QTimer, Qt, pyqtSignal
from PyQt5.QtWidgets import QWidget, QLineEdit, QPushButton, QComboBox, QSlider
from PyQt5.QtGui import QColor, QPalette

from phd_master_slave_interfaces.msg import SensorStatus
import threading
from typing import Dict, Optional

class SensorControlModule(QObject):
    """
    传感器控制模块
    显示传感器状态，处理开关指令
    """
    
    # 信号定义（用于线程间通信）
    update_signal = pyqtSignal(dict)  # 更新UI的信号
    
    def __init__(self, ui_widget, ros_node: Node, update_rate: float = 20.0):
        super().__init__()
        
        self.ui = ui_widget  # UI控件
        self.ros_node = ros_node  # ROS节点
        self.update_rate = update_rate  # 更新频率
        
        # 线程安全锁
        self.lock = threading.Lock()
        
        # 传感器状态数据
        self.sensor_data = {
            'front_sonar_set_status': 0,      # 设置状态 (上位机指令)
            'front_sonar_cur_status': 0,      # 当前状态 (MCU反馈)
            'front_sonar_sw_status': '未开启', # 显示状态
            
            'light_set_status': 0,
            'light_cur_status': 0,
            'light_sw_status': '未开启',
            
            'dvl_set_status': 0,
            'dvl_cur_status': 0,
            'dvl_sw_status': '未开启',
            
            'scanning_sonar_set_status': 0,
            'scanning_sonar_cur_status': 0,
            'scanning_sonar_sw_status': '未开启',
            
            'water_leak_status': 0,           # 漏水状态
            'water_leak_display': '未漏水',    # 漏水显示
        }
        
        # QoS配置
        self.qos_profile = QoSProfile(
            depth=10,
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST,
            durability=QoSDurabilityPolicy.VOLATILE
        )
        
        # 存储UI控件
        self.ui_controls = {}
        
        # 按钮点击防抖
        self.button_cooldown = {}
        self.cooldown_time = 0.3  # 300ms防抖
        
        # 初始化
        self.setup_ui_controls()
        self.setup_ros_subscribers()
        self.setup_update_timer()
        self.setup_button_connections()
        
        # 连接更新信号
        self.update_signal.connect(self.update_ui_from_data)
        
        self.ros_node.get_logger().info(f"传感器控制模块初始化完成，更新频率: {update_rate}Hz")
    
    def setup_ui_controls(self):
        """设置UI控件映射"""
        
        # ==================== 传感器开关状态显示 ====================
        self.ui_controls.update({
            'front_sonar_sw_status': self.ui.findChild(QLineEdit, 'front_sonar_sw_status'),
            'light_sw_status': self.ui.findChild(QLineEdit, 'light_sw_status'),
            'dvl_sw_status': self.ui.findChild(QLineEdit, 'dvl_sw_status'),
            'scanning_sonar_sw_status': self.ui.findChild(QLineEdit, 'scanning_sonar_sw_status'),
        })
        
        # ==================== 传感器开关按钮 ====================
        self.ui_controls.update({
            'front_sonar_sw': self.ui.findChild(QPushButton, 'front_sonar_sw'),
            'light_sw': self.ui.findChild(QPushButton, 'light_sw'),
            'dvl_sw': self.ui.findChild(QPushButton, 'dvl_sw'),
            'scanning_sonar_sw': self.ui.findChild(QPushButton, 'scanning_sonar_sw'),
        })
        
        # ==================== 传感器参数控件（频率、距离等）====================
        # 这些控件后续自行添加，先保存引用
        self.ui_controls.update({
            'front_sonar_freq': self.ui.findChild(QComboBox, 'front_sonar_freq'),
            'scanning_sonar_freq': self.ui.findChild(QComboBox, 'scanning_sonar_freq'),
            'cam_res': self.ui.findChild(QComboBox, 'cam_res'),
            'video_recorder': self.ui.findChild(QPushButton, 'video_recorder'),
            'cam_recording_status': self.ui.findChild(QLineEdit, 'cam_recording_status'),
        })
        
        # ==================== 滑块控件 ====================
        self.ui_controls.update({
            'horSlider_front_sonar_dist': self.ui.findChild(QSlider, 'horSlider_front_sonar_dist'),
            'horSlider_revove_sona_dist': self.ui.findChild(QSlider, 'horSlider_revove_sona_dist'),
        })
        
        # 验证所有控件是否找到
        missing = [key for key, ctrl in self.ui_controls.items() if ctrl is None]
        if missing:
            self.ros_node.get_logger().warn(f"未找到UI控件: {missing}")
        else:
            self.ros_node.get_logger().info(f"找到 {len(self.ui_controls)} 个UI控件")
    
    def setup_ros_subscribers(self):
        """设置ROS订阅器"""
        # 订阅传感器状态话题
        self.ros_node.sensor_status_sub = self.ros_node.create_subscription(
            SensorStatus,
            '/sw/sensor_sw_status',
            self.sensor_status_callback,
            self.qos_profile,
        )
        self.ros_node.get_logger().info("传感器状态订阅器设置完成")
    
    def setup_update_timer(self):
        """设置更新定时器"""
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.on_update_timeout)
        interval_ms = int(1000 / self.update_rate)
        self.update_timer.start(interval_ms)
        self.ros_node.get_logger().info(f"UI更新定时器启动: {interval_ms}ms间隔")
    
    def setup_button_connections(self):
        """设置按钮连接"""
        # 传感器开关按钮
        button_map = {
            'front_sonar_sw': 'front_sonar',
            'light_sw': 'light',
            'dvl_sw': 'dvl',
            'scanning_sonar_sw': 'scanning_sonar',
        }
        
        for btn_name, sensor_name in button_map.items():
            btn = self.ui_controls.get(btn_name)
            if btn:
                # 使用lambda捕获传感器名称
                btn.clicked.connect(
                    lambda checked, name=sensor_name: self.on_sensor_switch_clicked(name)
                )
                self.ros_node.get_logger().debug(f"连接按钮: {btn_name} -> {sensor_name}")
    
    def on_update_timeout(self):
        """定时器触发时调用"""
        with self.lock:
            data_copy = self.sensor_data.copy()
        # 通过信号发送到UI线程更新
        self.update_signal.emit(data_copy)
    
    # ==================== ROS回调函数 ====================
    
    def sensor_status_callback(self, msg: SensorStatus):
        """传感器状态回调"""
        with self.lock:
            # 更新设置状态（来自上位机指令）
            self.sensor_data['front_sonar_set_status'] = msg.front_sonar_set_status
            self.sensor_data['light_set_status'] = msg.light_set_status
            self.sensor_data['dvl_set_status'] = msg.dvl_set_status
            self.sensor_data['scanning_sonar_set_status'] = msg.scanning_sonar_set_status
            
            # 更新当前状态（来自MCU反馈）
            self.sensor_data['front_sonar_cur_status'] = msg.front_sonar_cur_status
            self.sensor_data['light_cur_status'] = msg.light_cur_status
            self.sensor_data['dvl_cur_status'] = msg.dvl_cur_status
            self.sensor_data['scanning_sonar_cur_status'] = msg.scanning_sonar_cur_status
            
            # 更新显示状态
            self.sensor_data['front_sonar_sw_status'] = '已开启' if msg.front_sonar_cur_status > 0 else '未开启'
            self.sensor_data['light_sw_status'] = '已开启' if msg.light_cur_status > 0 else '未开启'
            self.sensor_data['dvl_sw_status'] = '已开启' if msg.dvl_cur_status > 0 else '未开启'
            self.sensor_data['scanning_sonar_sw_status'] = '已开启' if msg.scanning_sonar_cur_status > 0 else '未开启'
            
            # 更新漏水状态
            self.sensor_data['water_leak_status'] = msg.water_leak_status
            self.sensor_data['water_leak_display'] = '漏水' if msg.water_leak_status > 0 else '未漏水'
            
            # 调试输出（降低频率）
            # self.ros_node.get_logger().debug(
            #     f"传感器状态更新: 前视声纳={msg.front_sonar_cur_status}, "
            #     f"灯={msg.light_cur_status}, "
            #     f"DVL={msg.dvl_cur_status}, "
            #     f"环扫声纳={msg.scanning_sonar_cur_status}",
            #     throttle_duration_sec=1.0
            # )
    
    # ==================== 按钮点击处理 ====================
    
    def on_sensor_switch_clicked(self, sensor_name: str):
        """传感器开关按钮点击处理"""
        # 防抖检查
        import time
        current_time = time.time()
        if sensor_name in self.button_cooldown:
            if current_time - self.button_cooldown[sensor_name] < self.cooldown_time:
                return
        self.button_cooldown[sensor_name] = current_time
        
        try:
            # 获取当前状态并取反
            with self.lock:
                # 根据传感器名称获取当前设置状态
                if sensor_name == 'front_sonar':
                    current_status = self.sensor_data.get('front_sonar_cur_status', 0)
                    new_status = 0 if current_status > 0 else 1
                    self.sensor_data['front_sonar_set_status'] = new_status
                elif sensor_name == 'light':
                    current_status = self.sensor_data.get('light_cur_status', 0)
                    new_status = 0 if current_status > 0 else 1
                    self.sensor_data['light_set_status'] = new_status
                elif sensor_name == 'dvl':
                    current_status = self.sensor_data.get('dvl_cur_status', 0)
                    new_status = 0 if current_status > 0 else 1
                    self.sensor_data['dvl_set_status'] = new_status
                elif sensor_name == 'scanning_sonar':
                    current_status = self.sensor_data.get('scanning_sonar_cur_status', 0)
                    new_status = 0 if current_status > 0 else 1
                    self.sensor_data['scanning_sonar_set_status'] = new_status
                else:
                    return
            
            # 构建并发送指令
            self.send_sensor_command(sensor_name, new_status)
            
            # 更新UI显示
            # status_text = '已开启' if new_status > 0 else '未开启'
            # status_key = f'{sensor_name}_sw_status'
            # with self.lock:
            #     self.sensor_data[status_key] = status_text
            
            # self.ros_node.get_logger().info(
            #     f"传感器 {sensor_name} 开关: {'开启' if new_status > 0 else '关闭'}"
            # )
            
        except Exception as e:
            self.ros_node.get_logger().error(f"处理传感器开关 {sensor_name} 失败: {e}")
    
    def send_sensor_command(self, sensor_name: str, status: int):
        """发送传感器指令到MCU"""
        try:
            # 创建SensorStatus消息
            msg = SensorStatus()
            msg.timestamp = self.ros_node.get_clock().now().to_msg()
            
            # 获取当前所有传感器状态
            with self.lock:
                # 复制当前设置状态
                front_sonar_set = self.sensor_data.get('front_sonar_set_status', 0)
                light_set = self.sensor_data.get('light_set_status', 0)
                dvl_set = self.sensor_data.get('dvl_set_status', 0)
                scanning_sonar_set = self.sensor_data.get('scanning_sonar_set_status', 0)
            
            # 填充消息（设置状态）
            msg.front_sonar_set_status = front_sonar_set
            msg.light_set_status = light_set
            msg.dvl_set_status = dvl_set
            msg.scanning_sonar_set_status = scanning_sonar_set
            
            # 当前状态（从MCU读取，这里填0，实际由MCU反馈）
            msg.front_sonar_cur_status = 0
            msg.light_cur_status = 0
            msg.dvl_cur_status = 0
            msg.scanning_sonar_cur_status = 0
            
            msg.water_leak_status = 0
            msg.data_valid = True
            
            # 发布到指令话题
            self.ros_node.sensor_cmd_pub = self.ros_node.create_publisher(
                SensorStatus,
                '/masterMachine/sensor_sw_cmd',
                self.qos_profile
            )
            self.ros_node.sensor_cmd_pub.publish(msg)
            
            self.ros_node.get_logger().debug(
                f"发送传感器指令: {sensor_name}={status}, "
                f"前视声纳={front_sonar_set}, 灯={light_set}, "
                f"DVL={dvl_set}, 环扫声纳={scanning_sonar_set}"
            )
            
        except Exception as e:
            self.ros_node.get_logger().error(f"发送传感器指令失败: {e}")
    
    # ==================== UI更新函数 ====================
    
    def update_ui_from_data(self, data: dict):
        """从数据字典更新UI"""
        try:
            # 更新开关状态显示
            status_map = {
                'front_sonar_sw_status': 'front_sonar_sw_status',
                'light_sw_status': 'light_sw_status',
                'dvl_sw_status': 'dvl_sw_status',
                'scanning_sonar_sw_status': 'scanning_sonar_sw_status',
            }
            
            for data_key, ui_name in status_map.items():
                ctrl = self.ui_controls.get(ui_name)
                if ctrl:
                    value = data.get(data_key, '未知')
                    ctrl.setText(value)
                    # 根据状态设置颜色
                    self.set_status_color(ctrl, value)
            
            # 如果有漏水状态显示，可以更新
            # leak_ctrl = self.ui_controls.get('is_leak')
            # if leak_ctrl:
            #     leak_value = data.get('water_leak_display', '未漏水')
            #     leak_ctrl.setText(leak_value)
            #     self.set_status_color(leak_ctrl, leak_value, is_leak=True)
            
        except Exception as e:
            self.ros_node.get_logger().error(f"更新UI出错: {e}")
    
    def set_status_color(self, ctrl: QLineEdit, status_text: str, is_leak: bool = False):
        """根据状态设置文本颜色"""
        palette = ctrl.palette()
        
        if is_leak:
            if '漏水' in status_text:
                palette.setColor(QPalette.Text, QColor(255, 0, 0))  # 红色
            else:
                palette.setColor(QPalette.Text, QColor(0, 255, 0))  # 绿色
        else:
            if '已开启' in status_text:
                palette.setColor(QPalette.Text, QColor(0, 255, 0))  # 绿色
            else:
                palette.setColor(QPalette.Text, QColor(255, 0, 0))  # 红色
        
        ctrl.setPalette(palette)
    
    def update_rate_changed(self, new_rate: float):
        """更改更新频率"""
        self.update_rate = new_rate
        interval_ms = int(1000 / new_rate)
        self.update_timer.setInterval(interval_ms)
        self.ros_node.get_logger().info(f"更新频率改为: {new_rate}Hz")
    
    def shutdown(self):
        """关闭模块"""
        self.update_timer.stop()
        self.ros_node.get_logger().info("传感器控制模块已关闭")