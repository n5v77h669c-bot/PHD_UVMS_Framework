#!/usr/bin/env python3
"""
运动参数控制模块
用于配置S面和PID控制器参数
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
from PyQt5.QtCore import QObject, QTimer, Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QLineEdit, QSlider, QPushButton, 
    QRadioButton, QStackedWidget, QMessageBox, QFileDialog
)
from PyQt5.QtGui import QDoubleValidator, QIntValidator
from ament_index_python.packages import get_package_share_directory

from phd_master_slave_interfaces.msg import RobustCtrlPara
import threading
import os
import yaml
from datetime import datetime
from typing import Dict, Optional

class MotionParaControlModule(QObject):
    """
    运动参数控制模块
    管理S面和PID控制器参数，支持YAML文件读写
    """
    
    # 信号定义
    param_updated = pyqtSignal(dict)  # 参数更新信号
    
    def __init__(self, ui_widget, ros_node: Node):
        super().__init__()
        
        self.ui = ui_widget
        self.ros_node = ros_node
        
        # 线程安全锁
        self.lock = threading.Lock()
        
        # 控制模式
        self.MODE_S = 0
        self.MODE_PID = 1
        self.MODE_OTHER = 2
        
        self.current_mode = self.MODE_S

        package_name = 'phd_master_machine'
        # 参数存储路径
        self.param_dir = os.path.join(
            get_package_share_directory(package_name),
            'motion_para'
        )
        # 确保目录存在
        os.makedirs(self.param_dir, exist_ok=True)
        
        # ==================== S面参数 ====================
        self.s_params = {
            # X方向
            'x_k1': 3.5, 'x_k2': 0.3, 'x_f_lim': 50.0,
            # Y方向
            'y_k1': 3.5, 'y_k2': 0.3, 'y_f_lim': 50.0,
            # Z方向
            'z_k1': 1.5, 'z_k2': 0.3, 'z_f_lim': 20.0,
            # Roll
            'roll_k1': 1.2, 'roll_k2': 0.3, 'roll_t_lim': 10.0,
            # Pitch
            'pitch_k1': 1.0, 'pitch_k2': 0.3, 'pitch_t_lim': 8.0,
            # Yaw
            'yaw_k1': 1.5, 'yaw_k2': 0.5, 'yaw_t_lim': 20.0,
        }
        
        # ==================== PID参数 ====================
        self.p_params = {
            # X方向
            'x_kp': 30.0, 'x_ki': 0.0, 'x_kd': 5.0, 'x_f_lim': 50.0,
            # Y方向
            'y_kp': 30.0, 'y_ki': 0.0, 'y_kd': 5.0, 'y_f_lim': 50.0,
            # Z方向
            'z_kp': 30.0, 'z_ki': 0.0, 'z_kd': 5.0, 'z_f_lim': 20.0,
            # Roll
            'roll_kp': 10.0, 'roll_ki': 0.1, 'roll_kd': 2.0, 'roll_t_lim': 10.0,
            # Pitch
            'pitch_kp': 5.0, 'pitch_ki': 0.1, 'pitch_kd': 2.0, 'pitch_t_lim': 8.0,
            # Yaw
            'yaw_kp': 5.0, 'yaw_ki': 0.1, 'yaw_kd': 1.0, 'yaw_t_lim': 20.0,
        }
        
        # UI控件映射
        self.ui_controls = {}
        
        # 参数发布器
        self.param_pub = self.ros_node.create_publisher(
            RobustCtrlPara,
            '/masterMachine/motion_ctrl_para',
            10
        )
        
        # 初始化UI
        self.setup_ui_controls()
        self.setup_signal_connections()
        self.init_ui_values()
        self.setup_stacked_widget()
        
        # 加载默认参数
        self.load_default_params()
        
        self.ros_node.get_logger().info("运动参数控制模块初始化完成")
    
    def setup_ui_controls(self):
        """设置UI控件映射"""
        
        # ==================== 模式选择RadioButton ====================
        self.ui_controls.update({
            's_plane': self.ui.findChild(QRadioButton, 'radioButton_s_plane'),
            'pid': self.ui.findChild(QRadioButton, 'radioButton_pid'),
            'other': self.ui.findChild(QRadioButton, 'radioButton_ohter'),
        })
        
        # ==================== StackedWidget ====================
        self.ui_controls['stacked_widget'] = self.ui.findChild(QStackedWidget, 'stackedWidget')
        
        # ==================== S面参数控件 ====================
        # 滑块
        s_sliders = [
            'slider_x_s_f_lim', 'slider_x_s_k1', 'slider_x_s_k2',
            'slider_y_s_f_lim', 'slider_y_s_k1', 'slider_y_s_k2',
            'slider_z_s_f_lim', 'slider_z_s_k1', 'slider_z_s_k2',
            'slider_roll_s_t_lim', 'slider_roll_s_k1', 'slider_roll_s_k2',
            'slider_pitch_s_t_lim', 'slider_pitch_s_k1', 'slider_pitch_s_k2',
            'slider_yaw_s_t_lim', 'slider_yaw_s_k1', 'slider_yaw_s_k2',
        ]
        for name in s_sliders:
            self.ui_controls[name] = self.ui.findChild(QSlider, name)
        
        # 输入框
        s_inputs = [
            'input_x_s_f_lim', 'input_x_s_k1', 'input_x_s_k2',
            'input_y_s_f_lim', 'input_y_s_k1', 'input_y_s_k2',
            'input_z_s_f_lim', 'input_z_s_k1', 'input_z_s_k2',
            'input_roll_s_t_lim', 'input_roll_s_k1', 'input_roll_s_k2',
            'input_pitch_s_t_lim', 'input_pitch_s_k1', 'input_pitch_s_k2',
            'input_yaw_s_t_lim', 'input_yaw_s_k1', 'input_yaw_s_k2',
        ]
        for name in s_inputs:
            self.ui_controls[name] = self.ui.findChild(QLineEdit, name)
        
        # ==================== PID参数控件 ====================
        p_sliders = [
            'slider_x_pid_f_lim', 'slider_x_pid_kp', 'slider_x_pid_ki', 'slider_x_pid_kd',
            'slider_y_pid_f_lim', 'slider_y_pid_kp', 'slider_y_pid_ki', 'slider_y_pid_kd',
            'slider_z_pid_f_lim', 'slider_z_pid_kp', 'slider_z_pid_ki', 'slider_z_pid_kd',
            'slider_roll_pid_t_lim', 'slider_roll_pid_kp', 'slider_roll_pid_ki', 'slider_roll_pid_kd',
            'slider_pitch_pid_t_lim', 'slider_pitch_pid_kp', 'slider_pitch_pid_ki', 'slider_pitch_pid_kd',
            'slider_yaw_pid_t_lim', 'slider_yaw_pid_kp', 'slider_yaw_pid_ki', 'slider_yaw_pid_kd',
        ]
        for name in p_sliders:
            self.ui_controls[name] = self.ui.findChild(QSlider, name)
        
        p_inputs = [
            'input_x_pid_f_lim', 'input_x_pid_kp', 'input_x_pid_ki', 'input_x_pid_kd',
            'input_y_pid_f_lim', 'input_y_pid_kp', 'input_y_pid_ki', 'input_y_pid_kd',
            'input_z_pid_f_lim', 'input_z_pid_kp', 'input_z_pid_ki', 'input_z_pid_kd',
            'input_roll_pid_t_lim', 'input_roll_pid_kp', 'input_roll_pid_ki', 'input_roll_pid_kd',
            'input_pitch_pid_t_lim', 'input_pitch_pid_kp', 'input_pitch_pid_ki', 'input_pitch_pid_kd',
            'input_yaw_pid_t_lim', 'input_yaw_pid_kp', 'input_yaw_pid_ki', 'input_yaw_pid_kd',
        ]
        for name in p_inputs:
            self.ui_controls[name] = self.ui.findChild(QLineEdit, name)
        
        # ==================== 按钮 ====================
        self.ui_controls['save_s'] = self.ui.findChild(QPushButton, 'save_para_s_plane')
        self.ui_controls['load_s'] = self.ui.findChild(QPushButton, 'load_para_s_plane')
        self.ui_controls['save_p'] = self.ui.findChild(QPushButton, 'save_para_pid')
        self.ui_controls['load_p'] = self.ui.findChild(QPushButton, 'load_para_pid')
        
        # 验证控件
        missing = [key for key, ctrl in self.ui_controls.items() if ctrl is None]
        if missing:
            self.ros_node.get_logger().warn(f"未找到UI控件: {missing}")
    
    def setup_signal_connections(self):
        """设置信号连接"""
        
        # ==================== 模式RadioButton ====================
        s_radio = self.ui_controls.get('s_plane')
        p_radio = self.ui_controls.get('pid')
        
        if s_radio:
            s_radio.toggled.connect(lambda checked: self.on_mode_changed(self.MODE_S) if checked else None)
        if p_radio:
            p_radio.toggled.connect(lambda checked: self.on_mode_changed(self.MODE_PID) if checked else None)
        
        # ==================== S面滑块和输入框 ====================
        s_mappings = [
            ('slider_x_s_k1', 'input_x_s_k1', 'x_k1'),
            ('slider_x_s_k2', 'input_x_s_k2', 'x_k2'),
            ('slider_x_s_f_lim', 'input_x_s_f_lim', 'x_f_lim'),
            ('slider_y_s_k1', 'input_y_s_k1', 'y_k1'),
            ('slider_y_s_k2', 'input_y_s_k2', 'y_k2'),
            ('slider_y_s_f_lim', 'input_y_s_f_lim', 'y_f_lim'),
            ('slider_z_s_k1', 'input_z_s_k1', 'z_k1'),
            ('slider_z_s_k2', 'input_z_s_k2', 'z_k2'),
            ('slider_z_s_f_lim', 'input_z_s_f_lim', 'z_f_lim'),
            ('slider_roll_s_k1', 'input_roll_s_k1', 'roll_k1'),
            ('slider_roll_s_k2', 'input_roll_s_k2', 'roll_k2'),
            ('slider_roll_s_t_lim', 'input_roll_s_t_lim', 'roll_t_lim'),
            ('slider_pitch_s_k1', 'input_pitch_s_k1', 'pitch_k1'),
            ('slider_pitch_s_k2', 'input_pitch_s_k2', 'pitch_k2'),
            ('slider_pitch_s_t_lim', 'input_pitch_s_t_lim', 'pitch_t_lim'),
            ('slider_yaw_s_k1', 'input_yaw_s_k1', 'yaw_k1'),
            ('slider_yaw_s_k2', 'input_yaw_s_k2', 'yaw_k2'),
            ('slider_yaw_s_t_lim', 'input_yaw_s_t_lim', 'yaw_t_lim'),
        ]
        
        for slider_name, input_name, param_key in s_mappings:
            slider = self.ui_controls.get(slider_name)
            line_edit = self.ui_controls.get(input_name)
            if slider and line_edit:
                # 设置输入框验证器
                validator = QDoubleValidator(0.0, 100.0, 2)
                line_edit.setValidator(validator)
                
                # 滑块变化 -> 更新输入框
                slider.valueChanged.connect(
                    lambda value, le=line_edit, key=param_key, is_s=True: 
                    self.on_slider_changed(value, le, key, is_s)
                )
                # 输入框变化 -> 更新滑块
                line_edit.editingFinished.connect(
                    lambda le=line_edit, sl=slider, key=param_key, is_s=True:
                    self.on_input_changed(le, sl, key, is_s)
                )
        
        # ==================== PID滑块和输入框 ====================
        p_mappings = [
            ('slider_x_pid_kp', 'input_x_pid_kp', 'x_kp'),
            ('slider_x_pid_ki', 'input_x_pid_ki', 'x_ki'),
            ('slider_x_pid_kd', 'input_x_pid_kd', 'x_kd'),
            ('slider_x_pid_f_lim', 'input_x_pid_f_lim', 'x_f_lim'),
            ('slider_y_pid_kp', 'input_y_pid_kp', 'y_kp'),
            ('slider_y_pid_ki', 'input_y_pid_ki', 'y_ki'),
            ('slider_y_pid_kd', 'input_y_pid_kd', 'y_kd'),
            ('slider_y_pid_f_lim', 'input_y_pid_f_lim', 'y_f_lim'),
            ('slider_z_pid_kp', 'input_z_pid_kp', 'z_kp'),
            ('slider_z_pid_ki', 'input_z_pid_ki', 'z_ki'),
            ('slider_z_pid_kd', 'input_z_pid_kd', 'z_kd'),
            ('slider_z_pid_f_lim', 'input_z_pid_f_lim', 'z_f_lim'),
            ('slider_roll_pid_kp', 'input_roll_pid_kp', 'roll_kp'),
            ('slider_roll_pid_ki', 'input_roll_pid_ki', 'roll_ki'),
            ('slider_roll_pid_kd', 'input_roll_pid_kd', 'roll_kd'),
            ('slider_roll_pid_t_lim', 'input_roll_pid_t_lim', 'roll_t_lim'),
            ('slider_pitch_pid_kp', 'input_pitch_pid_kp', 'pitch_kp'),
            ('slider_pitch_pid_ki', 'input_pitch_pid_ki', 'pitch_ki'),
            ('slider_pitch_pid_kd', 'input_pitch_pid_kd', 'pitch_kd'),
            ('slider_pitch_pid_t_lim', 'input_pitch_pid_t_lim', 'pitch_t_lim'),
            ('slider_yaw_pid_kp', 'input_yaw_pid_kp', 'yaw_kp'),
            ('slider_yaw_pid_ki', 'input_yaw_pid_ki', 'yaw_ki'),
            ('slider_yaw_pid_kd', 'input_yaw_pid_kd', 'yaw_kd'),
            ('slider_yaw_pid_t_lim', 'input_yaw_pid_t_lim', 'yaw_t_lim'),
        ]
        
        for slider_name, input_name, param_key in p_mappings:
            slider = self.ui_controls.get(slider_name)
            line_edit = self.ui_controls.get(input_name)
            if slider and line_edit:
                validator = QDoubleValidator(0.0, 100.0, 2)
                line_edit.setValidator(validator)
                
                slider.valueChanged.connect(
                    lambda value, le=line_edit, key=param_key, is_s=False: 
                    self.on_slider_changed(value, le, key, is_s)
                )
                line_edit.editingFinished.connect(
                    lambda le=line_edit, sl=slider, key=param_key, is_s=False:
                    self.on_input_changed(le, sl, key, is_s)
                )
        
        # ==================== 按钮连接 ====================
        save_s = self.ui_controls.get('save_s')
        load_s = self.ui_controls.get('load_s')
        save_p = self.ui_controls.get('save_p')
        load_p = self.ui_controls.get('load_p')
        
        if save_s:
            save_s.clicked.connect(lambda: self.save_params('s'))
        if load_s:
            load_s.clicked.connect(lambda: self.load_params('s'))
        if save_p:
            save_p.clicked.connect(lambda: self.save_params('p'))
        if load_p:
            load_p.clicked.connect(lambda: self.load_params('p'))
    
    def setup_stacked_widget(self):
        """设置StackedWidget"""
        stacked = self.ui_controls.get('stacked_widget')
        if stacked:
            # 默认显示S面控制页面 (index 0)
            stacked.setCurrentIndex(0)
    
    def init_ui_values(self):
        """初始化UI值"""
        # 初始化S面参数
        self.update_ui_from_params('s', self.s_params)
        # 初始化PID参数
        self.update_ui_from_params('p', self.p_params)
        # 默认选中S面
        s_radio = self.ui_controls.get('s_plane')
        if s_radio:
            s_radio.setChecked(True)
    
    def load_default_params(self):
        """加载默认参数"""
        # 尝试加载默认配置文件
        default_s = os.path.join(self.param_dir, 's_plane_default.yaml')
        default_p = os.path.join(self.param_dir, 'pid_default.yaml')
        
        if os.path.exists(default_s):
            self.load_from_yaml(default_s, 's')
        if os.path.exists(default_p):
            self.load_from_yaml(default_p, 'p')
    
    def on_mode_changed(self, mode: int):
        """模式切换"""
        self.current_mode = mode
        stacked = self.ui_controls.get('stacked_widget')
        if stacked:
            stacked.setCurrentIndex(mode)
        # 发布参数
        self.publish_params()
        self.ros_node.get_logger().info(f"切换到控制模式: {mode}")
    
    def on_slider_changed(self, value: int, line_edit: QLineEdit, param_key: str, is_s: bool):
        """滑块变化处理"""
        # 滑块范围 0-100，映射到实际值
        actual_value = value / 10.0  # 0-10范围，或根据参数调整
        line_edit.setText(f"{actual_value:.2f}")
        self.update_param(param_key, actual_value, is_s)
    
    def on_input_changed(self, line_edit: QLineEdit, slider: QSlider, param_key: str, is_s: bool):
        """输入框变化处理"""
        try:
            value = float(line_edit.text())
            # 更新滑块 (乘以10映射到0-100)
            slider_value = int(value * 10)
            slider_value = max(0, min(100, slider_value))
            slider.setValue(slider_value)
            self.update_param(param_key, value, is_s)
        except ValueError:
            pass
    
    def update_param(self, param_key: str, value: float, is_s: bool):
        """更新参数"""
        with self.lock:
            if is_s:
                self.s_params[param_key] = value
            else:
                self.p_params[param_key] = value
        # 发布参数
        self.publish_params()
    
    def update_ui_from_params(self, mode: str, params: dict):
        """从参数字典更新UI"""
        # 确定对应的控件前缀
        if mode == 's':
            prefix = 's'
            slider_prefix = 'slider_'
            input_prefix = 'input_'
        else:
            prefix = 'p'
            slider_prefix = 'slider_'
            input_prefix = 'input_'
        
        # 更新所有参数
        for key, value in params.items():
            # 构建控件名称
            if 'lim' in key:
                if 'f_lim' in key:
                    slider_name = f'{slider_prefix}{key.replace("_f_lim", "_s_f_lim") if mode == "s" else key.replace("_f_lim", "_pid_f_lim")}'
                else:
                    slider_name = f'{slider_prefix}{key.replace("_t_lim", "_s_t_lim") if mode == "s" else key.replace("_t_lim", "_pid_t_lim")}'
            else:
                # k1, k2, kp, ki, kd
                suffix = key.split('_')[-1]
                dof = '_'.join(key.split('_')[:-1])
                if mode == 's':
                    slider_name = f'slider_{dof}_s_{suffix}'
                else:
                    slider_name = f'slider_{dof}_pid_{suffix}'
            
            # 更新滑块
            slider = self.ui_controls.get(slider_name)
            if slider:
                slider_value = int(value * 10)
                slider_value = max(0, min(100, slider_value))
                slider.setValue(slider_value)
            
            # 更新输入框
            input_name = slider_name.replace('slider_', 'input_')
            line_edit = self.ui_controls.get(input_name)
            if line_edit:
                line_edit.setText(f"{value:.2f}")
    
    def publish_params(self):
        """发布参数到ROS话题"""
        try:
            msg = RobustCtrlPara()
            msg.timestamp = self.ros_node.get_clock().now().to_msg()
            msg.robust_mode = self.current_mode
            
            with self.lock:
                # S面参数
                s = self.s_params
                msg.s_x_k1 = float(s['x_k1'])
                msg.s_x_k2 = float(s['x_k2'])
                msg.s_x_f_lim = float(s['x_f_lim'])
                msg.s_y_k1 = float(s['y_k1'])
                msg.s_y_k2 = float(s['y_k2'])
                msg.s_y_f_lim = float(s['y_f_lim'])
                msg.s_z_k1 = float(s['z_k1'])
                msg.s_z_k2 = float(s['z_k2'])
                msg.s_z_f_lim = float(s['z_f_lim'])
                msg.s_roll_k1 = float(s['roll_k1'])
                msg.s_roll_k2 = float(s['roll_k2'])
                msg.s_roll_t_lim = float(s['roll_t_lim'])
                msg.s_pitch_k1 = float(s['pitch_k1'])
                msg.s_pitch_k2 = float(s['pitch_k2'])
                msg.s_pitch_t_lim = float(s['pitch_t_lim'])
                msg.s_yaw_k1 = float(s['yaw_k1'])
                msg.s_yaw_k2 = float(s['yaw_k2'])
                msg.s_yaw_t_lim = float(s['yaw_t_lim'])
                
                # PID参数
                p = self.p_params
                msg.p_x_kp = float(p['x_kp'])
                msg.p_x_ki = float(p['x_ki'])
                msg.p_x_kd = float(p['x_kd'])
                msg.p_x_f_lim = float(p['x_f_lim'])
                msg.p_y_kp = float(p['y_kp'])
                msg.p_y_ki = float(p['y_ki'])
                msg.p_y_kd = float(p['y_kd'])
                msg.p_y_f_lim = float(p['y_f_lim'])
                msg.p_z_kp = float(p['z_kp'])
                msg.p_z_ki = float(p['z_ki'])
                msg.p_z_kd = float(p['z_kd'])
                msg.p_z_f_lim = float(p['z_f_lim'])
                msg.p_roll_kp = float(p['roll_kp'])
                msg.p_roll_ki = float(p['roll_ki'])
                msg.p_roll_kd = float(p['roll_kd'])
                msg.p_roll_t_lim = float(p['roll_t_lim'])
                msg.p_pitch_kp = float(p['pitch_kp'])
                msg.p_pitch_ki = float(p['pitch_ki'])
                msg.p_pitch_kd = float(p['pitch_kd'])
                msg.p_pitch_t_lim = float(p['pitch_t_lim'])
                msg.p_yaw_kp = float(p['yaw_kp'])
                msg.p_yaw_ki = float(p['yaw_ki'])
                msg.p_yaw_kd = float(p['yaw_kd'])
                msg.p_yaw_t_lim = float(p['yaw_t_lim'])
            
            msg.data_valid = True
            self.param_pub.publish(msg)
            
        except Exception as e:
            self.ros_node.get_logger().error(f"发布参数失败: {e}")
    
    def save_params(self, mode: str):
        """保存参数到YAML文件"""
        try:
            # 生成文件名
            now = datetime.now()
            date_str = now.strftime("%Y.%m.%d_%H:%M")
            if mode == 's':
                filename = f"s-plane-{date_str}.yaml"
            else:
                filename = f"pid-{date_str}.yaml"
            
            filepath = os.path.join(self.param_dir, filename)
            
            # 准备数据
            data = {
                'robust_mode': self.current_mode,
                'mode_type': 's_plane' if mode == 's' else 'pid',
                'save_time': now.strftime("%Y-%m-%d %H:%M:%S"),
                'parameters': self.s_params if mode == 's' else self.p_params
            }
            
            # 写入YAML
            with open(filepath, 'w') as f:
                yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
            
            QMessageBox.information(None, "保存成功", f"参数已保存到:\n{filename}")
            self.ros_node.get_logger().info(f"参数保存到: {filename}")
            
        except Exception as e:
            QMessageBox.critical(None, "保存失败", f"保存参数失败:\n{str(e)}")
            self.ros_node.get_logger().error(f"保存参数失败: {e}")
    
    def load_params(self, mode: str):
        """从YAML文件加载参数"""
        try:
            # 打开文件选择对话框
            filepath, _ = QFileDialog.getOpenFileName(
                None,
                "选择参数文件",
                self.param_dir,
                "YAML文件 (*.yaml *.yml)"
            )
            
            if not filepath:
                return
            
            # 读取YAML
            with open(filepath, 'r') as f:
                data = yaml.safe_load(f)
            
            # 验证文件格式
            if not isinstance(data, dict) or 'parameters' not in data:
                QMessageBox.warning(None, "格式错误", "请选择正确的参数文件")
                return
            
            # 检查模式是否匹配
            file_mode = data.get('mode_type', '')
            expected_mode = 's_plane' if mode == 's' else 'pid'
            if file_mode != expected_mode:
                QMessageBox.warning(
                    None, 
                    "模式不匹配", 
                    f"当前选择的是{'S面' if mode == 's' else 'PID'}参数，\n"
                    f"但文件包含的是{'S面' if file_mode == 's_plane' else 'PID'}参数。"
                )
                return
            
            # 加载参数
            params = data['parameters']
            with self.lock:
                if mode == 's':
                    self.s_params.update(params)
                else:
                    self.p_params.update(params)
            
            # 更新UI
            self.update_ui_from_params(mode, params)
            
            # 发布参数
            self.publish_params()
            
            QMessageBox.information(None, "加载成功", f"参数已加载:\n{os.path.basename(filepath)}")
            self.ros_node.get_logger().info(f"参数加载: {filepath}")
            
        except yaml.YAMLError as e:
            QMessageBox.critical(None, "解析错误", f"YAML文件解析失败:\n{str(e)}")
        except Exception as e:
            QMessageBox.critical(None, "加载失败", f"加载参数失败:\n{str(e)}")
            self.ros_node.get_logger().error(f"加载参数失败: {e}")
    
    def load_from_yaml(self, filepath: str, mode: str):
        """从指定YAML文件加载参数（用于默认加载）"""
        try:
            if not os.path.exists(filepath):
                return
            
            with open(filepath, 'r') as f:
                data = yaml.safe_load(f)
            
            if not isinstance(data, dict) or 'parameters' not in data:
                return
            
            params = data['parameters']
            with self.lock:
                if mode == 's':
                    self.s_params.update(params)
                else:
                    self.p_params.update(params)
            
            self.update_ui_from_params(mode, params)
            self.ros_node.get_logger().info(f"默认参数加载: {filepath}")
            
        except Exception as e:
            self.ros_node.get_logger().warn(f"默认参数加载失败: {e}")
    
    def shutdown(self):
        """关闭模块"""
        self.ros_node.get_logger().info("运动参数控制模块已关闭")