#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
from PyQt5.QtCore import QObject, QTimer, Qt, pyqtSignal
from PyQt5.QtWidgets import QWidget, QLineEdit, QSlider, QPushButton, QToolBox, QTabWidget
from PyQt5.QtGui import QDoubleValidator, QIntValidator

from phd_master_slave_interfaces.msg import MasterMachineUI
import threading
from typing import Dict, Optional
import math
from datetime import datetime

class MotionControlModule(QObject):
    """
    运动控制模块
    处理四种控制模式：全手操、手柄、键盘、自动
    """
    # 信号定义
    status_updated = pyqtSignal(dict)  # 状态更新信号
    
    def __init__(self, ui_widget, ros_node: Node):
        super().__init__()
        
        self.ui = ui_widget  # UI控件
        self.ros_node = ros_node  # ROS节点
        
        # 线程安全锁
        self.lock = threading.Lock()

        self.MODE = {
            'MANUAL': 0,           # 全手操模式
            'XBOX_CONTROLLER': 1,  # 手柄遥控模式
            'KEYBOARD': 2,         # 键盘遥控模式
            'AUTOMATIC': 3,        # 自动模式
        }
        
        # 当前控制模式 (0:全手操, 1:手柄, 2:键盘, 3:自动)
        self.current_mode = self.MODE['MANUAL']
        
        # 控制数据存储
        self.control_data = {
            # 控制模式
            'control_mode': self.MODE['MANUAL'],
            # 全手操模式推进器值 (-100 ~ 100)
            'manual_lfu': 0, 'manual_lfd': 0,
            'manual_rfu': 0, 'manual_rfd': 0,
            'manual_lbu': 0, 'manual_lbd': 0,
            'manual_rbu': 0, 'manual_rbd': 0,
            # 自动模式参数
            'auto_x_velocity': 0.0,  # 纵向速度
            'auto_y_velocity': 0.0,  # 横向速度
            'auto_yaw': 0.0,         # 期望航向角
            'auto_depth': 0.0,       # 期望深度
            # 距离模式参数
            'auto_x_distance': 0.0,  # 纵向距离
            'auto_y_distance': 0.0,  # 横向距离
            # 保护参数
            'protect_depth': 0.0,            # 定深保护
            'protect_height': 0.0,           # 定高保护
            'protect_time': 0.0,             # 定时保护
            'upper_computer_timer': 0.0,     # 上位机计时
            'lower_machine_timer': 0.0,      # 下位机计时
        }

        # UI控件映射
        self.ui_controls = {}

        # ROS发布器
        self.motion_ctrl_pub = self.ros_node.create_publisher(MasterMachineUI, '/motionCtrl', 10)
        # 控制定时器
        self.timer = self.ros_node.create_timer(0.02, self.publish_control_data)  # 50Hz

        # 初始化UI控件
        self.setup_ui_controls()

        # 初始化控制模式
        self.init_control_mode()
        self.ros_node.get_logger().info(f"运动控制模块初始化完成")
    
    def setup_ui_controls(self):
        """设置UI控件映射和连接信号"""
        # ==================== 模式切换工具箱 ====================
        self.tool_box = self.ui.findChild(QToolBox, 'toolBox')
        if self.tool_box:
            self.tool_box.currentChanged.connect(self.on_mode_changed)
        
        # ==================== 全手操模式控件 ====================
        thrusters = ['lfu', 'lfd', 'rfu', 'rfd', 'lbu', 'lbd', 'rbu', 'rbd']
        
        for thruster in thrusters:
            # 获取输入框
            line_edit_name = f'manual_ctrl_prop_{thruster}'
            line_edit = self.ui.findChild(QLineEdit, line_edit_name)
            
            # 获取滑块
            slider_name = f'verticalSlider_{thruster}'
            slider = self.ui.findChild(QSlider, slider_name)
            
            if line_edit and slider:
                # 设置验证器 (-100 到 100)
                validator = QIntValidator(-100, 100)
                line_edit.setValidator(validator)
                
                # 连接信号
                line_edit.editingFinished.connect(
                    lambda le=line_edit, s=slider, t=thruster: self.on_line_edit_changed(le, s, t)
                )
                slider.sliderReleased.connect(
                    lambda s=slider, le=line_edit, t=thruster: self.on_slider_changed(s, le, t)
                )
                
                # 存储控件
                self.ui_controls[f'line_edit_{thruster}'] = line_edit
                self.ui_controls[f'slider_{thruster}'] = slider
                
                # 初始同步
                self.sync_line_edit_slider(line_edit, slider)
            else:
                missing = []
                if not line_edit:
                    missing.append(line_edit_name)
                if not slider:
                    missing.append(slider_name)
                self.ros_node.get_logger().warn(f"未找到控件: {missing}")
        
        # ==================== 自动模式控件 ====================
        # 自动模式标签页
        self.tab_widget = self.ui.findChild(QTabWidget, 'tabWidget')
        
        # 自动模式参数输入框
        auto_fields = [
            ('auto_x_v', 'auto_x_velocity', -5.0, 5.0),      # 纵向速度
            ('auto_y_v', 'auto_y_velocity', -5.0, 5.0),      # 横向速度
            ('auto_yaw', 'auto_yaw', -180.0, 180.0),         # 航向角
            ('auto_v_depth_depth', 'auto_depth', 0.0, 1000.0),  # 深度
            ('auto_v_depth_x_v', 'auto_x_distance', -100.0, 100.0),  # 纵向距离
            ('auto_v_depth_y_v', 'auto_y_distance', -100.0, 100.0),  # 横向距离
        ]
        
        for ui_name, data_key, min_val, max_val in auto_fields:
            line_edit = self.ui.findChild(QLineEdit, ui_name)
            if line_edit:
                # 设置浮点数验证器
                validator = QDoubleValidator(min_val, max_val, 2)
                line_edit.setValidator(validator)
                line_edit.editingFinished.connect(
                    lambda le=line_edit, key=data_key: self.on_auto_param_changed(le, key)
                )
                self.ui_controls[ui_name] = line_edit
        
        # ==================== 保护参数控件 ====================
        protect_fields = [
            ('protect_auto_depth', 'protect_depth', 0.0, 1000.0),
            ('protect_auto_high', 'protect_height', 0.0, 100.0),
            ('protect_auto_time', 'protect_time', 0.0, 3600.0),
            ('protect_upper_computer_timer', 'upper_computer_timer', 0.0, 3600.0),
            ('protect_lower_mashine_timer', 'lower_machine_timer', 0.0, 3600.0),
        ]
        
        for ui_name, data_key, min_val, max_val in protect_fields:
            line_edit = self.ui.findChild(QLineEdit, ui_name)
            if line_edit:
                validator = QDoubleValidator(min_val, max_val, 2)
                line_edit.setValidator(validator)
                line_edit.editingFinished.connect(
                    lambda le=line_edit, key=data_key: self.on_protect_param_changed(le, key)
                )
                self.ui_controls[ui_name] = line_edit
        
        self.ros_node.get_logger().info(f"UI控件初始化完成，找到 {len(self.ui_controls)} 个控件")
    
    def sync_line_edit_slider(self, line_edit: QLineEdit, slider: QSlider):
        """同步输入框和滑块的值"""
        try:
            text = line_edit.text().strip()
            if text:
                value = int(text)
                # 确保值在有效范围内
                value = max(-100, min(100, value))
                slider.setValue(value)
                line_edit.setText(str(value))
        except ValueError:
            # 如果输入无效，重置为0
            line_edit.setText("0")
            slider.setValue(0)
    
    def on_line_edit_changed(self, line_edit: QLineEdit, slider: QSlider, thruster_name: str):
        """输入框内容改变时的处理"""
        try:
            value = int(line_edit.text())
            # 限制范围
            value = max(-100, min(100, value))
            
            # 更新滑块
            slider.setValue(value)
            
            # 更新控制数据
            with self.lock:
                self.control_data[f'manual_{thruster_name}'] = value
            
            self.ros_node.get_logger().debug(f"推进器 {thruster_name} 设置为: {value}")
            
        except ValueError:
            # 输入无效，重置为0
            line_edit.setText("0")
            slider.setValue(0)
            with self.lock:
                self.control_data[f'manual_{thruster_name}'] = 0
    
    def on_slider_changed(self, slider: QSlider, line_edit: QLineEdit, thruster_name: str):
        """滑块改变时的处理"""
        value = slider.value()
        
        # 更新输入框
        line_edit.setText(str(value))
        
        # 更新控制数据
        with self.lock:
            self.control_data[f'manual_{thruster_name}'] = value
        
        self.ros_node.get_logger().debug(f"推进器 {thruster_name} 滑块设置为: {value}")
    
    def on_auto_param_changed(self, line_edit: QLineEdit, data_key: str):
        """自动模式参数改变时的处理"""
        try:
            value = float(line_edit.text())
            with self.lock:
                self.control_data[data_key] = value
            
            self.ros_node.get_logger().debug(f"自动参数 {data_key} 设置为: {value}")
        except ValueError:
            line_edit.setText("0.0")
            with self.lock:
                self.control_data[data_key] = 0.0
    
    def on_protect_param_changed(self, line_edit: QLineEdit, data_key: str):
        """保护参数改变时的处理"""
        try:
            value = float(line_edit.text())
            with self.lock:
                self.control_data[data_key] = value
            
            self.ros_node.get_logger().debug(f"保护参数 {data_key} 设置为: {value}")
        except ValueError:
            line_edit.setText("0.0")
            with self.lock:
                self.control_data[data_key] = 0.0
    
    def on_mode_changed(self, index: int):
        """控制模式切换"""
        new_mode = index
        if new_mode != self.current_mode:
            self.current_mode = new_mode
            with self.lock:
                self.control_data['control_mode'] = new_mode
                # 如果切换到非全手操模式，重置推进器值为0
                if new_mode != 1:
                    self.reset_thruster_values()
            self.ros_node.get_logger().info(f"切换到控制模式: {new_mode}")
            # 更新UI状态
            self.update_ui_for_mode(new_mode)
    
    def reset_thruster_values(self):
        """重置推进器值为0"""
        thrusters = ['lfu', 'lfd', 'rfu', 'rfd', 'lbu', 'lbd', 'rbu', 'rbd']
        for thruster in thrusters:
            self.control_data[f'manual_{thruster}'] = 0
            # 更新UI显示
            line_edit = self.ui_controls.get(f'line_edit_{thruster}')
            slider = self.ui_controls.get(f'slider_{thruster}')
            if line_edit:
                line_edit.setText("0")
            if slider:
                slider.setValue(0)
    
    def update_ui_for_mode(self, mode: int):
        """根据控制模式更新UI状态"""
        # 根据模式启用/禁用相关控件
        is_manual_mode = (mode == self.MODE['MANUAL'])
        is_auto_mode = (mode == self.MODE['AUTOMATIC'])
        
        # 更新全手操模式控件
        thrusters = ['lfu', 'lfd', 'rfu', 'rfd', 'lbu', 'lbd', 'rbu', 'rbd']
        for thruster in thrusters:
            line_edit = self.ui_controls.get(f'line_edit_{thruster}')
            slider = self.ui_controls.get(f'slider_{thruster}')
            if line_edit:
                line_edit.setEnabled(is_manual_mode)
            if slider:
                slider.setEnabled(is_manual_mode)
        
        # 更新自动模式控件
        if self.tab_widget:
            self.tab_widget.setEnabled(is_auto_mode)
    
    def init_control_mode(self):
        """初始化控制模式"""
        # 设置初始模式为全手操
        if self.tool_box:
            self.tool_box.setCurrentIndex(self.MODE['MANUAL'])  # 第一个标签页
        self.current_mode = self.MODE['MANUAL']
        with self.lock:
            self.control_data['control_mode'] = self.MODE['MANUAL']
        # 更新UI状态
        self.update_ui_for_mode(self.MODE['MANUAL'])
        self.reset_thruster_values()
    
    def publish_control_data(self):
        """发布控制数据到ROS话题"""
        try:
            msg = MasterMachineUI()
            # 获取当前时间
            now = self.ros_node.get_clock().now()
            msg.timestamp = now.to_msg()
            # 复制控制数据（使用线程锁）
            with self.lock:
                control_data = self.control_data.copy()
            # 填充消息字段
            msg.control_mode = control_data['control_mode']
            # 推进器值
            msg.manual_lfu = control_data['manual_lfu']
            msg.manual_lfd = control_data['manual_lfd']
            msg.manual_rfu = control_data['manual_rfu']
            msg.manual_rfd = control_data['manual_rfd']
            msg.manual_lbu = control_data['manual_lbu']
            msg.manual_lbd = control_data['manual_lbd']
            msg.manual_rbu = control_data['manual_rbu']
            msg.manual_rbd = control_data['manual_rbd']
            
            # 自动模式参数
            msg.auto_x_velocity = float(control_data['auto_x_velocity'])
            msg.auto_y_velocity = float(control_data['auto_y_velocity'])
            msg.auto_yaw = float(control_data['auto_yaw'])
            msg.auto_depth = float(control_data['auto_depth'])
            msg.auto_x_distance = float(control_data['auto_x_distance'])
            msg.auto_y_distance = float(control_data['auto_y_distance'])
            
            # 保护参数
            msg.protect_depth = float(control_data['protect_depth'])
            msg.protect_height = float(control_data['protect_height'])
            msg.protect_time = float(control_data['protect_time'])
            msg.upper_computer_timer = float(control_data['upper_computer_timer'])
            msg.lower_machine_timer = float(control_data['lower_machine_timer'])
    
            msg.data_valid = True
            
            # 发布消息
            self.motion_ctrl_pub.publish(msg)
            
            # 可选：记录发布信息
            # self.ros_node.get_logger().debug(f"发布控制指令，模式: {msg.control_mode}")
            
        except Exception as e:
            self.ros_node.get_logger().error(f"发布控制数据时出错: {e}")
    
    def shutdown(self):
        """关闭模块"""
        self.publish_timer.stop()
        # 发送停止指令
        self.send_stop_command()
        self.ros_node.get_logger().info("运动控制模块已关闭")
    
    def send_stop_command(self):
        """发送停止指令"""
        try:
            msg = MasterMachineUI()
            now = self.ros_node.get_clock().now()
            msg.timestamp = now.to_msg()
            
            # 所有推进器设为0
            msg.manual_lfu = 0
            msg.manual_lfd = 0
            msg.manual_rfu = 0
            msg.manual_rfd = 0
            msg.manual_lbu = 0
            msg.manual_lbd = 0
            msg.manual_rbu = 0
            msg.manual_rbd = 0
            
            msg.data_valid = True
            
            self.motion_ctrl_pub.publish(msg)
            self.ros_node.get_logger().info("发送停止指令")
            
        except Exception as e:
            self.ros_node.get_logger().error(f"发送停止指令时出错: {e}")