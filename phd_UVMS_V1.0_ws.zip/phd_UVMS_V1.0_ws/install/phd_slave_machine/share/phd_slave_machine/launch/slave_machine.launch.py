from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument

def generate_launch_description():

    imu_communication_launch = Node(
        package='phd_slave_machine',
        executable='imu_communication',
        name='imu_communication',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info'],
        parameters=[{
            'server_ip': '192.168.2.125',
            'server_port': 1003,
            'publish_hz': 50.0,
            'receive_hz': 50.0,
            'data_format': 'psoncms',  # 数据格式 'prdid' 或 'psoncms'
            'frame_id': 'imu_link',
            'enable_euler_pub': True,
            'enable_statistics': False,
            'auto_reconnect': True,
            'reconnect_delay': 1.0,
            'max_reconnect_delay': 30.0,

            'enable_integration': True,
            'max_velocity': 50.0,
            'velocity_leak_rate': 0.999,
            'position_leak_rate': 0.9999,
            'zero_velocity_threshold': 0.05,
            'zero_velocity_timeout': 1.0,
        }],
        remappings=[
                ('/imu_data', '/sensors/imu_data'),
            ]
    )

    depth_communication_launch = Node(
        package='phd_slave_machine',
        executable='depth_communication',
        name='depth_communication',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info'],
        parameters=[{
            'server_ip': '192.168.2.125',
            'server_port': 1005,          # 整数
            'publish_hz': 50.0,           # 浮点数
            'receive_hz': 50.0,
            'frame_id': 'depth_link',
            'child_frame_id': 'base_footprint',
            'auto_reconnect': True,
            'reconnect_delay': 1.0,
            'max_reconnect_delay': 30.0,
        }],
        remappings=[
            ('/depth_data', '/sensors/depth_data'),
            ]
    )

    mcu_propeller_controller_launch = Node(
        package='phd_slave_machine',
        executable='mcu_propeller_controller',
        name='mcu_propeller_controller',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info'],
        parameters=[{
            # 网络连接
            'mcu_ip': '192.168.2.125',
            'mcu_port': 1007,
            # 频率控制
            'publish_hz': 50.0,
            'send_hz': 50.0,
            'receive_hz': 50.0,
            # 网络
            'auto_reconnect': True,
            'reconnect_delay': 1.0,
            'max_reconnect_delay': 30.0,
            }],
    )

    mcu_sensor_sw_ctrl_launch = Node(
        package='phd_slave_machine',
        executable='mcu_sensor_sw_ctrl',
        name='mcu_sensor_sw_ctrl',
        output='screen',
        arguments=['--ros-args', '--log-level', 'info'],
        parameters=[{
            'server_ip': '192.168.2.125',
            'server_port': 1008,
            'publish_hz': 50.0,
            'receive_hz': 50.0,
            'auto_reconnect': True,
            'reconnect_delay': 1.0,
            'max_reconnect_delay': 30.0,
        }],
    )

    return LaunchDescription([
        imu_communication_launch,
        depth_communication_launch,
        mcu_propeller_controller_launch,
        mcu_sensor_sw_ctrl_launch,
    ])
