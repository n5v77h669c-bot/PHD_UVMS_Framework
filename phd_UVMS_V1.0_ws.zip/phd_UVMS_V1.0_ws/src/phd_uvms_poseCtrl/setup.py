from setuptools import find_packages, setup
import os
from glob import glob


package_name = 'phd_uvms_poseCtrl'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pyy',
    maintainer_email='pyy@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'xbox_force_control = phd_uvms_poseCtrl.xbox_force_control:main',
            'xbox_pose_control = phd_uvms_poseCtrl.xbox_pose_control:main',
            'pos_cmd = phd_uvms_poseCtrl.pos_cmd:main',
            'pid_control = phd_uvms_poseCtrl.pid_control:main',
            'pos_glo2loc_tf = phd_uvms_poseCtrl.pos_glo2loc_tf:main',
            'thruster_allocator = phd_uvms_poseCtrl.thruster_allocator:main',
            'sim_hydrodynamic = phd_uvms_poseCtrl.sim_hydrodynamic:main',

            'pos_cmd_rov = phd_uvms_poseCtrl.pos_cmd_rov:main',
            'pid_control_rov = phd_uvms_poseCtrl.pid_control_rov:main',
            's_control_rov = phd_uvms_poseCtrl.s_control_rov:main',
            'robust_ctrl = phd_uvms_poseCtrl.robust_ctrl:main',


        ],
    },
)
