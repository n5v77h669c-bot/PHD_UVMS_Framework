#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Point, Quaternion
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion, quaternion_from_euler
import math
import threading

# 检查pygame是否可用
try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError as e:
    print(f"Pygame导入错误: {e}")
    PYGAME_AVAILABLE = False

class PositionCommand(Node):
    def __init__(self):
        super().__init__('pos_cmd_rov')
        
        # 当前状态（从odom获取，用于初始校准）
        self.current_pose = None
        self.current_orientation = None
        self.lock = threading.Lock()
        
        # 目标状态（累积手柄输入）
        self.target_pose = {
            'x': 0.0, 'y': 0.0, 'z': 0.0,
            'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
            'abs_roll': 0.0, 'abs_pitch': 0.0, 'abs_yaw': 0.0
        }
        self.position_limit = 0.5
        
        # 初始位置标志
        self.initial_position_set = False
        
        # 角度吸附参数
        self.snap_angles = [i * math.pi/4 for i in range(-4, 5)]
        self.snap_threshold = 5.0 * math.pi/180
        
        # ========== 真实环境标志 ==========
        self.real_robot = True
        
        # X/Y轴开环控制参数
        self.xy_open_loop_scale = 20
        self.last_xbox_input = {'x': 0.0, 'y': 0.0}
        
        # 发布器 - 目标位置指令
        self.cmd_pub = self.create_publisher(PoseStamped, '/pos_cmd', 10)
        
        # 订阅器 - 里程计信息
        self.odom_sub = self.create_subscription(
            Odometry, 
            '/odom',
            self.odom_callback, 
            10
        )
        
        # 订阅器 - 手柄输入
        self.xbox_sub = self.create_subscription(
            PoseStamped,
            '/xbox_input',
            self.xbox_callback,
            10
        )
        
        # 控制定时器
        self.timer = self.create_timer(0.02, self.publish_command)
        
        self.get_logger().info("位置指令节点已启动，等待初始位置校准...")
        self.get_logger().info("【真实环境模式】Z轴闭环控制，X/Y轴开环控制")
        
    def odom_callback(self, msg):
        """处理里程计数据 - 用于初始校准"""
        with self.lock:
            # 位置
            self.current_pose = msg.pose.pose.position
            
            # 姿态（四元数转欧拉角）
            orientation_q = msg.pose.pose.orientation
            orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
            try:
                roll, pitch, yaw = euler_from_quaternion(orientation_list)
                self.current_orientation = {'roll': roll, 'pitch': pitch, 'yaw': yaw}
                
                # 如果是第一次收到odom数据，设置初始目标位置
                if not self.initial_position_set:
                    self.target_pose['x'] = 0.0
                    self.target_pose['y'] = 0.0
                    self.target_pose['z'] = self.current_pose.z
                    self.target_pose['abs_roll'] = roll
                    self.target_pose['abs_pitch'] = pitch
                    self.target_pose['abs_yaw'] = yaw
                    self.target_pose['roll'] = roll
                    self.target_pose['pitch'] = pitch
                    self.target_pose['yaw'] = yaw
                    self.initial_position_set = True
                    self.get_logger().info("初始位置校准完成")
                    self.get_logger().info(f"初始目标位置: x={self.target_pose['x']:.2f}, y={self.target_pose['y']:.2f}, z={self.target_pose['z']:.2f}")
                    self.get_logger().info(f"初始目标姿态: roll={math.degrees(roll):.1f}°, pitch={math.degrees(pitch):.1f}°, yaw={math.degrees(yaw):.1f}°")
                    
            except Exception as e:
                self.get_logger().warn(f"姿态解算失败: {e}")
                
    def xbox_callback(self, msg):
        """处理手柄输入"""
        if not self.initial_position_set:
            self.get_logger().warn("尚未完成初始位置校准，忽略手柄输入",
                                   throttle_duration_sec=1.0)
            return
            
        with self.lock:
            current_yaw = self.current_orientation['yaw'] if self.current_orientation else 0.0
            input_x = msg.pose.position.x * self.xy_open_loop_scale
            input_y = msg.pose.position.y * self.xy_open_loop_scale
            
            self.last_xbox_input = {'x': input_x, 'y': input_y, 'z': msg.pose.position.z}
            
            # X/Y轴：相对于当前朝向的位移
            self.target_pose['x'] = (input_x * math.cos(current_yaw) - input_y * math.sin(current_yaw)) * -1
            self.target_pose['y'] = (input_x * math.sin(current_yaw) + input_y * math.cos(current_yaw)) * -1
            
            # Z轴：深度控制（闭环）
            self.target_pose['z'] += msg.pose.position.z
            self.target_pose['z'] = self.apply_z_limit()
            
            # 姿态控制 - 手柄发送的是姿态增量
            orientation_q = msg.pose.orientation
            orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
            roll_delta, pitch_delta, yaw_delta = euler_from_quaternion(orientation_list)
            
            self.target_pose['abs_roll'] += roll_delta
            self.target_pose['abs_pitch'] += pitch_delta
            self.target_pose['abs_yaw'] += yaw_delta
            self.target_pose['abs_roll'] = self.apply_angle_clamp(self.target_pose['abs_roll'])
            self.target_pose['abs_pitch'] = self.apply_angle_clamp(self.target_pose['abs_pitch'])
            
            # 应用角度吸附
            self.target_pose['roll'] = self.apply_angle_snap(self.target_pose['abs_roll'])
            self.target_pose['pitch'] = self.apply_angle_snap(self.target_pose['abs_pitch'])
            self.target_pose['roll'] = self.apply_angle_clamp(self.target_pose['roll'])
            self.target_pose['pitch'] = self.apply_angle_clamp(self.target_pose['pitch'])
            self.target_pose['yaw'] = self.target_pose['abs_yaw']
            
    def apply_z_limit(self):
        # 如果还没有当前姿态数据，直接返回目标值
        if self.current_pose is None:
            return self.target_pose['z']
        
        z_offset = self.target_pose['z'] - self.current_pose.z
        
        # 检查是否超出限幅
        if abs(z_offset) > self.position_limit:
            # 限制单步变化量
            limited_z = self.current_pose.z + math.copysign(self.position_limit, z_offset)
            return limited_z
        else:
            return self.target_pose['z']
        
    def apply_angle_snap(self, angle):
        """应用角度吸附到最近的45度位置"""
        angle = self.normalize_angle(angle)
        closest_snap = min(self.snap_angles, key=lambda x: abs(x - angle))
        if abs(closest_snap - angle) <= self.snap_threshold:
            return closest_snap
        return angle
        
    def apply_angle_clamp(self, angle):
        """应用绝对角度限幅"""
        if angle > 89.0 * math.pi/180:
            angle = 89.0 * math.pi/180
        if angle < -89.0 * math.pi/180:
            angle = -89.0 * math.pi/180
        return angle
            
    def normalize_angle(self, angle):
        """将角度归一化到[-pi, pi]范围内"""
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return angle
        
    def publish_command(self):
        """发布位置指令"""
        if not self.initial_position_set:
            return
            
        cmd_msg = PoseStamped()
        cmd_msg.header.stamp = self.get_clock().now().to_msg()
        cmd_msg.header.frame_id = "world"
        
        # 设置位置
        cmd_msg.pose.position = Point(
            x=float(self.target_pose['x']),
            y=float(self.target_pose['y']), 
            z=float(self.target_pose['z'])
        )
        
        # 设置姿态（欧拉角转四元数）
        q = quaternion_from_euler(
            float(self.target_pose['roll']), 
            float(self.target_pose['pitch']), 
            float(self.target_pose['yaw'])
        )
        
        cmd_msg.pose.orientation = Quaternion(
            x=float(q[0]), 
            y=float(q[1]), 
            z=float(q[2]), 
            w=float(q[3])
        )
        
        self.cmd_pub.publish(cmd_msg)

def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = PositionCommand()
        rclpy.spin(node)
    except KeyboardInterrupt:
        if 'node' in locals():
            node.get_logger().info("位置指令节点被用户中断")
    except Exception as e:
        print(f"节点运行错误: {e}")
        if 'node' in locals():
            node.get_logger().error(f"节点运行错误: {e}")
    finally:
        if 'node' in locals():
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()