#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Wrench
import numpy as np
from scipy.linalg import pinv
import math

class ThrusterDistribution(Node):
    def __init__(self):
        super().__init__('thrust_distribution')
        
        # 订阅总体力/力矩命令
        self.wrench_sub = self.create_subscription(
            Wrench, '/force', self.wrench_callback, 10)
        
        # 创建8个推进器的发布器 - 发布Wrench消息
        self.thruster_publishers = {}
        thruster_names = ['lfu', 'lfd', 'rfu', 'rfd', 'lbu', 'lbd', 'rbu', 'rbd']
        
        for name in thruster_names:
            topic_name = f'/force_{name}'
            self.thruster_publishers[name] = self.create_publisher(Wrench, topic_name, 10)
        
        # 推进器配置矩阵 T (6x8)
        self.T_matrix = self.create_thruster_configuration()
        
        # 计算伪逆矩阵 (8x6)
        self.T_pinv = pinv(self.T_matrix)
        
        # 推进器推力限幅
        self.thruster_limits = (-20.0, 20.0)  # 根据实际推进器调整
        
        self.get_logger().info("推进器分配节点已启动")
        self.get_logger().info(f"配置矩阵形状: {self.T_matrix.shape}")
        
    def create_thruster_configuration(self):
        """
        推进器配置矩阵 T
        """
        # ROV尺寸 (单位: 米)
        Lx = 0.12  # 左右方向半长
        Ly = 0.20  # 前后方向半长  
        Lz = 0.084  # 上下方向半高
        dirCoe = 0.57735

        dirCoe_Ly = dirCoe * Ly
        dirCoe_Lx = dirCoe * Lx
        dirCoe_Lz = dirCoe * Lz

        TxCoe = dirCoe_Ly - dirCoe_Lz
        TyCoe = dirCoe_Lx + dirCoe_Lz
        TzCoe = dirCoe_Lx + dirCoe_Ly

        # 推进器配置矩阵 T (6x8)
        # 列顺序: [lfu, lfd, rfu, rfd, lbu, lbd, rbu, rbd]
        # 每个推进器只在局部Z轴产生力，但方向不同
        T = np.array([
            # Fx
            [  dirCoe,  dirCoe, -dirCoe, -dirCoe,  dirCoe,  dirCoe, -dirCoe, -dirCoe],
            # Fy
            [  dirCoe,  dirCoe,  dirCoe,  dirCoe, -dirCoe, -dirCoe, -dirCoe, -dirCoe],
            # Fz
            [  dirCoe, -dirCoe,  dirCoe, -dirCoe,  dirCoe, -dirCoe,  dirCoe, -dirCoe],
            # Tx
            [  TxCoe, -TxCoe,  TxCoe, -TxCoe, -TxCoe,  TxCoe, -TxCoe,  TxCoe],
            # Ty
            [  TyCoe, -TyCoe, -TyCoe,  TyCoe,  TyCoe, -TyCoe, -TyCoe,  TyCoe],
            # Tz
            [ -TzCoe, -TzCoe,  TzCoe,  TzCoe,  TzCoe,  TzCoe, -TzCoe, -TzCoe]
        ], dtype=np.float64)
        return T
        
    def wrench_callback(self, msg):
        """处理总体力/力矩命令并分配到推进器"""
        try:
            # 构建力/力矩向量 [Fx, Fy, Fz, Tx, Ty, Tz]
            wrench_vector = np.array([
                msg.force.x,    # Fx
                msg.force.y,    # Fy
                msg.force.z,    # Fz
                msg.torque.x,   # Tx
                msg.torque.y,   # Ty
                msg.torque.z    # Tz
            ], dtype=np.float64)
            
            # 使用伪逆求解推进器推力: F_thruster = T⁺ × F_total
            thruster_forces = self.T_pinv @ wrench_vector
            # 推力限幅
            thruster_forces = np.clip(thruster_forces, 
                                    self.thruster_limits[0], 
                                    self.thruster_limits[1])
            # 发布各个推进器的Wrench消息
            self.publish_thruster_wrenches(thruster_forces)
            
            # 调试输出
            # self.get_logger().info(
            #     f"总力: F({wrench_vector[0]:.1f},{wrench_vector[1]:.1f},{wrench_vector[2]:.1f}) "
            #     f"力矩: T({wrench_vector[3]:.1f},{wrench_vector[4]:.1f},{wrench_vector[5]:.1f})",
            #     throttle_duration_sec=1.0
            # )
        except Exception as e:
            self.get_logger().error(f"推进器分配计算失败: {e}")
            
    def publish_thruster_wrenches(self, thruster_forces):
        """发布各个推进器的Wrench消息"""
        thruster_names = ['lfu', 'lfd', 'rfu', 'rfd', 'lbu', 'lbd', 'rbu', 'rbd']
        for i, name in enumerate(thruster_names):
            wrench_msg = Wrench()
            wrench_msg.force.z = float(thruster_forces[i]) 
            # 其他方向的力和所有力矩设为0
            wrench_msg.force.x = 0.0
            wrench_msg.force.y = 0.0
            wrench_msg.torque.x = 0.0
            wrench_msg.torque.y = 0.0  
            wrench_msg.torque.z = 0.0
            
            self.thruster_publishers[name].publish(wrench_msg)

def main():
    rclpy.init()
    node = ThrusterDistribution()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("推进器分配节点被用户中断")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()