#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Wrench, PoseStamped
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion
import math
import threading
import numpy as np

class SController:
    """
    S面控制器 (Sigmoid-based Controller)
    公式: u = 2.0 / (1.0 + exp(-k1 * e - k2 * e_dot)) - 1.0
    输出范围: [-1.0, 1.0]
    """
    def __init__(self, k1, k2, output_limits=(-50.0, 50.0)):
        self.k1 = k1          # 误差增益
        self.k2 = k2          # 误差变化率增益
        self.output_limits = output_limits
        
        self.previous_error = 0.0
        self.last_time = None
        
    def reset(self):
        """重置控制器状态"""
        self.previous_error = 0.0
        self.last_time = None
        
    def update(self, error, dt):
        """
        更新S面控制器
        输入: error - 当前误差
              dt - 时间步长
        输出: 控制量 (范围已映射到 output_limits)
        """
        if dt <= 0 or dt > 0.1:
            dt = 0.02
            
        # 计算误差变化率 (微分)
        error_dot = (error - self.previous_error) / dt
        
        # S面控制公式
        # u ∈ [-1, 1]
        exponent = -(self.k1 * error + self.k2 * error_dot)
        # 防止exp溢出
        exponent = max(-50.0, min(50.0, exponent))
        u = 2.0 / (1.0 + math.exp(exponent)) - 1.0
        
        # 保存当前误差用于下次微分
        self.previous_error = error
        
        # 映射到输出范围
        output = self._map_output(u)
        
        return output
    
    def _map_output(self, u):
        """
        将S面输出 u ∈ [-1, 1] 映射到实际输出范围
        """
        min_out, max_out = self.output_limits
        # 线性映射
        output = min_out + (u + 1.0) / 2.0 * (max_out - min_out)
        return output


class ROVSController(Node):
    """
    ROV S面控制器
    使用Sigmoid函数进行非线性控制，比PID更平滑、鲁棒性更好
    """
    def __init__(self):
        super().__init__('s_control_rov')
        
        # ==================== S面控制器参数 ====================
        # k1: 误差增益 (相当于PID的P)
        # k2: 误差变化率增益 (相当于PID的D)
        # 输出范围: 力的单位是牛顿(N)，力矩单位是牛米(Nm)
        self.s_controllers = {
            'x': SController(k1=3.5, k2=0.3, output_limits=(-50, 50)),      # 纵荡 (Surge)
            'y': SController(k1=3.5, k2=0.3, output_limits=(-50, 50)),      # 横荡 (Sway)
            'z': SController(k1=1.5, k2=0.3, output_limits=(-20, 20)),      # 垂荡 (Heave)
            'roll': SController(k1=1.2, k2=0.3, output_limits=(-10, 10)),    # 横滚 (Roll)
            'pitch': SController(k1=1.0, k2=0.3, output_limits=(-8,8)),   # 俯仰 (Pitch)
            'yaw': SController(k1=1.5, k2=0.5, output_limits=(-20, 20))      # 偏航 (Yaw)
        }#当前版本中roll跟pitch是反过来的
        
        # 订阅局部目标状态（误差信息）
        self.pos_cmd_loc_sub = self.create_subscription(
            PoseStamped, 
            '/pos_cmd_loc', 
            self.pos_cmd_loc_callback, 
            10
        )
        
        # 发布控制力/力矩
        self.force_pub = self.create_publisher(Wrench, '/force', 10)
        
        # 当前局部误差
        self.local_errors = {
            'x': 0.0, 'y': 0.0, 'z': 0.0,
            'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0
        }
        
        # 上一次控制时间
        self.last_control_time = self.get_clock().now()
        
        # 控制定时器 (50Hz)
        self.control_timer = self.create_timer(0.02, self.control_loop)
        
        self.get_logger().info("=" * 60)
        self.get_logger().info("ROV S面控制器已启动")
        self.get_logger().info("控制自由度: Surge(x), Sway(y), Heave(z), Roll, Pitch, Yaw")
        self.get_logger().info("=" * 60)
    
    def pos_cmd_loc_callback(self, msg):
        """处理局部目标位置（误差信息）"""
        # 位置误差
        self.local_errors['x'] = msg.pose.position.x
        self.local_errors['y'] = msg.pose.position.y
        self.local_errors['z'] = msg.pose.position.z
        
        # 姿态误差
        orientation_q = msg.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        try:
            roll, pitch, yaw = euler_from_quaternion(orientation_list)
            self.local_errors['roll'] = roll
            self.local_errors['pitch'] = pitch
            self.local_errors['yaw'] = yaw
        except Exception as e:
            self.get_logger().warn(f"姿态解算失败: {e}")
    
    def control_loop(self):
        """S面控制主循环"""
        current_time = self.get_clock().now()
        dt = (current_time - self.last_control_time).nanoseconds / 1e9
        dt = max(0.01, min(0.05, dt))  # 限制dt范围
        
        # 计算各自由度的控制量
        forces = {}
        for dof in ['x', 'y', 'z', 'roll', 'pitch', 'yaw']:
            forces[dof] = self.s_controllers[dof].update(self.local_errors[dof], dt)
        
        # 发布控制力/力矩
        wrench = Wrench()
        wrench.force.x = float(forces['x'])
        wrench.force.y = float(forces['y'])
        wrench.force.z = float(forces['z'])
        wrench.torque.x = float(forces['roll'])
        wrench.torque.y = float(forces['pitch'])
        wrench.torque.z = float(forces['yaw'])
        
        self.force_pub.publish(wrench)
        
        # 调试输出（降低频率）
        if int(current_time.nanoseconds / 1e9) % 5 == 0:
            self.get_logger().debug(
                f"S控制输出: "
                f"Fx={forces['x']:.1f}N, Fy={forces['y']:.1f}N, Fz={forces['z']:.1f}N | "
                f"Tx={forces['roll']:.1f}Nm, Ty={forces['pitch']:.1f}Nm, Tz={forces['yaw']:.1f}Nm",
                throttle_duration_sec=2.0
            )
        
        self.last_control_time = current_time
    
    def set_gains(self, dof, k1, k2):
        """动态设置S面控制器增益"""
        if dof in self.s_controllers:
            self.s_controllers[dof].k1 = k1
            self.s_controllers[dof].k2 = k2
            self.get_logger().info(f"{dof} S面参数更新: k1={k1}, k2={k2}")


def main(args=None):
    rclpy.init(args=args)
    
    controller = None
    try:
        controller = ROVSController()
        rclpy.spin(controller)
    except KeyboardInterrupt:
        if controller:
            controller.get_logger().info("用户中断")
    except Exception as e:
        if controller:
            controller.get_logger().error(f"节点崩溃: {e}")
        else:
            print(f"节点启动失败: {e}")
    finally:
        if controller:
            controller.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()