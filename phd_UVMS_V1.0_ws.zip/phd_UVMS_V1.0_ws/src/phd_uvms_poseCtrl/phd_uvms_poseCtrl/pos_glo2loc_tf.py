#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Point, Quaternion
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion, quaternion_from_euler
import numpy as np
import math

class GlobalToLocalTF(Node):
    def __init__(self):
        super().__init__('pos_glo2loc_tf')
        
        # 当前状态
        self.current_pose = None
        self.current_quaternion = None
        self.current_orientation = None
        
        # 目标状态
        self.target_pose = None
        self.target_quaternion = None
        self.target_orientation = None
        
        # 订阅器
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10)
        self.pos_cmd_sub = self.create_subscription(
            PoseStamped, '/pos_cmd', self.pos_cmd_callback, 10)
        
        # 发布器 - 局部相对量
        self.pos_cmd_loc_pub = self.create_publisher(PoseStamped, '/pos_cmd_loc', 10)
        # 控制定时器
        self.timer = self.create_timer(0.02, self.publish_local_data)  # 50Hz
        
        self.get_logger().info("全局到局部坐标转换节点已启动")
        
    def odom_callback(self, msg):
        """处理当前状态"""
        self.current_pose = msg.pose.pose.position
        self.current_quaternion = msg.pose.pose.orientation
        
        # 转换为欧拉角
        orientation_list = [
            self.current_quaternion.x, self.current_quaternion.y,
            self.current_quaternion.z, self.current_quaternion.w
        ]
        try:
            roll, pitch, yaw = euler_from_quaternion(orientation_list)
            self.current_orientation = {'roll': roll, 'pitch': pitch, 'yaw': yaw}
        except Exception as e:
            self.get_logger().warn(f"当前姿态解算失败: {e}")
        
    def pos_cmd_callback(self, msg):
        """处理目标状态"""
        self.target_pose = msg.pose.position
        self.target_quaternion = msg.pose.orientation
        
        # 转换为欧拉角
        orientation_list = [
            self.target_quaternion.x, self.target_quaternion.y,
            self.target_quaternion.z, self.target_quaternion.w
        ]
        try:
            roll, pitch, yaw = euler_from_quaternion(orientation_list)
            self.target_orientation = {'roll': roll, 'pitch': pitch, 'yaw': yaw}
        except Exception as e:
            self.get_logger().warn(f"目标姿态解算失败: {e}")
            
        # self.get_logger().info(
        #         f"目标位置 - x:{self.target_pose.x:.2f}, y:{self.target_pose.y:.2f}, z:{self.target_pose.z:.2f} | "
        #         f"期望角度 - roll:{self.target_orientation['roll']:.2f}, pitch:{self.target_orientation['pitch']:.2f}, yaw:{self.target_orientation['yaw']:.2f}"
        #     )
        
    def publish_local_data(self):
        """发布局部相对量"""
        if (self.current_pose is None or self.current_orientation is None or 
            self.target_pose is None or self.target_orientation is None):
            return
            
        # 计算位置相对量（在机器人局部坐标系下）
        position_error_local = self.calculate_position_error_local()
        
        # 计算姿态相对量
        orientation_error_local = self.calculate_orientation_error_local()
        
        # 只需要发布局部目标状态（相对量）
        pos_cmd_loc_msg = PoseStamped()
        pos_cmd_loc_msg.header.stamp = self.get_clock().now().to_msg()
        pos_cmd_loc_msg.header.frame_id = "base_footprint"
        pos_cmd_loc_msg.pose.position = Point(
            x=float(position_error_local[0]),
            y=float(position_error_local[1]),
            z=float(position_error_local[2])
        )
        
        # 将欧拉角误差转换为四元数
        q = quaternion_from_euler(
            float(orientation_error_local[0]),
            float(orientation_error_local[1]), 
            float(orientation_error_local[2])
        )
        pos_cmd_loc_msg.pose.orientation = Quaternion(
            x=float(q[0]), y=float(q[1]), z=float(q[2]), w=float(q[3])
        )
        self.pos_cmd_loc_pub.publish(pos_cmd_loc_msg)
        
        # 调试信息
        # self.get_logger().info(
        #     f"局部误差 - 位置:({position_error_local[0]:.3f},{position_error_local[1]:.3f},{position_error_local[2]:.3f}) "
        #     f"姿态:({orientation_error_local[0]:.3f},{orientation_error_local[1]:.3f},{orientation_error_local[2]:.3f})",
        #     throttle_duration_sec=1.0  # 每秒只输出一次，避免日志过多
        # )
        
    def calculate_position_error_local(self):
        """计算局部坐标系下的位置误差"""
        # 全局位置误差
        global_error = np.array([
            self.target_pose.x - self.current_pose.x,
            self.target_pose.y - self.current_pose.y,
            self.target_pose.z - self.current_pose.z
        ])
        
        # 转换到局部坐标系
        if self.current_quaternion is not None:
            R = self.quaternion_to_rotation_matrix([
                self.current_quaternion.x, self.current_quaternion.y,
                self.current_quaternion.z, self.current_quaternion.w
            ])
            local_error = R.T @ global_error  # 转置矩阵将全局向量转换到局部
        else:
            local_error = global_error
            
        return local_error
        
    def calculate_orientation_error_local(self):
        """使用四元数计算局部坐标系下的姿态误差"""
        if (self.current_quaternion is None or 
            self.target_quaternion is None):
            return [0.0, 0.0, 0.0]
        
        # 当前姿态四元数
        q_current = np.array([
            self.current_quaternion.w,
            self.current_quaternion.x,
            self.current_quaternion.y, 
            self.current_quaternion.z
        ])
        
        # 目标姿态四元数
        q_target = np.array([
            self.target_quaternion.w,
            self.target_quaternion.x,
            self.target_quaternion.y,
            self.target_quaternion.z
        ])
        
        # 计算姿态误差四元数：q_error = q_current^-1 * q_target
        q_current_conj = np.array([q_current[0], -q_current[1], -q_current[2], -q_current[3]])
        q_error = self.quaternion_multiply(q_current_conj, q_target)
        
        # 将误差四元数转换为轴角形式，再投影到局部坐标系
        angle = 2 * math.acos(min(max(q_error[0], -1.0), 1.0))
        
        if angle > math.pi:
            angle = 2 * math.pi - angle
        
        if abs(angle) < 1e-6:
            return [0.0, 0.0, 0.0]
        
        axis_x = q_error[1] / math.sqrt(1 - q_error[0]**2)
        axis_y = q_error[2] / math.sqrt(1 - q_error[0]**2) 
        axis_z = q_error[3] / math.sqrt(1 - q_error[0]**2)
        
        # 在机器人局部坐标系下的误差
        roll_error = axis_x * angle
        pitch_error = axis_y * angle
        yaw_error = axis_z * angle
        
        return [roll_error, pitch_error, yaw_error]

    def quaternion_multiply(self, q1, q2):
        """四元数乘法"""
        w1, x1, y1, z1 = q1
        w2, x2, y2, z2 = q2
        w = w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2
        x = w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2
        y = w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2
        z = w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2
        return np.array([w, x, y, z])
    
    def quaternion_to_rotation_matrix(self, q):
        """四元数转旋转矩阵"""
        x, y, z, w = q
        return np.array([
            [1-2*y*y-2*z*z,   2*x*y-2*z*w,     2*x*z+2*y*w],
            [2*x*y+2*z*w,     1-2*x*x-2*z*z,   2*y*z-2*x*w],
            [2*x*z-2*y*w,     2*y*z+2*x*w,     1-2*x*x-2*y*y]
        ])
    
    def normalize_angle(self, angle):
        """角度归一化到[-pi, pi]"""
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return angle

def main():
    rclpy.init()
    node = GlobalToLocalTF()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("坐标转换节点被用户中断")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()