import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Wrench, Twist, PoseStamped
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion, quaternion_from_euler
import math
import threading

class PIDController:
    def __init__(self, kp, ki, kd, output_limits=(-10.0, 10.0), integral_limit=5.0):
        self.kp = kp
        self.ki = ki 
        self.kd = kd
        self.output_limits = output_limits
        self.integral_limit = integral_limit
        
        self.previous_error = 0.0
        self.integral = 0.0
        self.last_time = None
        
    def reset(self):
        """重置PID控制器"""
        self.previous_error = 0.0
        self.integral = 0.0
        self.last_time = None
        
    def update(self, error, dt):
        """更新PID控制器"""
        if self.last_time is None:
            self.last_time = rclpy.clock.Clock().now()
            return 0.0
            
        # 积分项
        self.integral += error * dt
        # 积分限幅
        self.integral = max(min(self.integral, self.integral_limit), -self.integral_limit)
        
        # 微分项
        derivative = (error - self.previous_error) / dt if dt > 0 else 0.0
        
        # PID输出
        output = (self.kp * error + 
                 self.ki * self.integral + 
                 self.kd * derivative)
        
        # 输出限幅
        output = max(min(output, self.output_limits[1]), self.output_limits[0])
        
        self.previous_error = error
        return output

class ROVForceController(Node):
    def __init__(self):
        super().__init__('pid_control_rov')
        
        # PID控制器参数（控制局部相对误差）
        self.pid_controllers = {
            'x': PIDController(kp=30.0, ki=0.0, kd=5.0, output_limits=(-50, 50)),
            'y': PIDController(kp=30.0, ki=0.0, kd=5.0, output_limits=(-50, 50)), 
            'z': PIDController(kp=30.0, ki=0.0, kd=5.0, output_limits=(-50, 50)),
            'roll': PIDController(kp=10.0, ki=0.1, kd=2.0, output_limits=(-10, 10)),
            'pitch': PIDController(kp=5.0, ki=0.1, kd=2.0, output_limits=(-10, 10)),
            'yaw': PIDController(kp=5.0, ki=0.1, kd=1.0, output_limits=(-10, 10))
        }
        
        # 只需要订阅局部目标状态（已经包含了误差信息）
        self.pos_cmd_loc_sub = self.create_subscription(
            PoseStamped, '/pos_cmd_loc', self.pos_cmd_loc_callback, 10)
        
        # 发布局部力
        self.force_pub = self.create_publisher(Wrench, '/force', 10)
        
        # 当前局部误差（初始为零）
        self.local_errors = {
            'x': 0.0, 'y': 0.0, 'z': 0.0,
            'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0
        }
        
        self.control_timer = self.create_timer(0.02, self.control_loop)
        self.get_logger().info("局部PID控制器已启动")
      
    def pos_cmd_loc_callback(self, msg):
        """处理局部目标位置（这个就是误差！）"""
        # 位置误差
        self.local_errors['x'] = msg.pose.position.x
        self.local_errors['y'] = msg.pose.position.y
        self.local_errors['z'] = msg.pose.position.z
        
        # 姿态误差
        orientation_q = msg.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        try:
            roll, pitch, yaw = euler_from_quaternion(orientation_list)
            self.local_errors['roll'] = roll
            self.local_errors['pitch'] = pitch
            self.local_errors['yaw'] = yaw
        except Exception as e:
            self.get_logger().warn(f"局部姿态解算失败: {e}")
                
        # self.get_logger().info(f"收到新目标位置: x={self.target_pose['x']:.2f}, y={self.target_pose['y']:.2f}, z={self.target_pose['z']:.2f}")
        
    def control_loop(self):
        """PID控制循环 - 极其简单！"""
        # 更新PID控制器
        dt = 0.02
        forces = {}
        
        for dof in ['x', 'y', 'z', 'roll', 'pitch', 'yaw']:
            forces[dof] = self.pid_controllers[dof].update(self.local_errors[dof], dt)
        
        # 发布局部力
        wrench = Wrench()
        wrench.force.x = float(forces['x'])
        wrench.force.y = float(forces['y']) 
        wrench.force.z = float(forces['z'])
        wrench.torque.x = float(forces['roll'])
        wrench.torque.y = float(forces['pitch'])
        wrench.torque.z = float(forces['yaw'])
        
        self.force_pub.publish(wrench)

        # self.get_logger().info(
        #         f"目标位置 - x:{self.target_pose['x']:.3f}, y:{self.target_pose['y']:.3f}, z:{self.target_pose['z']:.3f} | "
        #         f"期望角度 - roll:{target_roll:.2f}, pitch:{target_pitch:.2f}, yaw:{target_yaw:.2f}"
        #     )

    def set_pid_gains(self, dof, kp, ki, kd):
        """动态设置PID参数"""
        if dof in self.pid_controllers:
            self.pid_controllers[dof].kp = kp
            self.pid_controllers[dof].ki = ki
            self.pid_controllers[dof].kd = kd
            self.get_logger().info(f"{dof} PID参数更新: Kp={kp}, Ki={ki}, Kd={kd}")
    
    def normalize_angle(self, angle):
        """将角度归一化到[-pi, pi]范围内"""
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return angle

def main():
    rclpy.init()
    controller = ROVForceController()
    
    try:
        rclpy.spin(controller)
    except KeyboardInterrupt:
        pass
    finally:
        controller.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()