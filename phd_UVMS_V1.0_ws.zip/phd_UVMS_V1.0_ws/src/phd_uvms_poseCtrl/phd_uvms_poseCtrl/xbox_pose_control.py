#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Point, Quaternion
from tf_transformations import euler_from_quaternion, quaternion_from_euler
from nav_msgs.msg import Odometry
import sys
import threading
import math

# 检查pygame是否可用
try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError as e:
    print(f"Pygame导入错误: {e}")
    PYGAME_AVAILABLE = False

class XboxPoseControl(Node):
    def __init__(self):
        super().__init__('xbox_pos_control')

        # 发布目标位置
        self.pose_pub = self.create_publisher(PoseStamped, '/xbox_input', 10)

        # 检查pygame是否可用
        if not PYGAME_AVAILABLE:
            self.get_logger().error("Pygame未安装！请运行: pip3 install pygame")
            return
        
        # 初始化pygame
        try:
            pygame.init()
            
            # 检查是否有手柄
            if pygame.joystick.get_count() == 0:
                self.get_logger().warning("未检测到手柄，请连接手柄后重启节点")
                # 不退出，允许后续连接
            else:
                self.joystick = pygame.joystick.Joystick(0)
                self.joystick.init()
                self.get_logger().info(f"已连接手柄: {self.joystick.get_name()}")
                
        except Exception as e:
            self.get_logger().error(f"手柄初始化失败: {e}")
            return

        # 手柄状态,此为目标增量,并非绝对位置,在控制节点中,通过手柄输出增量来计算目标位置
        self.target_pose = {
            'x': 0.0, 'y': 0.0, 'z': 0.0,
            'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0
        }

        # 按钮状态
        self.lb_pressed = False
        self.rb_pressed = False
        self.deadzone = 0.2        # 摇杆死区
        
        # 控制参数
        self.position_sensitivity = 0.03  # 位置控制灵敏度
        self.orientation_sensitivity = 0.02  # 姿态控制灵敏度
        
        # 创建定时器
        self.timer = self.create_timer(0.02, self.control_loop)  # 50Hz
        self.get_logger().info("Xbox手柄位置控制节点已启动")

    def control_loop(self):
        """主控制循环 - 处理手柄输入并发布目标位置"""
        # 如果没有pygame或没有手柄，直接返回
        if not PYGAME_AVAILABLE:
            return
            
        try:
            # 处理事件
            pygame.event.pump()
            # 检查手柄是否连接
            if pygame.joystick.get_count() == 0:
                return
            # 确保joystick对象存在
            if not hasattr(self, 'joystick'):
                self.joystick = pygame.joystick.Joystick(0)
                self.joystick.init()
                self.get_logger().info(f"手柄已连接: {self.joystick.get_name()}")
        except Exception as e:
            self.get_logger().warning(f"手柄连接问题: {e}")
            return
        
        try:
            # 左摇杆：控制X,Y位置
            left_x = self.joystick.get_axis(0)   # X轴：左右
            left_y = -self.joystick.get_axis(1)  # Y轴：前后
            
            # 应用死区
            if abs(left_x) < self.deadzone:
                left_x = 0.0
            if abs(left_y) < self.deadzone:
                left_y = 0.0
                
            # 基于当前位置计算目标位置
            self.target_pose['x'] = left_x * self.position_sensitivity
            self.target_pose['y'] = left_y * self.position_sensitivity

            # LT/RT：控制Z位置（上下）
            lt = (self.joystick.get_axis(2) + 1) / 2  # 左触发器
            rt = (self.joystick.get_axis(5) + 1) / 2  # 右触发器
            
            # Z方向：RT向上，LT向下
            z_input = rt - lt
            # 修复：使用current_pose.z而不是y
            self.target_pose['z'] = z_input * self.position_sensitivity

            # 右摇杆：控制俯仰和偏航
            right_x = -self.joystick.get_axis(3)   # 偏航 
            right_y = self.joystick.get_axis(4)  # 俯仰 
            
            # 应用死区
            if abs(right_x) < self.deadzone:
                right_x = 0.0
            if abs(right_y) < self.deadzone:
                right_y = 0.0
                
            # 基于当前姿态计算目标姿态
            self.target_pose['yaw'] = right_x * self.orientation_sensitivity
            self.target_pose['roll'] = right_y * self.orientation_sensitivity
            
            # LB/RB：控制横滚 (绕X轴)
            lb_button = self.joystick.get_button(4)
            rb_button = self.joystick.get_button(5)
            roll_input = 0
            
            if lb_button and not rb_button:
                roll_input = -1  # 向左滚
                if not self.lb_pressed:
                    # self.get_logger().info("LB按下：向左横滚")
                    self.lb_pressed = True
            elif rb_button and not lb_button:
                roll_input = 1   # 向右滚
                if not self.rb_pressed:
                    # self.get_logger().info("RB按下：向右横滚")
                    self.rb_pressed = True
            else:
                # 重置按钮状态
                # if self.lb_pressed or self.rb_pressed:
                    # self.get_logger().info("横滚控制释放")
                self.lb_pressed = False
                self.rb_pressed = False
                
            self.target_pose['pitch'] = roll_input * self.orientation_sensitivity
            
            # 发布手柄输出增量
            self.publish_target_pose()
            
            # 可选：打印调试信息
            # self.get_logger().info(f"目标位置: ({self.target_pose['x']:.2f}, {self.target_pose['y']:.2f}, {self.target_pose['z']:.2f})")

        except Exception as e:
            self.get_logger().error(f"处理手柄输入时出错: {e}")

    def publish_target_pose(self):
        """发布目标位置消息"""
        tarPos = PoseStamped()
        tarPos.header.stamp = self.get_clock().now().to_msg()
        tarPos.header.frame_id = "world"
        
        # 设置位置
        tarPos.pose.position = Point(
            x=float(self.target_pose['x']),
            y=float(self.target_pose['y']), 
            z=float(self.target_pose['z'])
        )
        
        # 设置姿态（欧拉角转四元数）
        q = quaternion_from_euler(
            float(self.target_pose['roll']), 
            float(self.target_pose['pitch']), 
            float(self.target_pose['yaw'])
        )
        
        tarPos.pose.orientation = Quaternion(
            x=float(q[0]), 
            y=float(q[1]), 
            z=float(q[2]), 
            w=float(q[3])
        )

        # self.get_logger().info(
        #         f"手柄位置 - x:{self.target_pose['x']:.3f}, y:{self.target_pose['y']:.3f}, z:{self.target_pose['z']:.3f} | "
        #         f"手柄角度 - roll:{self.target_pose['roll']:.2f}, pitch:{self.target_pose['pitch']:.2f}, yaw:{self.target_pose['yaw']:.2f}"
        #     )
        
        self.pose_pub.publish(tarPos)

def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = XboxPoseControl()
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("节点被用户中断")
    except Exception as e:
        print(f"节点运行错误: {e}")
    finally:
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()