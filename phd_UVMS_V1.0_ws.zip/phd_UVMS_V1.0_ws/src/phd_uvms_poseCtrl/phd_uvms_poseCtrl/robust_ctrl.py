#!/usr/bin/env python3
"""
鲁棒控制器节点
融合S面控制和PID控制，支持动态切换
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Wrench, PoseStamped
from phd_master_slave_interfaces.msg import RobustCtrlPara
import math
import numpy as np
from tf_transformations import euler_from_quaternion


class SController:
    """S面控制器"""
    def __init__(self, k1=1.0, k2=0.3, output_limits=(-50.0, 50.0)):
        self.k1 = k1
        self.k2 = k2
        self.output_limits = output_limits
        self.previous_error = 0.0
        
    def reset(self):
        self.previous_error = 0.0
        
    def update(self, error, dt):
        if dt <= 0 or dt > 0.1:
            dt = 0.02
            
        error_dot = (error - self.previous_error) / dt
        exponent = -(self.k1 * error + self.k2 * error_dot)
        exponent = max(-50.0, min(50.0, exponent))
        u = 2.0 / (1.0 + math.exp(exponent)) - 1.0
        self.previous_error = error
        
        min_out, max_out = self.output_limits
        output = min_out + (u + 1.0) / 2.0 * (max_out - min_out)
        return output


class PIDController:
    """PID控制器"""
    def __init__(self, kp=1.0, ki=0.0, kd=0.0, output_limits=(-50.0, 50.0), integral_limit=5.0):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.output_limits = output_limits
        self.integral_limit = integral_limit
        self.previous_error = 0.0
        self.integral = 0.0
        
    def reset(self):
        self.previous_error = 0.0
        self.integral = 0.0
        
    def update(self, error, dt):
        if dt <= 0 or dt > 0.1:
            dt = 0.02
            
        self.integral += error * dt
        self.integral = max(min(self.integral, self.integral_limit), -self.integral_limit)
        derivative = (error - self.previous_error) / dt if dt > 0 else 0.0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        output = max(min(output, self.output_limits[1]), self.output_limits[0])
        self.previous_error = error
        return output


class RobustController(Node):
    """
    鲁棒控制器节点
    支持S面和PID控制动态切换
    """
    def __init__(self):
        super().__init__('robust_ctrl')
        
        # ==================== 控制模式 ====================
        self.MODE_S = 0
        self.MODE_PID = 1
        self.MODE_OTHER = 2
        
        self.robust_mode = self.MODE_S  # 默认S面控制
        
        # ==================== 初始化控制器 ====================
        # S面控制器
        self.s_controllers = {
            'x': SController(k1=3.5, k2=0.3, output_limits=(-50, 50)),
            'y': SController(k1=3.5, k2=0.3, output_limits=(-50, 50)),
            'z': SController(k1=1.5, k2=0.3, output_limits=(-20, 20)),
            'roll': SController(k1=1.2, k2=0.3, output_limits=(-10, 10)),
            'pitch': SController(k1=1.0, k2=0.3, output_limits=(-8, 8)),
            'yaw': SController(k1=1.5, k2=0.5, output_limits=(-20, 20))
        }
        
        # PID控制器
        self.p_controllers = {
            'x': PIDController(kp=30.0, ki=0.0, kd=5.0, output_limits=(-50, 50)),
            'y': PIDController(kp=30.0, ki=0.0, kd=5.0, output_limits=(-50, 50)),
            'z': PIDController(kp=30.0, ki=0.0, kd=5.0, output_limits=(-20, 20)),
            'roll': PIDController(kp=10.0, ki=0.1, kd=2.0, output_limits=(-10, 10)),
            'pitch': PIDController(kp=5.0, ki=0.1, kd=2.0, output_limits=(-8, 8)),
            'yaw': PIDController(kp=5.0, ki=0.1, kd=1.0, output_limits=(-20, 20))
        }
        
        # 当前使用的控制器引用
        self.active_controllers = self.s_controllers
        
        # ==================== 订阅器 ====================
        # 订阅目标位置误差
        self.pos_cmd_loc_sub = self.create_subscription(
            PoseStamped,
            '/pos_cmd_loc',
            self.pos_cmd_loc_callback,
            10
        )
        
        # 订阅控制参数
        self.param_sub = self.create_subscription(
            RobustCtrlPara,
            '/masterMachine/motion_ctrl_para',
            self.param_callback,
            10
        )
        
        # ==================== 发布器 ====================
        self.force_pub = self.create_publisher(Wrench, '/force', 10)
        
        # ==================== 状态变量 ====================
        self.local_errors = {
            'x': 0.0, 'y': 0.0, 'z': 0.0,
            'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0
        }
        self.last_control_time = self.get_clock().now()
        
        # ==================== 控制定时器 (50Hz) ====================
        self.control_timer = self.create_timer(0.02, self.control_loop)
        
        self.get_logger().info("=" * 60)
        self.get_logger().info("鲁棒控制器已启动")
        self.get_logger().info(f"当前控制模式: {'S面' if self.robust_mode == self.MODE_S else 'PID' if self.robust_mode == self.MODE_PID else '其他'}")
        self.get_logger().info("=" * 60)
    
    def pos_cmd_loc_callback(self, msg):
        """处理局部目标位置（误差信息）"""
        self.local_errors['x'] = msg.pose.position.x
        self.local_errors['y'] = msg.pose.position.y
        self.local_errors['z'] = msg.pose.position.z
        
        orientation_q = msg.pose.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        try:
            roll, pitch, yaw = euler_from_quaternion(orientation_list)
            self.local_errors['roll'] = roll
            self.local_errors['pitch'] = pitch
            self.local_errors['yaw'] = yaw
        except Exception as e:
            self.get_logger().warn(f"姿态解算失败: {e}")
    
    def param_callback(self, msg):
        """控制参数回调"""
        try:
            # 更新模式
            new_mode = msg.robust_mode
            if new_mode != self.robust_mode:
                self.robust_mode = new_mode
                if new_mode == self.MODE_S:
                    self.active_controllers = self.s_controllers
                    self.get_logger().info("切换到S面控制模式")
                    self.reset_all_controllers()
                elif new_mode == self.MODE_PID:
                    self.active_controllers = self.p_controllers
                    self.get_logger().info("切换到PID控制模式")
                    self.reset_all_controllers()
                else:
                    self.get_logger().warn(f"未知控制模式: {new_mode}，保持当前模式")
            
            # 更新S面参数
            if msg.robust_mode == self.MODE_S:
                self.update_s_parameters(msg)
            # 更新PID参数
            elif msg.robust_mode == self.MODE_PID:
                self.update_p_parameters(msg)
                
        except Exception as e:
            self.get_logger().error(f"参数更新失败: {e}")
    
    def update_s_parameters(self, msg):
        """更新S面控制器参数"""
        params = {
            'x': (msg.s_x_k1, msg.s_x_k2, msg.s_x_f_lim),
            'y': (msg.s_y_k1, msg.s_y_k2, msg.s_y_f_lim),
            'z': (msg.s_z_k1, msg.s_z_k2, msg.s_z_f_lim),
            'roll': (msg.s_roll_k1, msg.s_roll_k2, msg.s_roll_t_lim),
            'pitch': (msg.s_pitch_k1, msg.s_pitch_k2, msg.s_pitch_t_lim),
            'yaw': (msg.s_yaw_k1, msg.s_yaw_k2, msg.s_yaw_t_lim)
        }
        
        for dof, (k1, k2, lim) in params.items():
            if dof in self.s_controllers:
                self.s_controllers[dof].k1 = float(k1)
                self.s_controllers[dof].k2 = float(k2)
                self.s_controllers[dof].output_limits = (-float(lim), float(lim))
        
        self.get_logger().debug("S面参数已更新")
    
    def update_p_parameters(self, msg):
        """更新PID控制器参数"""
        params = {
            'x': (msg.p_x_kp, msg.p_x_ki, msg.p_x_kd, msg.p_x_f_lim),
            'y': (msg.p_y_kp, msg.p_y_ki, msg.p_y_kd, msg.p_y_f_lim),
            'z': (msg.p_z_kp, msg.p_z_ki, msg.p_z_kd, msg.p_z_f_lim),
            'roll': (msg.p_roll_kp, msg.p_roll_ki, msg.p_roll_kd, msg.p_roll_t_lim),
            'pitch': (msg.p_pitch_kp, msg.p_pitch_ki, msg.p_pitch_kd, msg.p_pitch_t_lim),
            'yaw': (msg.p_yaw_kp, msg.p_yaw_ki, msg.p_yaw_kd, msg.p_yaw_t_lim)
        }
        
        for dof, (kp, ki, kd, lim) in params.items():
            if dof in self.p_controllers:
                self.p_controllers[dof].kp = float(kp)
                self.p_controllers[dof].ki = float(ki)
                self.p_controllers[dof].kd = float(kd)
                self.p_controllers[dof].output_limits = (-float(lim), float(lim))
        
        self.get_logger().debug("PID参数已更新")
    
    def reset_all_controllers(self):
        """重置所有控制器状态"""
        for controllers in [self.s_controllers, self.p_controllers]:
            for ctrl in controllers.values():
                ctrl.reset()
    
    def control_loop(self):
        """控制主循环"""
        current_time = self.get_clock().now()
        dt = (current_time - self.last_control_time).nanoseconds / 1e9
        dt = max(0.01, min(0.05, dt))
        
        # 计算各自由度的控制量
        forces = {}
        for dof in ['x', 'y', 'z', 'roll', 'pitch', 'yaw']:
            forces[dof] = self.active_controllers[dof].update(self.local_errors[dof], dt)
        
        # 发布控制力/力矩
        wrench = Wrench()
        wrench.force.x = float(forces['x'])
        wrench.force.y = float(forces['y'])
        wrench.force.z = float(forces['z'])
        wrench.torque.x = float(forces['roll'])
        wrench.torque.y = float(forces['pitch'])
        wrench.torque.z = float(forces['yaw'])
        
        self.force_pub.publish(wrench)
        
        # 调试输出
        if int(current_time.nanoseconds / 1e9) % 5 == 0:
            mode_str = 'S面' if self.robust_mode == self.MODE_S else 'PID' if self.robust_mode == self.MODE_PID else '其他'
            self.get_logger().debug(
                f"[{mode_str}] "
                f"Fx={forces['x']:.1f}N, Fy={forces['y']:.1f}N, Fz={forces['z']:.1f}N | "
                f"Tx={forces['roll']:.1f}Nm, Ty={forces['pitch']:.1f}Nm, Tz={forces['yaw']:.1f}Nm",
                throttle_duration_sec=2.0
            )
        
        self.last_control_time = current_time


def main(args=None):
    rclpy.init(args=args)
    
    controller = None
    try:
        controller = RobustController()
        rclpy.spin(controller)
    except KeyboardInterrupt:
        if controller:
            controller.get_logger().info("用户中断")
    except Exception as e:
        if controller:
            controller.get_logger().error(f"节点崩溃: {e}")
        else:
            print(f"节点启动失败: {e}")
    finally:
        if controller:
            controller.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()