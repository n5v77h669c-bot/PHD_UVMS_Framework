#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Wrench, Vector3, Twist, Pose
import numpy as np
from scipy.spatial.transform import Rotation as R

class HydrodynamicSimulator(Node):
    def __init__(self):
        super().__init__('sim_hydrodynamic')
        
        # 订阅状态
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10)
        
        # 发布水动力
        self.hydro_force_pub = self.create_publisher(Wrench, '/force_hydrodynamic', 10)
        
        # ROV水动力参数
        self.hydro_params = {
            # 质量属性
            'mass': 30.0,  # kg
            'volume': 0.03,  # m³ 排水体积
            
            # 水的密度
            'water_density': 1025.0,  # kg/m³ 海水
        }
        
        # 计算浮力
        buoyancy_force = self.hydro_params['water_density'] * 9.81 * self.hydro_params['volume']
        self.hydro_params['buoyancy_force'] = buoyancy_force
        
        # 附加质量矩阵对角线元素
        self.added_mass = np.array([15.0, 30.0, 40.0, 2.0, 3.0, 1.5])
        
        # 线性阻尼系数
        self.linear_damping = np.array([50.0, 80.0, 100.0, 20.0, 30.0, 15.0])
        
        # 二次阻尼系数
        self.quadratic_damping = np.array([150.0, 200.0, 250.0, 50.0, 60.0, 40.0])
        
        # 浮心位置（相对于基座标系）[x, y, z]
        self.buoyancy_center = np.array([0.0, 0.0, 0.05])
        
        # 重心位置 [x, y, z]  
        self.gravity_center = np.array([0.0, 0.0, 0.0])
        
        # 惯性矩 [Ixx, Iyy, Izz]
        self.inertia = np.array([2.0, 2.0, 1.5])
        
        # 状态变量
        self.current_velocity = np.zeros(6)  # [u, v, w, p, q, r]
        self.previous_velocity = np.zeros(6)
        self.current_pose = Pose()
        self.last_time = self.get_clock().now()
        
        self.get_logger().info("水动力模拟节点已启动")
        self.get_logger().info(f"浮力: {buoyancy_force:.2f} N, 重力: {self.hydro_params['mass'] * 9.81:.2f} N")

    def odom_callback(self, msg):
        """处理里程计数据，计算水动力"""
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds * 1e-9
        
        if dt < 0.001 or dt > 1.0:  # 避免过小或过大的时间步长
            self.last_time = current_time
            return
            
        # 保存当前姿态
        self.current_pose = msg.pose.pose
        
        # 提取线速度和角速度（机体坐标系）
        linear_vel = np.array([
            msg.twist.twist.linear.x,
            msg.twist.twist.linear.y, 
            msg.twist.twist.linear.z
        ])
        
        angular_vel = np.array([
            msg.twist.twist.angular.x,
            msg.twist.twist.angular.y,
            msg.twist.twist.angular.z
        ])
        
        # 合并为广义速度向量 [u, v, w, p, q, r]（机体坐标系）
        self.current_velocity = np.concatenate([linear_vel, angular_vel])
        
        # 计算水动力（在机体坐标系中）
        hydro_wrench = self.compute_hydrodynamic_forces(dt)
        
        # 发布水动力
        self.hydro_force_pub.publish(hydro_wrench)
        
        # 调试信息
        # self.get_logger().info(
        #     f"速度 - u:{linear_vel[0]:.2f}, v:{linear_vel[1]:.2f}, w:{linear_vel[2]:.2f} | "
        #     f"力 - Fx:{hydro_wrench.force.x:.2f}, Fy:{hydro_wrench.force.y:.2f}, Fz:{hydro_wrench.force.z:.2f}",
        #     throttle_duration_sec=1.0
        # )
        
        self.previous_velocity = self.current_velocity.copy()
        self.last_time = current_time

    def compute_hydrodynamic_forces(self, dt):
        """计算总水动力（在机体坐标系中）"""
        wrench = Wrench()
        
        try:
            # 1. 阻尼力（最主要的阻力）
            damping_force = self.compute_damping_force()
            
            # 2. 附加质量效应
            added_mass_force = self.compute_added_mass_force(dt)
            
            # 3. 恢复力（浮力-重力）- 需要转换到机体坐标系
            restore_force = self.compute_restoring_force()
            
            # 4. 科里奥利力
            coriolis_force = self.compute_coriolis_force()
            
            # 总水动力（在机体坐标系中）
            total_force = damping_force + added_mass_force + restore_force + coriolis_force
            
            # 转换为Wrench消息
            wrench.force = Vector3(
                x=float(total_force[0]),
                y=float(total_force[1]), 
                z=float(total_force[2])
            )
            wrench.torque = Vector3(
                x=float(total_force[3]),
                y=float(total_force[4]),
                z=float(total_force[5])
            )
            
        except Exception as e:
            self.get_logger().error(f"计算水动力时出错: {str(e)}", throttle_duration_sec=1.0)
            # 返回零力
            wrench.force = Vector3(x=0.0, y=0.0, z=0.0)
            wrench.torque = Vector3(x=0.0, y=0.0, z=0.0)
            
        return wrench

    def compute_added_mass_force(self, dt):
        """计算附加质量力"""
        if dt < 1e-6:
            return np.zeros(6)
            
        # 加速度估计（机体坐标系）
        acceleration = (self.current_velocity - self.previous_velocity) / dt
        
        # 附加质量力 = -附加质量矩阵 × 加速度
        added_mass_force = -self.added_mass * acceleration
        
        return added_mass_force

    def compute_damping_force(self):
        """计算流体阻尼力（机体坐标系）"""
        v = self.current_velocity
        damping_force = np.zeros(6)
        
        # 线性阻尼 + 二次阻尼
        for i in range(6):
            linear_damp = -self.linear_damping[i] * v[i]
            quadratic_damp = -self.quadratic_damping[i] * abs(v[i]) * v[i]
            damping_force[i] = linear_damp + quadratic_damp
            
        return damping_force

    def compute_restoring_force(self):
        """计算恢复力（需要从世界坐标系转换到机体坐标系）"""
        restore_force = np.zeros(6)
        
        try:
            # 获取当前姿态的四元数
            q = self.current_pose.orientation
            quaternion = [q.x, q.y, q.z, q.w]
            
            # 创建旋转对象
            rotation = R.from_quat(quaternion)
            
            # 在世界坐标系中的力
            gravity_world = np.array([0.0, 0.0, self.hydro_params['mass'] * 9.81])
            buoyancy_world = np.array([0.0, 0.0, -self.hydro_params['buoyancy_force']])
            
            # 转换到机体坐标系
            gravity_body = rotation.inv().apply(gravity_world)
            buoyancy_body = rotation.inv().apply(buoyancy_world)
            
            # 合力在机体坐标系中
            net_force_body = gravity_body + buoyancy_body
            
            # 计算力矩（由于浮心和重心不重合）
            buoyancy_torque_body = np.cross(
                self.buoyancy_center - self.gravity_center,
                buoyancy_body  # 浮力在机体坐标系中
            )
            
            # 重力作用在重心，力矩为零
            gravity_torque_body = np.zeros(3)
            
            net_torque_body = buoyancy_torque_body + gravity_torque_body
            
            restore_force[0:3] = net_force_body
            restore_force[3:6] = net_torque_body
            
        except Exception as e:
            self.get_logger().warning(f"恢复力计算错误: {str(e)}")
            
        return restore_force

    def compute_coriolis_force(self):
        """计算科里奥利和向心力（简化版本）"""
        v = self.current_velocity
        coriolis_force = np.zeros(6)
        
        try:
            # 线速度和角速度分量
            u, v_val, w = v[0], v[1], v[2]  # 线速度
            p, q, r = v[3], v[4], v[5]  # 角速度
            
            # 质量科里奥利项
            mass = self.hydro_params['mass']
            coriolis_force[0] = mass * (v_val * r - w * q)
            coriolis_force[1] = mass * (w * p - u * r)
            coriolis_force[2] = mass * (u * q - v_val * p)
            
            # 惯性科里奥利项
            Ixx, Iyy, Izz = self.inertia
            coriolis_force[3] = (Izz - Iyy) * q * r
            coriolis_force[4] = (Ixx - Izz) * p * r
            coriolis_force[5] = (Iyy - Ixx) * p * q
            
        except Exception as e:
            self.get_logger().warning(f"科里奥利力计算错误: {str(e)}")
            
        return coriolis_force

def main():
    rclpy.init()
    node = HydrodynamicSimulator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("水动力模拟节点关闭")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()