#!/usr/bin/env python3
import os
import sys
from ament_index_python.packages import get_package_share_directory
from PyQt5 import QtWidgets, uic
from PyQt5.QtCore import pyqtSignal, QTimer

class UIModuleLoader:
    """UI模块加载器 - 负责动态加载和管理.ui文件"""
    
    def __init__(self, ui_dir="ui"):
        self.ui_dir = ui_dir
        self.modules = {}
        self.widgets = {}
        
    def load_module(self, pkg_name, module_name, ui_filename):
        """加载一个UI模块"""
        try:
            pkg_path = os.path.join(
                get_package_share_directory(pkg_name))
            # 构建UI文件路径
            ui_path = os.path.join(
                pkg_path, 
                self.ui_dir, 
                ui_filename
            )
            
            if not os.path.exists(ui_path):
                raise FileNotFoundError(f"UI文件不存在: {ui_path}")
            
            # 加载UI文件
            widget = uic.loadUi(ui_path)
            self.modules[module_name] = {
                'widget': widget,
                'filename': ui_filename,
                'path': ui_path
            }
            self.widgets[module_name] = widget
            
            print(f"✓ 加载模块: {module_name} -> {ui_filename}")
            return widget
            
        except Exception as e:
            print(f"✗ 加载模块失败 {module_name}: {e}")
            return None
    
    def get_module(self, module_name):
        """获取已加载的模块"""
        return self.widgets.get(module_name)
    
    def connect_signals(self, module_name, signal_mapping):
        """连接信号槽"""
        widget = self.get_module(module_name)
        if widget:
            for signal_name, callback in signal_mapping.items():
                try:
                    # 查找控件
                    control = getattr(widget, signal_name, None)
                    if control:
                        if hasattr(control, 'clicked'):
                            control.clicked.connect(callback)
                        elif hasattr(control, 'valueChanged'):
                            control.valueChanged.connect(callback)
                        elif hasattr(control, 'textChanged'):
                            control.textChanged.connect(callback)
                        print(f"  ✓ 连接信号: {signal_name}")
                except Exception as e:
                    print(f"  ✗ 连接信号失败 {signal_name}: {e}")
    
    def set_validator(self, module_name, control_name, validator_type="float"):
        """设置输入验证器（对应你的C++代码功能）"""
        widget = self.get_module(module_name)
        if widget:
            try:
                control = getattr(widget, control_name, None)
                if control and hasattr(control, 'setValidator'):
                    from PyQt5.QtGui import QDoubleValidator, QIntValidator, QRegExpValidator
                    from PyQt5.QtCore import QRegExp
                    
                    if validator_type == "float":
                        # 浮点数验证器（对应你的QRegExpValidator）
                        validator = QDoubleValidator()
                        validator.setNotation(QDoubleValidator.StandardNotation)
                        control.setValidator(validator)
                    elif validator_type == "int":
                        validator = QIntValidator()
                        control.setValidator(validator)
                    elif validator_type == "regex":
                        # 自定义正则表达式
                        regex = QRegExp(r"^[-+]?[0-9]*\.?[0-9]+$")
                        validator = QRegExpValidator(regex)
                        control.setValidator(validator)
                    
                    print(f"  ✓ 设置验证器: {control_name} -> {validator_type}")
            except Exception as e:
                print(f"  ✗ 设置验证器失败 {control_name}: {e}")