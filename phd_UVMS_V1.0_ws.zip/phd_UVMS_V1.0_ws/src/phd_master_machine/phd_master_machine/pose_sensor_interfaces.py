#!/usr/bin/env python3
"""
位姿传感器接口节点
订阅：/sensors/imu_data (MtiImu) - IMU姿态数据
      /sensors/depth_data (Depth) - 深度数据
发布：/odom (nav_msgs/Odometry) - 里程计数据
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
import numpy as np
import math
import threading
from scipy.spatial.transform import Rotation as R

from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseWithCovariance, TwistWithCovariance, Pose, Twist, Point, Quaternion, Vector3
from std_msgs.msg import Header
from builtin_interfaces.msg import Time

from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped

from phd_master_slave_interfaces.msg import MtiImu
from phd_master_slave_interfaces.msg import Depth


class PoseSensorInterfaces(Node):
    
    def __init__(self):
        super().__init__('pose_sensor_interfaces')
        
        # ==================== 参数声明 ====================
        self.declare_parameters(
            namespace='',
            parameters=[
                # 话题名称
                ('imu_topic', '/sensors/imu_data'),
                ('depth_topic', '/sensors/depth_data'),
                ('odom_topic', '/odom'),
                # 坐标系
                ('odom_frame_id', 'odom'),
                ('base_frame_id', 'base_footprint'),
                # 发布频率
                ('publish_hz', 50.0),
                # 协方差设置
                ('pose_covariance_diag', [0.01, 0.01, 0.001, 0.001, 0.001, 0.001]),
                ('twist_covariance_diag', [0.01, 0.01, 0.01, 0.001, 0.001, 0.001]),
                # 调试模式
                ('enable_debug', False),
            ]
        )
        
        # ==================== 参数加载 ====================
        self.imu_topic = self.get_parameter('imu_topic').value
        self.depth_topic = self.get_parameter('depth_topic').value
        self.odom_topic = self.get_parameter('odom_topic').value
        self.odom_frame_id = self.get_parameter('odom_frame_id').value
        self.base_frame_id = self.get_parameter('base_frame_id').value
        self.publish_hz = self.get_parameter('publish_hz').value
        self.pose_covariance_diag = self.get_parameter('pose_covariance_diag').value
        self.twist_covariance_diag = self.get_parameter('twist_covariance_diag').value
        self.enable_debug = self.get_parameter('enable_debug').value
        
        # ==================== 数据存储 ====================
        self.data_lock = threading.Lock()
        
        # IMU数据
        self.imu_data = {
            'roll': 0.0,
            'pitch': 0.0,
            'yaw': 0.0,
            'q0': 1.0,
            'q1': 0.0,
            'q2': 0.0,
            'q3': 0.0,
            'accel_x': 0.0,
            'accel_y': 0.0,
            'accel_z': 0.0,
            'gyro_x': 0.0,
            'gyro_y': 0.0,
            'gyro_z': 0.0,
            'timestamp': self.get_clock().now(),
            'data_valid': False
        }
        
        # 深度数据
        self.depth_data = {
            'depth': 0.0,
            'temperature': 0.0,
            'timestamp': self.get_clock().now(),
            'data_valid': False
        }
        
        # 时间戳
        self.last_publish_time = self.get_clock().now()
        
        qos_profile = QoSProfile(
            depth=50,
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST
        )

        # 订阅
        self.imu_sub = self.create_subscription(
            MtiImu,
            self.imu_topic,
            self.imu_callback,
            qos_profile
        )
        
        self.depth_sub = self.create_subscription(
            Depth,
            self.depth_topic,
            self.depth_callback,
            qos_profile
        )

        # 发布
        self.odom_pub = self.create_publisher(
            Odometry,
            self.odom_topic,
            10
        )

        # 定时发布Odometry
        publish_interval = 1.0 / self.publish_hz
        self.publish_timer = self.create_timer(publish_interval, self.publish_odometry)

        # 发布tf
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # ==================== 初始化日志 ====================
        self.get_logger().info("=" * 60)
        self.get_logger().info("位姿传感器接口节点启动")
        self.get_logger().info(f"订阅IMU话题: {self.imu_topic}")
        self.get_logger().info(f"订阅深度话题: {self.depth_topic}")
        self.get_logger().info(f"发布Odometry话题: {self.odom_topic}")
        self.get_logger().info(f"坐标系: {self.odom_frame_id} -> {self.base_frame_id}")
        self.get_logger().info(f"发布频率: {self.publish_hz}Hz")
        self.get_logger().info("=" * 60)
    
    # ==================== 回调函数 ====================
    
    def imu_callback(self, msg: MtiImu):
        """IMU数据回调"""
        with self.data_lock:
            self.imu_data['roll'] = msg.roll
            self.imu_data['pitch'] = msg.pitch
            self.imu_data['yaw'] = msg.yaw
            self.imu_data['q0'] = msg.q0
            self.imu_data['q1'] = msg.q1
            self.imu_data['q2'] = msg.q2
            self.imu_data['q3'] = msg.q3
            self.imu_data['accel_x'] = msg.accel_x
            self.imu_data['accel_y'] = msg.accel_y
            self.imu_data['accel_z'] = msg.accel_z
            self.imu_data['gyro_x'] = msg.gyro_x
            self.imu_data['gyro_y'] = msg.gyro_y
            self.imu_data['gyro_z'] = msg.gyro_z
            self.imu_data['timestamp'] = self.get_clock().now()
            self.imu_data['data_valid'] = msg.data_valid
        
        if self.enable_debug and self.imu_data['data_valid']:
            self.get_logger().debug(
                f"IMU: yaw={msg.yaw:.1f}°, pitch={msg.pitch:.1f}°, roll={msg.roll:.1f}°",
                throttle_duration_sec=1.0
            )
    
    def depth_callback(self, msg: Depth):
        """深度数据回调"""
        with self.data_lock:
            self.depth_data['depth'] = msg.depth
            self.depth_data['temperature'] = msg.temp_water
            self.depth_data['timestamp'] = self.get_clock().now()
            self.depth_data['data_valid'] = True
        
        if self.enable_debug:
            self.get_logger().debug(
                f"深度: {msg.depth:.2f}m",
                throttle_duration_sec=1.0
            )
    
    # ==================== Odometry发布 ====================
    
    def publish_odometry(self):
        """发布Odometry消息"""
        try:
            with self.data_lock:
                # 检查数据有效性
                # imu_valid = self.imu_data['data_valid']
                # depth_valid = self.depth_data['data_valid']
                
                # if not imu_valid:
                #     self.get_logger().warn("IMU数据无效", throttle_duration_sec=5.0)
                
                # 创建Odometry消息
                odom_msg = Odometry()
                
                # Header
                odom_msg.header = Header()
                odom_msg.header.stamp = self.get_clock().now().to_msg()
                odom_msg.header.frame_id = self.odom_frame_id
                odom_msg.child_frame_id = self.base_frame_id
                
                # ========== 位姿 (Pose) ==========
                # 位置 Position (x, y, z)
                # x, y: 真实ROV无法获取，设为固定值
                # z: 从深度计获取，注意坐标系：ROS中z轴向上，深度是向下的，所以取负值
                odom_msg.pose.pose.position = Point()
                # odom_msg.pose.pose.position.x = 
                # odom_msg.pose.pose.position.y = 
                odom_msg.pose.pose.position.z = -self.depth_data['depth']
                
                # 姿态 Orientation (四元数)

                odom_msg.pose.pose.orientation = Quaternion(
                    w=self.imu_data['q0'],
                    x=self.imu_data['q1'],
                    y=self.imu_data['q2'],
                    z=self.imu_data['q3']
                )
                
                # 位姿协方差 (6x6)
                # [x, y, z, roll, pitch, yaw]
                odom_msg.pose.covariance = self._create_covariance_matrix(
                    self.pose_covariance_diag
                )
                
                # ========== 速度 (Twist) ==========
                # 线速度 Linear
                # odom_msg.twist.twist.linear = Vector3()
                
                # 从加速度积分得到速度（简化版，后续可以完善）
                # 目前先设为0，等待后续开发
                # odom_msg.twist.twist.linear.x = 0.0
                # odom_msg.twist.twist.linear.y = 0.0
                # odom_msg.twist.twist.linear.z = 0.0
                
                # 角速度 Angular (来自IMU陀螺仪)
                # odom_msg.twist.twist.angular = Vector3(
                #     x=self.imu_data['gyro_x'],
                #     y=self.imu_data['gyro_y'],
                #     z=self.imu_data['gyro_z']
                # )
                # 速度协方差 (6x6)
                # odom_msg.twist.covariance = self._create_covariance_matrix(
                #     self.twist_covariance_diag
                # )

                t = TransformStamped()
                t.header.stamp = self.get_clock().now().to_msg()
                t.header.frame_id = self.odom_frame_id      # "odom"
                t.child_frame_id = self.base_frame_id       # "base_link"
                
                # 位置
                # t.transform.translation.x = self.fixed_x
                # t.transform.translation.y = self.fixed_y
                t.transform.translation.z = -self.depth_data['depth']
                t.transform.rotation.w = self.imu_data['q0']
                t.transform.rotation.x = self.imu_data['q1']
                t.transform.rotation.y = self.imu_data['q2']
                t.transform.rotation.z = self.imu_data['q3']
                
                # 发布Odometry 与 TF
                self.tf_broadcaster.sendTransform(t)
                self.odom_pub.publish(odom_msg)
                
                # 调试输出
                if self.enable_debug:
                    self.get_logger().debug(
                        f"{-self.depth_data['depth']:.2f}), "
                        f"yaw={self.imu_data['yaw']:.1f}°",
                        throttle_duration_sec=1.0
                    )
                
        except Exception as e:
            self.get_logger().error(f"发布Odometry失败: {e}")
    
    def _create_covariance_matrix(self, diagonal_values):
        """
        创建6x6对角协方差矩阵
        参数: [x, y, z, roll, pitch, yaw] 的对角线值
        """
        covariance = [0.0] * 36
        for i in range(6):
            if i < len(diagonal_values):
                covariance[i * 7] = diagonal_values[i]  # 对角线索引: i*7 + i
            else:
                covariance[i * 7] = 0.001  # 默认值
        return covariance
    
    def quaternion_to_euler(self, q):
        """四元数转欧拉角（调试用）"""
        try:
            rotation = R.from_quat([q.x, q.y, q.z, q.w])
            euler = rotation.as_euler('xyz', degrees=True)
            return euler[0], euler[1], euler[2]
        except:
            return 0.0, 0.0, 0.0
    
    def destroy_node(self):
        """清理资源"""
        self.get_logger().info("关闭位姿传感器接口节点...")
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = PoseSensorInterfaces()
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("用户中断")
    except Exception as e:
        node.get_logger().error(f"节点崩溃: {e}")
    finally:
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()