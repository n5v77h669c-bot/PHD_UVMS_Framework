#!/usr/bin/env python3
import sys
import rclpy
from rclpy.node import Node
from PyQt5 import QtWidgets, uic
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtWidgets import (
    QMainWindow, QDockWidget, QTabWidget, 
    QVBoxLayout, QHBoxLayout, QSplitter,QWidget,QGroupBox
)

from phd_master_machine.rqt_ui_loader import UIModuleLoader
from phd_master_machine.ui_modules.rov_status import ROVStatusMonitor
from phd_master_machine.ui_modules.motion_ctrl import MotionControlModule
from phd_master_machine.ui_modules.sensor_ctrl import SensorControlModule
from phd_master_machine.ui_modules.motion_para_ctrl import MotionParaControlModule

class ROVControlPanel(QMainWindow):
    """ROV上位机主窗口"""
    
    def __init__(self, ros_node=None):
        super().__init__()
        self.package_name = 'phd_master_machine'
        
        # 初始化ROS节点
        self.ros_node = ros_node


        if not self.ros_node:
            rclpy.init(args=sys.argv)
            self.ros_node = Node('rov_control_panel')
        
        
        # 初始化UI加载器
        self.ui_loader = UIModuleLoader()
              
        # 设置窗口属性
        self.setWindowTitle("ROV控制面板")
        self.setGeometry(0, 0, 1024, 1280)
        
        # 加载主窗口UI
        self.load_main_ui()
        
        # 加载所有模块
        self.load_all_modules()
        
        self.init_status_module()
        self.init_motion_control_module()
        self.init_sensor_control_module()
        self.init_motion_para_control_module()

        self.timer = QTimer()
        self.timer.timeout.connect(self.ros_spin)
        self.timer.start(50)  # 20Hz
        
    def load_main_ui(self):
        """加载主窗口布局"""
        # 中央布局
        central_widget = QtWidgets.QWidget()
        self.setCentralWidget(central_widget)

         # 创建主垂直布局（相当于垂直LinearLayout）
        main_layout = QHBoxLayout(central_widget)
        main_layout.setSpacing(0)  # 控件间距

        left_container = QWidget()
        left_layout = QVBoxLayout(left_container)
        self.motion_ctrl_container = QGroupBox("运动控制")
        self.motion_ctrl_container.setMinimumHeight(600)

        self.bottom_tabs = QTabWidget()
        self.sensor_ctrl_container = QWidget()
        self.motion_para_ctrl_container = QWidget()

        self.bottom_tabs.addTab(self.sensor_ctrl_container, "传感器控制")
        self.bottom_tabs.addTab(self.motion_para_ctrl_container, "运动参数控制")

        left_layout.addWidget(self.motion_ctrl_container)
        left_layout.addWidget(self.bottom_tabs)

        right_container = QWidget()
        right_layout = QVBoxLayout(right_container)

        self.rov_status_container = QGroupBox("ROV状态显示")
        right_layout.addWidget(self.rov_status_container)

        main_splitter = QSplitter(Qt.Horizontal)
        main_splitter.addWidget(left_container)
        main_splitter.addWidget(right_container)
        main_splitter.setSizes([670, 550])

        main_layout.addWidget(main_splitter)
        self.left_splitter = main_splitter

    def load_all_modules(self):
        """加载所有UI模块"""
        motion_ctrl_widget = self.ui_loader.load_module(self.package_name, "motion_ctrl", "ui_motion_ctrl.ui")
        if motion_ctrl_widget:
            self.place_widget_in_container(motion_ctrl_widget, self.motion_ctrl_container, "运动控制")
            self.motion_ctrl_widget = motion_ctrl_widget

        sensor_ctrl_widget = self.ui_loader.load_module(self.package_name, "sensor_ctrl", "ui_sensor_ctrl.ui")
        if sensor_ctrl_widget:
            self.place_widget_in_container( sensor_ctrl_widget, self.sensor_ctrl_container, "声纳控制系统")
            self.sensor_ctrl_widget = sensor_ctrl_widget
        
        motion_para_ctrl_widget = self.ui_loader.load_module(self.package_name, "motion_para_ctrl", "ui_motion_para_ctrl.ui")
        if motion_para_ctrl_widget:
            self.place_widget_in_container( motion_para_ctrl_widget, self.motion_para_ctrl_container, "运动参数控制")
            self.motion_para_ctrl_widget = motion_para_ctrl_widget
        
        rov_status_widget = self.ui_loader.load_module(self.package_name, "rov_status", "ui_rov_status.ui")
        if rov_status_widget:
            self.place_widget_in_container(rov_status_widget, self.rov_status_container, "ROV状态监控")
            self.rov_status_widget = rov_status_widget

    def place_widget_in_container(self, widget, container, title=None):
        """把widget放入指定的容器"""
        # 清空容器原有内容
        if container.layout():
            while container.layout().count():
                item = container.layout().takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
        else:
            # 创建新布局
            layout = QVBoxLayout()
            layout.setContentsMargins(10, 10, 10, 10)
            container.setLayout(layout)
        
        # 如果是GroupBox，设置标题
        if isinstance(container, QGroupBox) and title:
            container.setTitle(title)
        
        # 添加widget到容器
        container.layout().addWidget(widget)
        print(f"✓ 已放置: {title}")

    
    def init_status_module(self):
        """初始化状态监控模块"""
        if hasattr(self, 'rov_status_widget'):
            self.status_monitor = ROVStatusMonitor(
                ui_widget=self.rov_status_widget,
                ros_node=self.ros_node,
                update_rate=20.0  # 20Hz更新
            )
            self.ros_node.get_logger().info("状态监控模块初始化完成")

    def init_motion_control_module(self):
        """初始化运动控制模块"""
        if hasattr(self, 'motion_ctrl_widget'):
            # 创建运动控制模块
            self.motion_control = MotionControlModule(
                ui_widget=self.motion_ctrl_widget,
                ros_node=self.ros_node,
            )
            self.ros_node.get_logger().info("运动控制模块初始化完成")

    def init_sensor_control_module(self):
        """初始化传感器控制模块"""
        if hasattr(self, 'sensor_ctrl_widget'):
            self.sensor_control = SensorControlModule(
                ui_widget=self.sensor_ctrl_widget,
                ros_node=self.ros_node,
            )
            self.ros_node.get_logger().info("传感器控制模块初始化完成")

    def init_motion_para_control_module(self):
        """初始化运动参数控制模块"""
        if hasattr(self, 'motion_para_ctrl_widget'):
            self.motion_para_control = MotionParaControlModule(
                ui_widget=self.motion_para_ctrl_widget,
                ros_node=self.ros_node
        )
        self.ros_node.get_logger().info("运动参数控制模块初始化完成")
    
    def ros_spin(self):
        """处理ROS事件"""
        rclpy.spin_once(self.ros_node, timeout_sec=0)
    
    def closeEvent(self, event):
        """窗口关闭事件"""
        self.timer.stop()
        if self.ros_node:
            self.ros_node.destroy_node()
        rclpy.shutdown()
        event.accept()
    

def main():
    app = QtWidgets.QApplication(sys.argv)
    
    # 创建ROS节点
    rclpy.init(args=sys.argv)
    ros_node = Node('rov_control_panel')
    
    # 创建主窗口
    window = ROVControlPanel(ros_node)
    window.show()
    
    # 运行应用
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()