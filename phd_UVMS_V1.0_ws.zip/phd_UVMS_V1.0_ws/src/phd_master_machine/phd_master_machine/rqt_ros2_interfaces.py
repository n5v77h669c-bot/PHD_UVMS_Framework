#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray, String
from geometry_msgs.msg import Twist

class ROS2Interface:
    """ROS 2通信接口"""
    
    def __init__(self, node):
        self.node = node
        
        # 创建发布器
        self.thruster_pub = self.node.create_publisher(
            Float32MultiArray, 
            '/rov/thruster_control', 
            10
        )
        
        self.velocity_pub = self.node.create_publisher(
            Twist,
            '/rov/cmd_vel',
            10
        )
        
        # 创建订阅器（用于接收状态）
        self.node.create_subscription(
            String,
            '/rov/status',
            self.status_callback,
            10
        )
        
        print("ROS 2接口初始化完成")
    
    def publish_thruster_control(self, control_data):
        """发布推力器控制消息"""
        msg = Float32MultiArray()
        
        # 按固定顺序排列推力器数据
        order = ['LF_hor', 'LF_ver', 'RF_hor', 'RF_ver', 
                 'LB_hor', 'LB_ver', 'RB_hor', 'RB_ver']
        
        for thruster in order:
            value = control_data.get(thruster, 0.0)
            msg.data.append(float(value))
        
        self.thruster_pub.publish(msg)
        self.node.get_logger().info(f'发布推力器控制: {msg.data}')
    
    def publish_velocity_command(self, linear_x, linear_y, angular_z):
        """发布速度控制命令"""
        msg = Twist()
        msg.linear.x = float(linear_x)
        msg.linear.y = float(linear_y)
        msg.angular.z = float(angular_z)
        
        self.velocity_pub.publish(msg)
        self.node.get_logger().info(f'发布速度命令: vx={linear_x}, vy={linear_y}, wz={angular_z}')
    
    def status_callback(self, msg):
        """状态回调函数"""
        self.node.get_logger().info(f'收到状态: {msg.data}')
        # 这里可以更新UI状态显示