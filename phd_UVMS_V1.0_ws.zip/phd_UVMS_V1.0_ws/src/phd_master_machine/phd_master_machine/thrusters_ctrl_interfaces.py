#!/usr/bin/env python3
"""
推进器控制接口节点
负责接收运动控制指令和力分配结果，转换为推进器功率指令
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
import numpy as np
from typing import Dict, List, Optional
import threading

from geometry_msgs.msg import Wrench
from phd_master_slave_interfaces.msg import MasterMachineUI
from phd_master_slave_interfaces.msg import ThrusterStatus


class ThrustersCtrlInterfaces(Node):
    """
    推进器控制接口
    订阅：/motionCtrl (MasterMachineUI) - 上位机控制指令
          /force_lfu, /force_lfd, ... (Wrench) - 力分配节点输出的力
    发布：/thrusters/command (ThrusterStatus) - 推进器功率指令
    """
    
    def __init__(self):
        super().__init__('thrusters_ctrl_interfaces')
        
        # ==================== 模式定义 ====================
        self.MODE = {
            'MANUAL': 0,           # 全手操模式
            'XBOX_CONTROLLER': 1,  # 手柄遥控模式
            'KEYBOARD': 2,         # 键盘遥控模式
            'AUTOMATIC': 3,        # 自动模式
        }
        
        self.MODE_NAMES = {
            0: '全手操模式',
            1: '手柄遥控模式',
            2: '键盘遥控模式',
            3: '自动模式'
        }
        
        # ==================== 推进器配置 ====================
        self.thruster_names = ['lfu', 'lfd', 'rfu', 'rfd', 'lbu', 'lbd', 'rbu', 'rbd']
        
        # 推进器编号索引
        self.thruster_indices = {name: i for i, name in enumerate(self.thruster_names)}
        
        # ==================== 参数声明 ====================
        self.declare_parameters(
            namespace='',
            parameters=[
                # 话题名称
                ('motion_ctrl_topic', '/masterMachine/motionCtrl'),
                ('thrusters_command_topic', '/masterMachine/thrusters_command'),
                # 力到功率转换参数
                ('force_to_power_scale', 1.0),    # 力转功率缩放系数 (N -> %)
                ('max_power', 100.0),             # 最大功率百分比
                ('min_power', -100.0),            # 最小功率百分比
                # 死区设置
                ('deadband_enabled', True),       # 是否启用死区
                ('force_deadband', 1.0),          # 力死区 (N)
                # 控制模式
                ('default_mode', 0),              # 默认模式：全手操
                # 发布频率
                ('command_publish_hz', 50.0),     # 指令发布频率
                # 安全设置
                ('timeout_seconds', 1.0),         # 指令超时时间
            ]
        )
        
        # ==================== 参数加载 ====================
        self.motion_ctrl_topic = self.get_parameter('motion_ctrl_topic').value
        self.thrusters_command_topic = self.get_parameter('thrusters_command_topic').value
        self.force_to_power_scale = self.get_parameter('force_to_power_scale').value
        self.max_power = self.get_parameter('max_power').value
        self.min_power = self.get_parameter('min_power').value
        self.deadband_enabled = self.get_parameter('deadband_enabled').value
        self.force_deadband = self.get_parameter('force_deadband').value
        self.default_mode = self.get_parameter('default_mode').value
        self.command_publish_hz = self.get_parameter('command_publish_hz').value
        self.timeout_seconds = self.get_parameter('timeout_seconds').value
        
        # ==================== 数据存储 ====================
        self.data_lock = threading.Lock()
        
        # 当前控制模式
        self.current_mode = self.default_mode
        
        # 全手操模式指令（来自UI）
        self.manual_powers = {
            'lfu': 0, 'lfd': 0, 'rfu': 0, 'rfd': 0,
            'lbu': 0, 'lbd': 0, 'rbu': 0, 'rbd': 0
        }
        
        # 力分配节点计算的力
        self.force_values = {
            'lfu': 0.0, 'lfd': 0.0, 'rfu': 0.0, 'rfd': 0.0,
            'lbu': 0.0, 'lbd': 0.0, 'rbu': 0.0, 'rbd': 0.0
        }
        
        # 最终输出的功率指令
        self.output_powers = {
            'lfu': 0, 'lfd': 0, 'rfu': 0, 'rfd': 0,
            'lbu': 0, 'lbd': 0, 'rbu': 0, 'rbd': 0
        }
        
        # 时间戳
        self.last_motion_ctrl_time = self.get_clock().now()
        self.last_force_times = {name: self.get_clock().now() for name in self.thruster_names}
        
        # 统计信息
        self.stats = {
            'mode_changes': 0,
            'commands_sent': 0,
            'timeout_count': 0,
            'force_timeout_count': 0,
        }

        # 推力曲线数据
        self.init_thrust_curve()
        
        # ==================== QoS配置 ====================
        self.reliable_qos = QoSProfile(
            depth=10,
            reliability=QoSReliabilityPolicy.RELIABLE,
            history=QoSHistoryPolicy.KEEP_LAST
        )
        
        self.best_effort_qos = QoSProfile(
            depth=10,
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST
        )
        
        # ==================== 订阅器 ====================
        # 订阅运动控制指令（来自UI）
        self.motion_ctrl_sub = self.create_subscription(
            MasterMachineUI,
            self.motion_ctrl_topic,
            self.motion_ctrl_callback,
            self.reliable_qos
        )
        
        # 订阅8个推进器的力话题
        self.force_subs = {}
        for name in self.thruster_names:
            topic = f'/force_{name}'
            self.force_subs[name] = self.create_subscription(
                Wrench,
                topic,
                lambda msg, n=name: self.force_callback(msg, n),
                self.best_effort_qos
            )
        
        # ==================== 发布器 ====================
        # 推进器指令发布器
        self.command_pub = self.create_publisher(
            ThrusterStatus,
            self.thrusters_command_topic,
            self.reliable_qos
        )
        
        # ==================== 定时器 ====================
        # 指令发布定时器
        command_interval = 1.0 / self.command_publish_hz
        self.command_timer = self.create_timer(command_interval, self.publish_commands)

        
        # ==================== 初始化日志 ====================
        self.get_logger().info("=" * 60)
        self.get_logger().info("推进器控制接口节点启动")
        self.get_logger().info(f"订阅运动控制话题: {self.motion_ctrl_topic}")
        self.get_logger().info(f"发布推进器指令话题: {self.thrusters_command_topic}")
        self.get_logger().info(f"力转功率系数: {self.force_to_power_scale}")
        self.get_logger().info(f"死区设置: {'启用' if self.deadband_enabled else '禁用'}, {self.force_deadband}N")
        self.get_logger().info(f"默认控制模式: {self.MODE_NAMES[self.default_mode]}")
        self.get_logger().info(f"指令发布频率: {self.command_publish_hz}Hz")
        self.get_logger().info("=" * 60)
    
    # ==================== 力到功率转换函数 ====================
    
    def init_thrust_curve(self):
        """初始化推力曲线数据"""
        g = 9.8
        # 反转推力数据 (电压 -> 推力N)
        self.reverse_thrust_data = [
            (10.0, 1.1 * g),   # 10V -> 1.1kgf
            (16.0, 2.6 * g),   # 16V -> 2.6kgf
            (20.0, 3.5 * g),   # 20V -> 3.5kgf
            (26.0, 5.5 * g),   # 26V -> 5.5kgf
        ]
        # 正转推力数据 (推力 × 1.2)
        self.forward_thrust_data = [
            (v, f * 1.2) for v, f in self.reverse_thrust_data
        ]
        # 最大电压
        self.max_voltage = 26.0
        # 方向修正系数
        self.dir_coe = {
            'lfu': 1,
            'lfd': -1,
            'rfu': -1,
            'rfd': 1,
            'lbu': -1,
            'lbd': 1,
            'rbu': 1,
            'rbd': -1,
        }

    def force_to_power(self, force: float) -> int:
        """
        将力(N)转换为推进器功率百分比(-100 ~ 100)
        """
        # 死区处理
        if self.deadband_enabled and abs(force) < self.force_deadband:
            return 0
        # 根据方向选择数据表
        if force >= 0:
            thrust_data = self.forward_thrust_data
            max_thrust = thrust_data[-1][1]
            
            if force >= max_thrust:
                power = 100.0
            else:
                voltage = self._interpolate_force_to_voltage(force, thrust_data)
                power = (voltage / self.max_voltage) * 100.0
                power = max(0.0, min(100.0, power))
        else:
            thrust_data = self.reverse_thrust_data
            abs_force = abs(force)
            max_thrust = thrust_data[-1][1]
            if abs_force >= max_thrust:
                power = -100.0
            else:
                voltage = self._interpolate_force_to_voltage(abs_force, thrust_data)
                power = -(voltage / self.max_voltage) * 100.0
                power = max(-100.0, min(0.0, power))
        return int(round(power))
    
    def _interpolate_force_to_voltage(self, force: float, data: List[tuple]) -> float:
        """线性插值：力 -> 电压"""
        # 外推处理
        if force <= data[0][1]:
            if data[0][1] > 0:
                return data[0][0] * (force / data[0][1])
            return 0.0
        if force >= data[-1][1]:
            return data[-1][0]
        # 查找区间并插值
        for i in range(len(data) - 1):
            if data[i][1] <= force <= data[i+1][1]:
                f1, v1 = data[i][1], data[i][0]
                f2, v2 = data[i+1][1], data[i+1][0]
                if f2 - f1 > 0:
                    return v1 + (v2 - v1) * (force - f1) / (f2 - f1)
                return v1
        return data[-1][0]
    
    # ==================== 回调函数 ====================
    
    def motion_ctrl_callback(self, msg: MasterMachineUI):
        """
        运动控制指令回调（来自UI）
        """
        with self.data_lock:
            # 更新控制模式
            if msg.control_mode != self.current_mode:
                old_mode = self.current_mode
                self.current_mode = msg.control_mode
                self.stats['mode_changes'] += 1
                self.get_logger().info(
                    f"控制模式切换: {self.MODE_NAMES.get(old_mode, '未知')} -> "
                    f"{self.MODE_NAMES.get(self.current_mode, '未知')}"
                )
            
            # 更新全手操模式功率指令
            if self.current_mode == self.MODE['MANUAL']:
                self.manual_powers['lfu'] = msg.manual_lfu
                self.manual_powers['lfd'] = msg.manual_lfd
                self.manual_powers['rfu'] = msg.manual_rfu
                self.manual_powers['rfd'] = msg.manual_rfd
                self.manual_powers['lbu'] = msg.manual_lbu
                self.manual_powers['lbd'] = msg.manual_lbd
                self.manual_powers['rbu'] = msg.manual_rbu
                self.manual_powers['rbd'] = msg.manual_rbd
                
                # 调试输出
                # self.get_logger().debug(
                #     f"手操模式功率: {list(self.manual_powers.values())}",
                #     throttle_duration_sec=1.0
                # )
        
        self.last_motion_ctrl_time = self.get_clock().now()
    
    def force_callback(self, msg: Wrench, thruster_name: str):
        """
        推进器力回调（来自力分配节点）
        """
        with self.data_lock:
            # Wrench消息中，沿推进器轴线的力在z方向
            force = msg.force.z
            self.force_values[thruster_name] = force
            
            # 调试输出
            # self.get_logger().debug(
            #     f"{thruster_name} 力: {force:.2f}N",
            #     throttle_duration_sec=0.5
            # )
        
        self.last_force_times[thruster_name] = self.get_clock().now()
    
    # ==================== 核心逻辑 ====================
    
    def calculate_output_powers(self):
        """
        根据当前控制模式计算最终输出功率
        """
        with self.data_lock:
            now = self.get_clock().now()
            for name in self.thruster_names:
                if self.current_mode == self.MODE['MANUAL']:
                    self.output_powers[name] = self.manual_powers[name]
                else:
                    force = self.force_values[name] * self.dir_coe[name]
                    self.output_powers[name] = self.force_to_power(force)
    
    def publish_commands(self):
        try:
            # 计算当前输出功率
            self.calculate_output_powers()
            # 创建推进器指令消息
            cmd_msg = ThrusterStatus()
            cmd_msg.timestamp = self.get_clock().now().to_msg()
            
            with self.data_lock:
                # 设置功率（ThrusterStatus期望的范围是0-200）
                cmd_msg.set_power_lfu = self.output_powers['lfu'] + 100
                cmd_msg.set_power_lfd = self.output_powers['lfd'] + 100
                cmd_msg.set_power_rfu = self.output_powers['rfu'] + 100
                cmd_msg.set_power_rfd = self.output_powers['rfd'] + 100
                cmd_msg.set_power_lbu = self.output_powers['lbu'] + 100
                cmd_msg.set_power_lbd = self.output_powers['lbd'] + 100
                cmd_msg.set_power_rbu = self.output_powers['rbu'] + 100
                cmd_msg.set_power_rbd = self.output_powers['rbd'] + 100
                # 状态标志
                cmd_msg.data_valid = True
                cmd_msg.temperature = 25.0
            # 发布指令
            self.command_pub.publish(cmd_msg)
            self.stats['commands_sent'] += 1
            
            # 调试输出（降低频率）
            # if self.stats['commands_sent'] % 50 == 0:
            #     powers = [
            #         self.output_powers['lfu'],
            #         self.output_powers['lfd'],
            #         self.output_powers['rfu'],
            #         self.output_powers['rfd'],
            #         self.output_powers['lbu'],
            #         self.output_powers['lbd'],
            #         self.output_powers['rbu'],
            #         self.output_powers['rbd']
            #     ]
            #     self.get_logger().debug(
            #         f"发布指令 [{self.MODE_NAMES.get(self.current_mode, '未知')}]: {powers}"
            #     )
            
        except Exception as e:
            self.get_logger().error(f"发布指令失败: {e}")
    
    def print_statistics(self):
        """
        打印统计信息
        """
        self.get_logger().info(
            f"统计: 模式切换={self.stats['mode_changes']} | "
            f"指令发送={self.stats['commands_sent']} | "
            f"指令超时={self.stats['timeout_count']} | "
            f"力超时={self.stats['force_timeout_count']}"
        )
        # 重置计数（可选）
        # self.stats['commands_sent'] = 0
    
    def destroy_node(self):
        """
        清理资源
        """
        self.get_logger().info("关闭推进器控制接口节点...")
        
        # 发送停止指令
        try:
            stop_msg = ThrusterStatus()
            stop_msg.timestamp = self.get_clock().now().to_msg()
            stop_msg.set_power_lfu = 100
            stop_msg.set_power_lfd = 100
            stop_msg.set_power_rfu = 100
            stop_msg.set_power_rfd = 100
            stop_msg.set_power_lbu = 100
            stop_msg.set_power_lbd = 100
            stop_msg.set_power_rbu = 100
            stop_msg.set_power_rbd = 100
            stop_msg.data_valid = True
            self.command_pub.publish(stop_msg)
            self.get_logger().info("发送停止指令")
        except Exception as e:
            self.get_logger().error(f"发送停止指令失败: {e}")
        
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = ThrustersCtrlInterfaces()
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("用户中断")
    except Exception as e:
        node.get_logger().error(f"节点崩溃: {e}")
    finally:
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()