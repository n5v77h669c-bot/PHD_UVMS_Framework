#!/usr/bin/env python3
import yaml
import os

class ModuleManager:
    """模块管理器 - 通过配置文件管理UI模块"""
    
    def __init__(self, config_file="config/modules.yaml"):
        self.config_file = config_file
        self.modules_config = self.load_config()
    
    def load_config(self):
        """加载模块配置文件"""
        config_path = os.path.join(
            os.path.dirname(__file__), 
            self.config_file
        )
        
        default_config = {
            'modules': [
                {
                    'name': 'manual_control',
                    'ui_file': 'manual_control.ui',
                    'display_name': '手动控制',
                    'dock_area': 'left',
                    'enabled': True,
                    'validators': {
                        'man_Ctrl_LF_hor_prop_vol': 'float',
                        'man_Ctrl_LF_ver_prop_vol': 'float',
                        # ... 其他验证器配置
                    }
                },
                {
                    'name': 'auto_control',
                    'ui_file': 'auto_control.ui',
                    'display_name': '自动控制',
                    'dock_area': 'left',
                    'enabled': True
                },
                {
                    'name': 'video_display',
                    'ui_file': 'video_display.ui',
                    'display_name': '视频显示',
                    'dock_area': 'right',
                    'enabled': True
                }
            ],
            'layout': {
                'main_window': {'width': 1600, 'height': 900},
                'splitter_sizes': {'left': 400, 'right': 1200}
            }
        }
        
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        else:
            # 保存默认配置
            self.save_config(default_config)
            return default_config
    
    def save_config(self, config):
        """保存配置"""
        config_path = os.path.join(
            os.path.dirname(__file__), 
            self.config_file
        )
        
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
    
    def get_enabled_modules(self):
        """获取启用的模块"""
        return [m for m in self.modules_config.get('modules', []) 
                if m.get('enabled', True)]
    
    def add_module(self, module_config):
        """添加新模块"""
        self.modules_config['modules'].append(module_config)
        self.save_config(self.modules_config)
    
    def remove_module(self, module_name):
        """移除模块"""
        self.modules_config['modules'] = [
            m for m in self.modules_config['modules']
            if m.get('name') != module_name
        ]
        self.save_config(self.modules_config)