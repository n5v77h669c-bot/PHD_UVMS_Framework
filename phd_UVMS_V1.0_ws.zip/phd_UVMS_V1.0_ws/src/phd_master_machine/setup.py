from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'phd_master_machine'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'ui'), glob('ui/*.ui')),
        (os.path.join('share', package_name, 'ui_modules'), glob('phd_master_machine/ui_modules/*.py')),

        (os.path.join('lib', package_name), glob('scripts/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rov1101-master',
    maintainer_email='rov1101-master@todo.todo',
    description='PHD_UVMS 综合控制界面',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'rqt_main = phd_master_machine.rqt_main:main',
            'thrusters_ctrl_interfaces = phd_master_machine.thrusters_ctrl_interfaces:main',
            'pose_sensor_interfaces = phd_master_machine.pose_sensor_interfaces:main',
        ],
    },
)
