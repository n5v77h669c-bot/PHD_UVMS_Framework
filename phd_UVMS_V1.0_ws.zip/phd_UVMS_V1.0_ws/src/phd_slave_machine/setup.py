from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'phd_slave_machine'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pyy',
    maintainer_email='pyy@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'imu_communication = phd_slave_machine.imu_communication:main',
            'depth_communication = phd_slave_machine.depth_communication:main',
            'mcu_propeller_controller = phd_slave_machine.mcu_propeller_controller:main',
            'mcu_sensor_sw_ctrl = phd_slave_machine.mcu_sensor_sw_ctrl:main',
        ],
    },
)
