#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
import socket
import threading
import select
import time
import numpy as np

from phd_master_slave_interfaces.msg import SensorStatus


class SensorSwitchController(Node):
    def __init__(self):
        super().__init__('mcu_sensor_sw_ctrl')
        
        # ==================== 参数配置 ====================
        self.declare_parameters(
            namespace='',
            parameters=[
                # 网络连接参数
                ('mcu_ip', '192.168.2.125'),
                ('mcu_port', 1008),
                # 频率控制
                ('publish_hz', 50.0),           # 状态发布频率
                ('send_hz', 20.0),              # 指令发送频率
                ('receive_hz', 50.0),           # 数据接收频率
                # 网络连接参数
                ('auto_reconnect', True),
                ('reconnect_delay', 1.0),
                ('max_reconnect_delay', 30.0),
            ]
        )
        
        # ==================== 参数加载 ====================
        # 网络参数
        self.mcu_ip = self.get_parameter('mcu_ip').value
        self.mcu_port = self.get_parameter('mcu_port').value
        # 频率参数
        self.publish_hz = self.get_parameter('publish_hz').value
        self.send_hz = self.get_parameter('send_hz').value
        self.receive_hz = self.get_parameter('receive_hz').value
        # 网络连接参数
        self.auto_reconnect = self.get_parameter('auto_reconnect').value
        self.reconnect_delay = self.get_parameter('reconnect_delay').value
        self.max_reconnect_delay = self.get_parameter('max_reconnect_delay').value
        
        # ==================== 数据存储 ====================
        # 传感器映射
        self.sensor_mapping = {
            # 发送映射：功能名称 -> 数据索引
            'send': {
                'front_sonar': 0,   # 前视声纳
                'light': 1,           # 灯
                'dvl': 2,             # DVL
                'scanning_sonar': 3,  # 环扫声纳
            },
            # 接收映射：数据索引 -> 功能名称
            'receive': {
                0: 'front_sonar',
                1: 'light',
                2: 'dvl',
                3: 'scanning_sonar',
            }
        }
        
        # 传感器状态 (0: 关闭, 1: 开启)
        self.set_status = {
            'front_sonar': 0,
            'light': 0,
            'dvl': 0,
            'scanning_sonar': 0,
        }
        
        self.cur_status = {
            'front_sonar': 0,
            'light': 0,
            'dvl': 0,
            'scanning_sonar': 0,
        }
        
        self.water_leak_status = 0  # 0: 未漏水, 1: 漏水
        
        # 上次发送的状态（用于检测变化）
        self.last_set_status = {
            'front_sonar': -1,
            'light': -1,
            'dvl': -1,
            'scanning_sonar': -1,
        }
        
        # 指令队列
        self.pending_command = None
        self.command_ready = False
        
        # 数据锁
        self.data_lock = threading.Lock()
        self.command_lock = threading.Lock()
        
        # 统计信息
        self.stats = {
            'packets_sent': 0,
            'packets_received': 0,
            'parse_errors': 0,
            'send_errors': 0,
            'last_stat_time': time.time(),
        }
        
        # 连接状态
        self.connected = False
        
        # ==================== QoS配置 ====================
        qos_profile = QoSProfile(
            depth=10,
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST
        )
        
        # ==================== 发布 订阅 ====================
        # 传感器状态发布器
        self.status_pub = self.create_publisher(
            SensorStatus,
            '/sw/sensor_sw_status',
            qos_profile
        )
        
        # 传感器指令订阅器
        self.sensor_cmd_sub = self.create_subscription(
            SensorStatus,
            '/masterMachine/sensor_sw_cmd',
            self.sensor_cmd_callback,
            qos_profile,
        )
        
        # ==================== 定时器 ====================
        # 状态发布定时器
        publish_interval = 1.0 / self.publish_hz
        self.publish_timer = self.create_timer(publish_interval, self._publish_status)
        
        # 指令发送定时器
        send_interval = 1.0 / self.send_hz
        self.send_timer = self.create_timer(send_interval, self._send_commands_timer)
        
        # ==================== 网络通信线程 ====================
        self.running = True
        self.sock = None
        self.receive_thread = threading.Thread(
            target=self._tcp_receiver_worker,
            daemon=True
        )
        self.receive_thread.start()
        
        # ==================== 启动日志 ====================
        self.get_logger().info("=" * 60)
        self.get_logger().info("传感器开关控制器启动")
        self.get_logger().info(f"连接地址: {self.mcu_ip}:{self.mcu_port}")
        self.get_logger().info(f"状态发布: {self.publish_hz}Hz")
        self.get_logger().info(f"指令发送: {self.send_hz}Hz")
        self.get_logger().info("传感器顺序: 前视声纳 灯 DVL 环扫声纳")
        self.get_logger().info("=" * 60)
    
    def _tcp_receiver_worker(self):
        """TCP接收线程"""
        buffer = bytearray()
        current_reconnect_delay = self.reconnect_delay
        
        while self.running and rclpy.ok():
            try:
                # 建立TCP连接
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.settimeout(5.0)
                self.get_logger().info(f"尝试连接到 {self.mcu_ip}:{self.mcu_port}...")
                self.sock.connect((self.mcu_ip, self.mcu_port))
                self.sock.settimeout(0.05)
                self.get_logger().info("传感器MCU连接成功")
                self.connected = True
                current_reconnect_delay = self.reconnect_delay
                buffer.clear()
                
                # 主接收循环
                while self.running and rclpy.ok():
                    try:
                        ready = select.select([self.sock], [], [], 0.01)
                        if not ready[0]:
                            continue
                        
                        data = self.sock.recv(1024)
                        if not data:
                            self.get_logger().warning("传感器连接断开")
                            self.connected = False
                            break
                        
                        buffer.extend(data)
                        self.stats['packets_received'] += 1
                        
                        # 解析数据包
                        while len(buffer) >= 8:  # 帧头(2) + 数据(4) + 漏水(1) + 帧尾(1) = 8字节
                            # 查找包头 AB 02
                            header_idx = -1
                            for i in range(len(buffer) - 1):
                                if buffer[i] == 0xAB and buffer[i+1] == 0x02:
                                    header_idx = i
                                    break
                            
                            if header_idx == -1:
                                # 没找到包头，清空缓冲区
                                buffer.clear()
                                break
                            
                            # 丢弃包头前的数据
                            if header_idx > 0:
                                buffer = buffer[header_idx:]
                            
                            # 检查是否有完整包 (8字节: 帧头2 + 数据4 + 漏水1 + 帧尾1)
                            if len(buffer) < 8:
                                break
                            
                            # 检查包尾
                            if buffer[7] != 0xFF:
                                # 包尾错误，移除第一个字节继续查找
                                buffer.pop(0)
                                continue
                            
                            # 提取完整数据包
                            packet = buffer[:8]
                            buffer = buffer[8:]
                            
                            # 解析数据包
                            self._parse_response_packet(packet)
                            
                    except socket.timeout:
                        continue
                    except Exception as e:
                        self.get_logger().warning(f"接收数据异常: {e}")
                        self.connected = False
                        break
                        
            except (socket.error, ConnectionRefusedError, TimeoutError) as e:
                self.connected = False
                if self.auto_reconnect:
                    self.get_logger().error(f"连接失败: {e}, {current_reconnect_delay:.1f}秒后重试")
                    time.sleep(current_reconnect_delay)
                    current_reconnect_delay = min(
                        current_reconnect_delay * 1.5,
                        self.max_reconnect_delay
                    )
                    continue
                else:
                    self.get_logger().error(f"连接失败: {e}")
                    break
                    
            except Exception as e:
                self.connected = False
                self.get_logger().error(f"未知错误: {e}")
                time.sleep(5)
                
            finally:
                if self.sock:
                    try:
                        self.sock.close()
                    except:
                        pass
                    self.sock = None
                if self.running and self.auto_reconnect:
                    time.sleep(current_reconnect_delay)
    
    def _parse_response_packet(self, packet):
        """解析MCU返回的数据包 (AB 02 d1 d2 d3 d4 leak FF)"""
        try:
            if len(packet) != 8:
                return
            
            # 提取4个传感器的状态
            # packet[2] - 前视声纳状态
            # packet[3] - 灯状态
            # packet[4] - DVL状态
            # packet[5] - 环扫声纳状态
            sensor_statuses = list(packet[2:6])
            leak_status = packet[6]
            
            with self.data_lock:
                # 更新当前状态
                for idx, value in enumerate(sensor_statuses):
                    if idx in self.sensor_mapping['receive']:
                        name = self.sensor_mapping['receive'][idx]
                        self.cur_status[name] = 1 if value > 0 else 0
                
                # 更新漏水状态
                self.water_leak_status = 1 if leak_status > 0 else 0
            
            # 调试输出（降低频率）
            if self.stats['packets_received'] % 50 == 0:
                self.get_logger().debug(
                    f"传感器状态: 前视声纳={sensor_statuses[0]}, "
                    f"灯={sensor_statuses[1]}, "
                    f"DVL={sensor_statuses[2]}, "
                    f"环扫声纳={sensor_statuses[3]}, "
                    f"漏水={leak_status}",
                    throttle_duration_sec=1.0
                )
            
        except Exception as e:
            self.stats['parse_errors'] += 1
            self.get_logger().warning(f"解析数据包失败: {e}")
    
    def sensor_cmd_callback(self, msg):
        """传感器指令回调"""
        if not self.connected:
            return
        
        try:
            with self.command_lock:
                # 更新设置状态
                self.set_status['front_sonar'] = 1 if msg.front_sonar_set_status > 0 else 0
                self.set_status['light'] = 1 if msg.light_set_status > 0 else 0
                self.set_status['dvl'] = 1 if msg.dvl_set_status > 0 else 0
                self.set_status['scanning_sonar'] = 1 if msg.scanning_sonar_set_status > 0 else 0
                
                self.command_ready = True
                
        except Exception as e:
            self.stats['send_errors'] += 1
            self.get_logger().error(f"处理传感器指令失败: {e}")
    
    def _send_commands_timer(self):
        """定时发送指令"""
        if not self.connected or not self.sock:
            return
        
        # 检查是否有命令需要发送
        with self.command_lock:
            if not self.command_ready:
                return
        
        try:
            # 检查状态是否有变化
            status_changed = False
            for name in self.set_status.keys():
                if self.set_status[name] != self.last_set_status[name]:
                    status_changed = True
                    break
            
            if status_changed:
                # 构建数据包
                packet = bytearray()
                packet.append(0xAA)  # 帧头
                packet.append(0x02)  # 设备ID
                
                # 添加4个传感器状态
                for name in ['front_sonar', 'light', 'dvl', 'scanning_sonar']:
                    packet.append(self.set_status[name])
                
                # 添加漏水状态（0x00，只读不写）
                packet.append(0x00)
                
                packet.append(0xFF)  # 帧尾
                
                # 发送数据
                self.sock.sendall(packet)
                self.stats['packets_sent'] += 1
                
                # 保存当前设置值
                self.last_set_status = self.set_status.copy()
                
                # 调试输出
                self.get_logger().debug(
                    f"发送传感器指令: "
                    f"前视声纳={self.set_status['front_sonar']}, "
                    f"灯={self.set_status['light']}, "
                    f"DVL={self.set_status['dvl']}, "
                    f"环扫声纳={self.set_status['scanning_sonar']}",
                    throttle_duration_sec=1.0
                )
                
        except Exception as e:
            self.stats['send_errors'] += 1
            self.get_logger().error(f"发送传感器指令失败: {e}")
            self.sock = None
            self.connected = False
    
    def _publish_status(self):
        """发布传感器状态"""
        if not self.connected:
            return
        
        try:
            with self.data_lock:
                status_msg = SensorStatus()
                status_msg.timestamp = self.get_clock().now().to_msg()
                
                # 设置状态（来自上位机）
                status_msg.front_sonar_set_status = self.set_status['front_sonar']
                status_msg.light_set_status = self.set_status['light']
                status_msg.dvl_set_status = self.set_status['dvl']
                status_msg.scanning_sonar_set_status = self.set_status['scanning_sonar']
                
                # 当前状态（来自MCU）
                status_msg.front_sonar_cur_status = self.cur_status['front_sonar']
                status_msg.light_cur_status = self.cur_status['light']
                status_msg.dvl_cur_status = self.cur_status['dvl']
                status_msg.scanning_sonar_cur_status = self.cur_status['scanning_sonar']
                
                # 漏水状态
                status_msg.water_leak_status = self.water_leak_status
                
                # 数据有效性
                status_msg.data_valid = True
                
                # 发布
                self.status_pub.publish(status_msg)
                
        except Exception as e:
            self.get_logger().error(f"发布传感器状态失败: {e}")
    
    def _print_statistics(self):
        """输出统计信息"""
        if not self.connected:
            self.get_logger().info("等待传感器MCU连接...")
            return
            
        current_time = time.time()
        interval = current_time - self.stats['last_stat_time']
        
        if interval > 0:
            send_rate = self.stats['packets_sent'] / interval
            receive_rate = self.stats['packets_received'] / interval
            
            with self.data_lock:
                status_str = ", ".join(
                    f"{name}={status}" for name, status in self.cur_status.items()
                )
            
            self.get_logger().info(
                f"传感器统计: "
                f"发送={send_rate:.1f}Hz ({self.stats['packets_sent']}) | "
                f"接收={receive_rate:.1f}Hz ({self.stats['packets_received']}) | "
                f"错误={self.stats['parse_errors']}/{self.stats['send_errors']} | "
                f"状态: {status_str} | "
                f"漏水={self.water_leak_status}"
            )
            
            # 重置统计
            self.stats['packets_sent'] = 0
            self.stats['packets_received'] = 0
            self.stats['parse_errors'] = 0
            self.stats['send_errors'] = 0
            self.stats['last_stat_time'] = current_time
    
    def destroy_node(self):
        """清理资源"""
        self.get_logger().info("关闭传感器开关控制器...")
        self.running = False
        self.connected = False
        
        # 发送关闭指令
        if self.sock:
            try:
                # 关闭所有传感器
                stop_packet = bytes([0xAA, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF])
                self.sock.sendall(stop_packet)
                time.sleep(0.1)
            except:
                pass
        
        # 等待线程结束
        if hasattr(self, 'receive_thread') and self.receive_thread.is_alive():
            self.receive_thread.join(timeout=2.0)
        
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    
    node = None
    try:
        node = SensorSwitchController()
        rclpy.spin(node)
    except KeyboardInterrupt:
        if node:
            node.get_logger().info("用户中断")
    except Exception as e:
        if node:
            node.get_logger().error(f"节点崩溃: {e}")
        else:
            print(f"节点启动失败: {e}")
    finally:
        if node:
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()