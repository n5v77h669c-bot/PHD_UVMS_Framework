#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
import socket
import threading
import select
import time
import numpy as np

from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, Vector3
from std_msgs.msg import Header
from phd_master_slave_interfaces.msg import Depth

class DepthSensorPublisher(Node):
    def __init__(self):
        super().__init__('depth_communication')
        
        # ==================== 参数配置 ====================
        self.declare_parameters(
            namespace='',
            parameters=[
                ('server_ip', '192.168.2.125'),
                ('server_port', 1005),
                ('publish_hz', 50.0),           # 发布频率
                ('receive_hz', 100.0),          # 接收频率
                ('frame_id', 'depth_link'),
                ('child_frame_id', 'base_link'),
                ('depth_offset', 0.0),          # 深度偏移校准
                ('max_depth', 500.0),           # 最大深度限制
                ('buffer_size', 5),             # 滤波缓冲区大小
                ('auto_reconnect', True),       # 是否自动重连
                ('reconnect_delay', 1.0),       # 重连延迟
                ('max_reconnect_delay', 30.0),  # 最大重连延迟
            ]
        )
        
        self.server_ip = self.get_parameter('server_ip').value
        self.server_port = self.get_parameter('server_port').value
        self.publish_hz = self.get_parameter('publish_hz').value
        self.receive_hz = self.get_parameter('receive_hz').value
        self.depth_offset = self.get_parameter('depth_offset').value
        self.max_depth = self.get_parameter('max_depth').value
        self.buffer_size = self.get_parameter('buffer_size').value
        self.auto_reconnect = self.get_parameter('auto_reconnect').value
        self.reconnect_delay = self.get_parameter('reconnect_delay').value
        self.max_reconnect_delay = self.get_parameter('max_reconnect_delay').value
        
        # 数据缓存
        self.depth_data = None
        self.latest_depth = None
        self.latest_temperature = None
        self.latest_timestamp = None
        self.data_lock = threading.Lock()
        
        # 频率控制
        self.process_interval = 1.0 / self.receive_hz if self.receive_hz > 0 else 0
        self.next_process_time = 0
        
        # 统计信息
        self.received_count = 0
        self.processed_count = 0
        self.dropped_count = 0
        self.last_stat_time = time.time()
        
        # 深度滤波
        self.depth_buffer = []
        
        # QoS配置
        qos_profile = QoSProfile(
            depth=50,  # 较大的缓冲区
            reliability=QoSReliabilityPolicy.BEST_EFFORT,  # 允许丢包
            history=QoSHistoryPolicy.KEEP_LAST,  # 修正：应该是 KEEP_LAST
            durability=QoSDurabilityPolicy.VOLATILE  # 修正：使用 QoSDurabilityPolicy
        )
        
        # 发布器
        self.depth_pub = self.create_publisher(
            Depth, 
            '/depth_data', 
            qos_profile
            )
        
        # 启动接收线程
        self.running = True
        self.receive_thread = threading.Thread(
            target=self._tcp_receiver_worker,
            daemon=True
        )
        self.receive_thread.start()
        
        # 定时发布器
        publish_interval = 1.0 / self.publish_hz
        self.publish_timer = self.create_timer(publish_interval, self._publish_latest_data)
        
        # 统计定时器（可选）
        # self.stat_timer = self.create_timer(5.0, self._update_statistics)
        
        self.get_logger().info("=" * 60)
        self.get_logger().info(f"深度计发布器启动")
        self.get_logger().info(f"连接: {self.server_ip}:{self.server_port}")
        self.get_logger().info(f"接收频率: {self.receive_hz}Hz")
        self.get_logger().info(f"发布频率: {self.publish_hz}Hz")
        self.get_logger().info("=" * 60)
    
    def _tcp_receiver_worker(self):
        """TCP接收线程"""
        buffer = ""
        sock = None
        current_reconnect_delay = self.reconnect_delay
        
        while self.running and rclpy.ok():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                self.get_logger().info(f"尝试连接到 {self.server_ip}:{self.server_port}...")
                sock.connect((self.server_ip, self.server_port))
                sock.settimeout(0.05)
                
                self.get_logger().info("深度计TCP连接成功")
                current_reconnect_delay = self.reconnect_delay
                buffer = ""
                
                while self.running and rclpy.ok():
                    try:
                        ready = select.select([sock], [], [], 0.01)
                        if not ready[0]:
                            continue
                        
                        data = sock.recv(1024)
                        if not data:
                            self.get_logger().warning("连接断开")
                            break
                        
                        buffer += data.decode('ascii', errors='ignore')
                        self.received_count += 1
                        
                        # 处理完整数据行
                        lines = []
                        while '\n' in buffer or '\r' in buffer:
                            if '\n' in buffer:
                                line, buffer = buffer.split('\n', 1)
                            elif '\r' in buffer:
                                line, buffer = buffer.split('\r', 1)
                            else:
                                break
                            
                            line = line.strip()
                            if line:
                                lines.append(line)
                        
                        # 处理所有行
                        for line in lines:
                            if self._should_process_line():
                                depth_msg = self._parse_and_update(line)
                                if depth_msg:
                                    with self.data_lock:
                                        self.depth_data = depth_msg
                                    self.processed_count += 1
                                else:
                                    self.dropped_count += 1
                            else:
                                self.dropped_count += 1
                                
                    except socket.timeout:
                        continue
                    except Exception as e:
                        self.get_logger().warning(f"接收数据异常: {e}")
                        break
                        
            except (socket.error, ConnectionRefusedError, TimeoutError) as e:
                if self.auto_reconnect:
                    self.get_logger().error(f"连接失败: {e}, {current_reconnect_delay:.1f}秒后重试")
                    time.sleep(current_reconnect_delay)
                    current_reconnect_delay = min(current_reconnect_delay * 1.5, self.max_reconnect_delay)
                    continue
                else:
                    self.get_logger().error(f"连接失败: {e}")
                    break
                
            except Exception as e:
                self.get_logger().error(f"未知错误: {e}")
                time.sleep(5)
                
            finally:
                if sock:
                    try:
                        sock.close()
                    except:
                        pass
                    sock = None
                
                if self.running and self.auto_reconnect:
                    time.sleep(current_reconnect_delay)
                elif self.running:
                    self.get_logger().info("自动重连已禁用，节点将退出")
                    self.running = False
    
    def _should_process_line(self):
        """决定是否处理当前数据行"""
        if self.process_interval <= 0:
            return True
        
        current_time = time.time()
        if current_time < self.next_process_time:
            return False
        
        self.next_process_time = current_time + self.process_interval
        return True
    
    def _parse_and_update(self, line):
        """解析深度计数据并更新状态"""
        try:
            t_pos = line.find('T=')
            d_pos = line.find('D=')
            
            if t_pos == -1 or d_pos == -1:
                self.get_logger().debug(f"无效数据格式: {line}")
                return None
            
            temp_str = line[t_pos+2:d_pos].strip()
            depth_str = line[d_pos+2:].strip()

            temperature = float(temp_str)
            depth_meters = float(depth_str)
            
            depth_calibrated = depth_meters + self.depth_offset
            
            if abs(depth_calibrated) > self.max_depth:
                self.get_logger().warning(f"深度超出范围: {depth_calibrated}m")
                depth_calibrated = np.sign(depth_calibrated) * self.max_depth
            
            # 滤波
            self.depth_buffer.append(depth_calibrated)
            if len(self.depth_buffer) > self.buffer_size:
                self.depth_buffer.pop(0)
            
            filtered_depth = sum(self.depth_buffer) / len(self.depth_buffer)

            # 创建消息对象
            depth_msg = Depth()
            depth_msg.depth = filtered_depth
            depth_msg.temp_water = temperature
            depth_msg.timestamp = self.get_clock().now().to_msg()
            
            # 更新缓存
            with self.data_lock:
                self.latest_depth = filtered_depth
                self.latest_temperature = temperature
                self.latest_timestamp = self.get_clock().now()
            
            return depth_msg
            
        except ValueError as e:
            self.get_logger().warning(f"深度数据解析失败: {line}, 错误: {e}")
            return None
        except Exception as e:
            self.get_logger().error(f"处理深度数据时出错: {e}")
            return None
    
    def _update_statistics(self):
        """更新和输出统计信息"""
        current_time = time.time()
        time_interval = current_time - self.last_stat_time
        
        if time_interval > 0:
            receive_rate = self.received_count / time_interval
            process_rate = self.processed_count / time_interval
            drop_rate = self.dropped_count / time_interval
            
            self.get_logger().info(
                f"深度计统计: "
                f"接收={receive_rate:.1f}Hz "
                f"处理={process_rate:.1f}Hz "
                f"丢弃={drop_rate:.1f}Hz "
                f"缓冲区={len(self.depth_buffer)}/{self.buffer_size}"
            )
            
            self.received_count = 0
            self.processed_count = 0
            self.dropped_count = 0
            self.last_stat_time = current_time
    
    def _publish_latest_data(self):
        """发布最新深度数据"""
        if self.depth_data is None:
            return
        
        try:
            # 更新时间戳
            self.depth_data.timestamp = self.get_clock().now().to_msg()
            self.depth_pub.publish(self.depth_data)
            
            # self.get_logger().info(
            #     f"深度: {self.depth_data.depth:.3f}m | 水温: {self.depth_data.temp_water:.2f}°C",
            #     throttle_duration_sec=2.0
            # )
            
        except Exception as e:
            self.get_logger().error(f"发布深度数据失败: {e}")
    
    def destroy_node(self):
        """清理资源"""
        self.get_logger().info("关闭深度计节点...")
        self.running = False
        
        if hasattr(self, 'receive_thread') and self.receive_thread.is_alive():
            self.receive_thread.join(timeout=2.0)
        
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = DepthSensorPublisher()
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("用户中断")
    except Exception as e:
        node.get_logger().error(f"节点崩溃: {e}")
    finally:
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()