#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
import socket
import threading
import select
import time
import math
import numpy as np

from geometry_msgs.msg import Quaternion, Vector3
from std_msgs.msg import Header
from scipy.spatial.transform import Rotation as R
from phd_master_slave_interfaces.msg import MtiImu

class IMUQuaternionPublisher(Node):
    def __init__(self):
        super().__init__('imu_communication')
        # ==================== 参数配置 ====================
        self.declare_parameters(
            namespace='',
            parameters=[
                ('server_ip', '192.168.2.125'),
                ('server_port', 1003),
                ('publish_hz', 50.0),           # 发布频率
                ('receive_hz', 100.0),          # 接收频率
                ('data_format', 'psoncms'),     # 数据格式: 'prdid' 或 'psoncms'
                ('frame_id', 'imu_link'),
                ('enable_statistics', True),    # 是否输出统计信息
                ('auto_reconnect', True),       # 是否自动重连
                ('reconnect_delay', 1.0),       # 重连延迟
                ('max_reconnect_delay', 30.0),  # 最大重连延迟

                ('enable_integration', True),   # 是否启用积分
                ('max_velocity', 50.0),                   # 最大速度限制 (m/s)
                ('velocity_leak_rate', 0.999),           # 速度泄漏率 (0.999 ≈ 每秒衰减0.1%)
                ('position_leak_rate', 0.9999),          # 位置泄漏率
                ('zero_velocity_threshold', 0.05),       # 零速检测阈值 (m/s²)
                ('zero_velocity_timeout', 1.0),          # 零速持续时间 (秒)
            
            ]
        )
        self.server_ip = self.get_parameter('server_ip').value
        self.server_port = self.get_parameter('server_port').value
        self.publish_hz = self.get_parameter('publish_hz').value
        self.target_receive_hz = self.get_parameter('receive_hz').value
        self.data_format = self.get_parameter('data_format').value
        self.frame_id = self.get_parameter('frame_id').value
        self.enable_statistics = self.get_parameter('enable_statistics').value
        self.auto_reconnect = self.get_parameter('auto_reconnect').value
        self.reconnect_delay = self.get_parameter('reconnect_delay').value
        self.max_reconnect_delay = self.get_parameter('max_reconnect_delay').value

        self.enable_integration = self.get_parameter('enable_integration').value
        self.max_velocity = self.get_parameter('max_velocity').value
        self.velocity_leak_rate = self.get_parameter('velocity_leak_rate').value
        self.position_leak_rate = self.get_parameter('position_leak_rate').value
        self.zero_velocity_threshold = self.get_parameter('zero_velocity_threshold').value
        self.zero_velocity_timeout = self.get_parameter('zero_velocity_timeout').value

        # 数据缓存
        self.latest_imu_data = None
        self.latest_quaternion = None
        self.latest_timestamp = None
        self.data_lock = threading.Lock()
        # 接收频率控制
        self.receive_interval = 1.0 / self.target_receive_hz if self.target_receive_hz > 0 else 0
        self.last_receive_time = time.time()

        # 速度积分 (m/s)
        self.integrated_velocity = {'x': 0.0, 'y': 0.0, 'z': 0.0}
        # 位置积分 (m)
        self.integrated_position = {'x': 0.0, 'y': 0.0, 'z': 0.0}
        # 上一次加速度积分的时间
        self.last_accel_time = self.get_clock().now()
        # 零速检测计数器
        self.zero_velocity_counter = 0
        self.zero_velocity_triggered = False
        # 上一次的姿态角（用于去除重力）
        self.last_roll = 0.0
        self.last_pitch = 0.0
        
        # 统计信息
        self.stats = {
            'total_received': 0,
            'valid_parsed': 0,
            'prdid_count': 0,
            'psoncms_count': 0,
            'invalid_count': 0,
            'last_stat_time': time.time(),
            'last_publish_time': time.time(),
        }
        
        # QoS配置
        qos_profile = QoSProfile(
            depth=50,  # 较大的缓冲区
            reliability=QoSReliabilityPolicy.BEST_EFFORT,  # 允许丢包
            history=QoSHistoryPolicy.KEEP_LAST,  # 修正：应该是 KEEP_LAST
            durability=QoSDurabilityPolicy.VOLATILE  # 修正：使用 QoSDurabilityPolicy
        )
        # ==================== 创建发布器 ====================
        # 发布完整的IMU数据
        self.imu_pub = self.create_publisher(
            MtiImu,
            '/imu_data',
            qos_profile
        )
        # ==================== 启动TCP接收线程 ====================
        self.running = True
        self.receive_thread = threading.Thread(
            target=self._tcp_receiver_worker,
            daemon=True
        )
        self.receive_thread.start()
        # ==================== 定时发布器 ====================
        publish_interval = 1.0 / self.publish_hz
        self.publish_timer = self.create_timer(
            publish_interval,
            self._publish_latest_data
        )
        # ==================== 统计信息定时器 ====================
        # if self.enable_statistics:
        #     self.stat_timer = self.create_timer(
        #         5.0,  # 每5秒输出一次统计信息
        #         self._print_statistics
        #     )
        self.get_logger().info("=" * 60)
        self.get_logger().info("MTI IMU 四元数发布器启动")
        self.get_logger().info(f"连接地址: {self.server_ip}:{self.server_port}")
        self.get_logger().info(f"数据格式: {self.data_format.upper()}")
        self.get_logger().info(f"接收频率: {self.target_receive_hz}Hz")
        self.get_logger().info(f"发布频率: {self.publish_hz}Hz")
        self.get_logger().info(f"发布话题: /imu_data")
        self.get_logger().info(f"位置速度积分: {'启用' if self.enable_integration else '禁用'}")
        self.get_logger().info("=" * 60)
    
    def _tcp_receiver_worker(self):
        """TCP接收线程 - 支持自动重连"""
        buffer = ""
        current_reconnect_delay = self.reconnect_delay
        
        while self.running and rclpy.ok():
            try:
                # 建立TCP连接
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)  # 连接超时
                self.get_logger().info(f"尝试连接到 {self.server_ip}:{self.server_port}...")
                sock.connect((self.server_ip, self.server_port))
                sock.settimeout(0.05)  # 接收超时设为50ms
                self.get_logger().info("IMU_TCP连接成功")
                current_reconnect_delay = self.reconnect_delay  # 重置重连延迟
                buffer = ""  # 清空缓冲区
                # 主接收循环
                while self.running and rclpy.ok():
                    try:
                        # 非阻塞检查数据
                        ready = select.select([sock], [], [], 0.01)
                        if not ready[0]:
                            continue
                        # 接收数据
                        data = sock.recv(4096)
                        if not data:
                            self.get_logger().warning("连接断开")
                        # 解码并添加到缓冲区
                        buffer += data.decode('ascii', errors='ignore')
                        self.stats['total_received'] += 1
                        # 处理所有完整的数据行
                        while '\n' in buffer:
                            line, buffer = buffer.split('\n', 1)
                            self._process_data_line(line.strip())
                    except socket.timeout:
                        continue  # 正常超时，继续循环
                    except Exception as e:
                        self.get_logger().warning(f"接收数据异常: {e}")
                        break
                        
            except (socket.error, ConnectionRefusedError, TimeoutError) as e:
                if self.auto_reconnect:
                    self.get_logger().error(f"连接失败: {e}, {current_reconnect_delay:.1f}秒后重试")
                    time.sleep(current_reconnect_delay)
                    current_reconnect_delay = min(
                        current_reconnect_delay * 1.5, 
                        self.max_reconnect_delay
                    )  # 指数退避
                    continue
                else:
                    self.get_logger().error(f"连接失败: {e}")
                    break
                    
            except Exception as e:
                self.get_logger().error(f"未知错误: {e}")
                time.sleep(5)
                
            finally:
                # 清理socket
                try:
                    sock.close()
                except:
                    pass
                
                # 如果不是主动停止，且需要重连，则等待后继续
                if self.running and self.auto_reconnect:
                    time.sleep(current_reconnect_delay)
                elif self.running:
                    self.get_logger().info("自动重连已禁用，节点将退出")
                    self.running = False

    # ========== 新增：从加速度去除重力分量 ==========
    def remove_gravity_from_accel(self, accel_x, accel_y, accel_z, roll_deg, pitch_deg):
        """
        从加速度计数据中去除重力分量
        返回：去除重力后的线性加速度 (m/s²)
        """
        g = 9.81
        roll_rad = math.radians(roll_deg)
        pitch_rad = math.radians(pitch_deg)
        
        # 重力在机体坐标系的分量
        # 当机体旋转时，重力向量会被投影到各轴上
        gravity_x = -g * math.sin(pitch_rad)
        gravity_y = g * math.sin(roll_rad) * math.cos(pitch_rad)
        gravity_z = g * math.cos(roll_rad) * math.cos(pitch_rad)
        
        # 去除重力
        linear_accel_x = accel_x - gravity_x
        linear_accel_y = accel_y - gravity_y
        linear_accel_z = accel_z - gravity_z
        
        return linear_accel_x, linear_accel_y, linear_accel_z
    
    # ========== 新增：速度/位置积分更新 ==========
    def update_integration(self, linear_accel_x, linear_accel_y, linear_accel_z):
        """
        更新速度和位置积分
        """
        current_time = self.get_clock().now()
        dt = (current_time - self.last_accel_time).nanoseconds / 1e9
        
        # 限制dt范围，防止异常
        if dt <= 0 or dt > 0.1:
            dt = 0.01
            self.last_accel_time = current_time
            return
        
        # 计算加速度幅值，用于零速检测
        accel_magnitude = math.sqrt(
            linear_accel_x**2 + 
            linear_accel_y**2 + 
            linear_accel_z**2
        )
        
        # 零速检测
        if accel_magnitude < self.zero_velocity_threshold:
            self.zero_velocity_counter += 1
        else:
            self.zero_velocity_counter = 0
        
        # 判断是否为零速状态
        zero_velocity = (self.zero_velocity_counter > self.zero_velocity_timeout * self.publish_hz)
        
        if self.enable_integration:
            # 速度积分：v = v + a * dt
            self.integrated_velocity['x'] += linear_accel_x * dt
            self.integrated_velocity['y'] += linear_accel_y * dt
            self.integrated_velocity['z'] += linear_accel_z * dt
            
            # 零速修正：逐渐减小速度
            if zero_velocity and not self.zero_velocity_triggered:
                self.get_logger().info("零速检测触发，速度将逐渐衰减")
                self.zero_velocity_triggered = True
            elif not zero_velocity:
                self.zero_velocity_triggered = False
            
            # 应用泄漏率（防止长时间积分漂移）
            self.integrated_velocity['x'] *= self.velocity_leak_rate
            self.integrated_velocity['y'] *= self.velocity_leak_rate
            self.integrated_velocity['z'] *= self.velocity_leak_rate
            
            # 速度限幅
            self.integrated_velocity['x'] = max(-self.max_velocity, 
                                                 min(self.max_velocity, 
                                                     self.integrated_velocity['x']))
            self.integrated_velocity['y'] = max(-self.max_velocity, 
                                                 min(self.max_velocity, 
                                                     self.integrated_velocity['y']))
            self.integrated_velocity['z'] = max(-self.max_velocity, 
                                                 min(self.max_velocity, 
                                                     self.integrated_velocity['z']))
        
        if self.enable_integration:
            # 位置积分：p = p + v * dt
            self.integrated_position['x'] += self.integrated_velocity['x'] * dt
            self.integrated_position['y'] += self.integrated_velocity['y'] * dt
            self.integrated_position['z'] += self.integrated_velocity['z'] * dt
            
            # 应用泄漏率
            self.integrated_position['x'] *= self.position_leak_rate
            self.integrated_position['y'] *= self.position_leak_rate
            self.integrated_position['z'] *= self.position_leak_rate
        
        
        # 更新时间戳
        self.last_accel_time = current_time
    
    def _parse_psoncms_data(self, line):
        """解析PSONCMS格式数据: $PSONCMS,q0,q1,q2,q3,accel_x,accel_y,accel_z,gyro_x,gyro_y,gyro_z,mag_x,mag_y,mag_z,temp*checksum"""
        try:
            parts = line.split(',')
            # 验证数据长度
            if len(parts) < 14:
                self.get_logger().warning(f"数据字段错误: {len(parts)}个")
                return None
            # 解析四元数 (w, x, y, z)
            q0 = float(parts[1])   # w
            q1 = float(parts[2])   # x
            q2 = float(parts[3])   # y
            q3 = float(parts[4])   # z
            # 验证四元数是否合法
            norm = math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3)
            if abs(norm - 1.0) > 0.1:
                self.get_logger().warning(f"四元数未归一化: norm={norm:.4f}")
                if norm > 0:
                    q0 /= norm
                    q1 /= norm
                    q2 /= norm
                    q3 /= norm
            # 解析加速度 (m/s²)
            accel_x = float(parts[5])
            accel_y = float(parts[6])
            accel_z = float(parts[7])
            # 解析角速度 (rad/s)
            gyro_x = float(parts[8])
            gyro_y = float(parts[9])
            gyro_z = float(parts[10])
            # 解析磁场 (a.u.)
            mag_x = float(parts[11])
            mag_y = float(parts[12])
            mag_z = float(parts[13])
            temp_data = parts[14].split('*')
            temp = float(temp_data[0])
            # 从四元数计算欧拉角
            try:
                rotation = R.from_quat([q1, q2, q3, q0])
                euler_rad = rotation.as_euler('xyz', degrees=False)
                roll_deg = math.degrees(euler_rad[0])
                pitch_deg = math.degrees(euler_rad[1])
                yaw_deg = math.degrees(euler_rad[2])
                if yaw_deg < 0:
                    yaw_deg += 360.0
                elif yaw_deg >= 360:
                    yaw_deg -= 360.0
                    
            except Exception as e:
                self.get_logger().warning(f"欧拉角计算失败: {e}")
                roll_deg, pitch_deg, yaw_deg = 0.0, 0.0, 0.0

            # 去除重力分量
            linear_accel_x, linear_accel_y, linear_accel_z = self.remove_gravity_from_accel(
                accel_x, accel_y, accel_z, roll_deg, pitch_deg
            )
            # 更新速度和位置积分
            self.update_integration(linear_accel_x, linear_accel_y, linear_accel_z)
            
            # 创建IMU消息
            imu_msg = MtiImu()
            imu_msg.roll = roll_deg
            imu_msg.pitch = pitch_deg
            imu_msg.yaw = yaw_deg
            imu_msg.q0 = q0
            imu_msg.q1 = q1
            imu_msg.q2 = q2
            imu_msg.q3 = q3 
            imu_msg.accel_x = accel_x
            imu_msg.accel_y = accel_y
            imu_msg.accel_z = accel_z
            imu_msg.gyro_x = gyro_x
            imu_msg.gyro_y = gyro_y
            imu_msg.gyro_z = gyro_z
            imu_msg.mag_x = mag_x
            imu_msg.mag_y = mag_y
            imu_msg.mag_z = mag_z
            imu_msg.temp_imu = temp

            imu_msg.vel_x = self.integrated_velocity['x']
            imu_msg.vel_y = self.integrated_velocity['y']
            imu_msg.vel_z = self.integrated_velocity['z']
            imu_msg.pos_x = self.integrated_position['x']
            imu_msg.pos_y = self.integrated_position['y']
            imu_msg.pos_z = self.integrated_position['z']
            
            now = self.get_clock().now()
            imu_msg.timestamp = now.to_msg()
            imu_msg.data_source = 1
            imu_msg.data_valid = True
            self.stats['psoncms_count'] += 1
            self.stats['valid_parsed'] += 1
            return imu_msg, roll_deg, pitch_deg, yaw_deg
            
        except ValueError as e:
            self.stats['invalid_count'] += 1
            self.get_logger().info(f"数据解析错误: {e}")
            return None, 0, 0, 0
        except Exception as e:
            self.stats['invalid_count'] += 1
            self.get_logger().warning(f"解析PSONCMS数据失败: {e}")
            return None, 0, 0, 0
    
    def _parse_prdid_data(self, parts):
        """解析PRDID格式数据"""
        try:
            if len(parts) < 4:
                return None, 0, 0, 0
            
            roll = float(parts[1])
            pitch = float(parts[2])
            yaw = float(parts[3])
            
            roll_rad = math.radians(roll)
            pitch_rad = math.radians(pitch)
            yaw_rad = math.radians(yaw)
            
            rotation = R.from_euler('xyz', [roll_rad, pitch_rad, yaw_rad])
            quat = rotation.as_quat()
            
            imu_msg = MtiImu()
            
            imu_msg.roll = roll
            imu_msg.pitch = pitch
            imu_msg.yaw = yaw
            
            imu_msg.q0 = quat[3]
            imu_msg.q1 = quat[0]
            imu_msg.q2 = quat[1]
            imu_msg.q3 = quat[2]
            
            imu_msg.accel_x = 0.0
            imu_msg.accel_y = 0.0
            imu_msg.accel_z = 0.0
            
            imu_msg.gyro_x = 0.0
            imu_msg.gyro_y = 0.0
            imu_msg.gyro_z = 0.0
            
            imu_msg.mag_x = 0.0
            imu_msg.mag_y = 0.0
            imu_msg.mag_z = 0.0
            
            imu_msg.temp_imu = 25.0
            
            now = self.get_clock().now()
            imu_msg.timestamp = now.to_msg()
            
            imu_msg.data_source = 0
            imu_msg.data_valid = True
            
            self.stats['prdid_count'] += 1
            self.stats['valid_parsed'] += 1
            
            return imu_msg, roll, pitch, yaw
            
        except Exception as e:
            self.stats['invalid_count'] += 1
            self.get_logger().warning(f"解析PRDID数据失败: {e}")
            return None, 0, 0, 0
        
        
    
    def _process_data_line(self, line):
        """处理单行IMU数据"""
        current_time = time.time()
        if current_time - self.last_receive_time < self.receive_interval:
            return
        
        self.last_receive_time = current_time
        imu_msg = None
        roll, pitch, yaw = 0, 0, 0
        if self.data_format.lower() == 'prdid' and line.startswith('$PRDID'):
            imu_msg, roll, pitch, yaw = self._parse_prdid_data(line.split(','))
        elif self.data_format.lower() == 'psoncms' and line.startswith('$PSONCMS'):
            imu_msg, roll, pitch, yaw = self._parse_psoncms_data(line)
        else:
            self.stats['invalid_count'] += 1
            return
        
        if imu_msg is not None and imu_msg.data_valid:
            with self.data_lock:
                self.latest_imu_data = imu_msg
                self.latest_timestamp = self.get_clock().now()
                # self.get_logger().info(
                #     f"解析数据: R={roll:.1f}°, P={pitch:.1f}°, Y={yaw:.1f}°, "
                #     f"Acc=({imu_msg.accel_x:.3f},{imu_msg.accel_y:.3f},{imu_msg.accel_z:.3f})m/s²"
                # )
    
    def _publish_latest_data(self):
        """发布最新数据"""
        with self.data_lock:
            if self.latest_imu_data is None:
                return
            imu_data = self.latest_imu_data
            timestamp = self.latest_timestamp
        try:
            imu_data.timestamp = timestamp.to_msg()
            self.imu_pub.publish(imu_data)
            current_time = time.time()
            self.stats['last_publish_time'] = current_time
            # self.get_logger().info(
            #     f"发布IMU数据: R={imu_data.roll:.1f}°, P={imu_data.pitch:.1f}°, Y={imu_data.yaw:.1f}°, "
            #     f"温度: {imu_data.temp_imu:.1f}°C"
            # )
        except Exception as e:
            self.get_logger().error(f"发布数据失败: {e}")
    
    def _print_statistics(self):
        """输出统计信息"""
        if not self.enable_statistics:
            return
        
        current_time = time.time()
        interval = current_time - self.stats['last_stat_time']
        
        if interval > 0:
            total_rate = self.stats['total_received'] / interval
            valid_rate = self.stats['valid_parsed'] / interval
            publish_age = current_time - self.stats['last_publish_time']
            
            self.get_logger().info(
                f"IMU统计信息: 接收速率={total_rate:.1f}Hz, 解析速率={valid_rate:.1f}Hz, "
                f"最后发布时间={publish_age:.3f}秒前"
            )
            
            self.stats['total_received'] = 0
            self.stats['valid_parsed'] = 0
            self.stats['prdid_count'] = 0
            self.stats['psoncms_count'] = 0
            self.stats['invalid_count'] = 0
            self.stats['last_stat_time'] = current_time
    
    def destroy_node(self):
        """清理资源"""
        self.get_logger().info("正在关闭IMU四元数发布器...")
        self.running = False
        
        if hasattr(self, 'receive_thread') and self.receive_thread.is_alive():
            self.receive_thread.join(timeout=2.0)
            self.get_logger().info("接收线程已停止")
        super().destroy_node()

def main(args=None):
    # 初始化前声明变量
    node = None
    
    try:
        rclpy.init(args=args)
        node = IMUQuaternionPublisher()
        rclpy.spin(node)
        
    except KeyboardInterrupt:
        if node:
            node.get_logger().info("用户中断")
        else:
            print("用户中断")
            
    except Exception as e:
        if node:
            node.get_logger().error(f"节点崩溃: {e}")
        else:
            print(f"节点初始化失败: {e}")
            
    finally:
        if node:
            node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()