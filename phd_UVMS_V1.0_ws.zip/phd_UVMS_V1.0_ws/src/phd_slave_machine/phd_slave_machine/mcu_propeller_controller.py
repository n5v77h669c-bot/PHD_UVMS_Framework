#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy
import socket
import threading
import select
import time
import numpy as np
from collections import deque

from geometry_msgs.msg import Wrench
from std_msgs.msg import Header
from phd_master_slave_interfaces.msg import ThrusterStatus

class MCUPropellerController(Node):
    def __init__(self):
        super().__init__('mcu_propeller_controller')
        
        # ==================== 参数配置 ====================
        self.declare_parameters(
            namespace='',
            parameters=[
                # 网络连接参数
                ('mcu_ip', '192.168.2.125'),
                ('mcu_port', 1007),
                # 频率控制
                ('publish_hz', 50.0),           # 状态发布频率
                ('send_hz', 50.0),              # 指令发送频率
                ('receive_hz', 100.0),          # 数据接收频率
                # 网络连接参数
                ('auto_reconnect', True),
                ('reconnect_delay', 1.0),
                ('max_reconnect_delay', 30.0),
            ]
        )
        
        # ==================== 参数加载 ====================
        # 网络参数
        self.mcu_ip = self.get_parameter('mcu_ip').value
        self.mcu_port = self.get_parameter('mcu_port').value
        # 频率参数
        self.publish_hz = self.get_parameter('publish_hz').value
        self.send_hz = self.get_parameter('send_hz').value
        self.receive_hz = self.get_parameter('receive_hz').value
        # 网络连接参数
        self.auto_reconnect = self.get_parameter('auto_reconnect').value
        self.reconnect_delay = self.get_parameter('reconnect_delay').value
        self.max_reconnect_delay = self.get_parameter('max_reconnect_delay').value
        
        # ==================== 数据存储 ====================
        # 推进器名称映射
        self.thruster_mapping = {
            # 发送映射：消息字段 -> 物理通道索引
            'send': {
                'lfu': 1,   # 左前上 连接到物理通道0
                'lfd': 0,   # 左前下 连接到物理通道1
                'rfu': 4,   # 右前上 连接到物理通道2
                'rfd': 5,   # 右前下 连接到物理通道3
                'lbu': 2,   # 左后上 连接到物理通道4
                'lbd': 3,   # 左后下 连接到物理通道5
                'rbu': 7,   # 右后上 连接到物理通道6
                'rbd': 6,   # 右后下 连接到物理通道7
            },
            # 接收映射：物理通道索引 -> 消息字段
            'receive': {}
        }
        # 自动生成反向映射（用于接收状态）
        for name, channel in self.thruster_mapping['send'].items():
            self.thruster_mapping['receive'][channel] = name
        
        self.thruster_names = ['lfu', 'lfd', 'rfu', 'rfd', 'lbu', 'lbd', 'rbu', 'rbd']
        self.thruster_indices = {name: i for i, name in enumerate(self.thruster_names)}
        
        # 当前状态
        self.set_powers = np.array([100] * 8, dtype=np.int32)  # 设置功率 (0-200)
        self.actual_powers = np.array([100] * 8, dtype=np.int32)  # 实际功率 (0-200)
        self.last_set_powers = np.array([100] * 8, dtype=np.int32)  # 上次设置功率
        
        # 添加指令队列，解决定时器问题
        self.pending_command = None
        self.command_ready = False
        
        # 数据锁
        self.data_lock = threading.Lock()
        self.force_lock = threading.Lock()
        self.command_lock = threading.Lock()
        
        # 统计信息
        self.stats = {
            'packets_sent': 0,
            'packets_received': 0,
            'parse_errors': 0,
            'send_errors': 0,
            'last_stat_time': time.time(),
        }
        
        # 连接状态
        self.connected = False
        
        # ==================== QoS配置 ====================
        qos_profile = QoSProfile(
            depth=10,
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            history=QoSHistoryPolicy.KEEP_LAST
        )
        
        # ==================== 发布 订阅 ====================
        # 推进器状态发布器
        self.status_pub = self.create_publisher(
            ThrusterStatus,
            '/thrusters/status',
            qos_profile
        )
        
        self.thrusters_cmd_sub = self.create_subscription(
            ThrusterStatus,
            '/masterMachine/thrusters_command',
            self.thrusters_cmd_callback,
            qos_profile,
        )
        
        # ==================== 定时器 ====================
        # 状态发布定时器
        publish_interval = 1.0 / self.publish_hz
        self.publish_timer = self.create_timer(publish_interval, self._publish_status)
        
        # 指令发送定时器 - 修复：使用正确的方法名
        send_interval = 1.0 / self.send_hz
        self.send_timer = self.create_timer(send_interval, self._send_commands_timer)
        
        # 统计信息定时器
        # self.stat_timer = self.create_timer(10.0, self._print_statistics)
        
        # ==================== 网络通信线程 ====================
        self.running = True
        self.sock = None
        self.receive_thread = threading.Thread(
            target=self._tcp_receiver_worker,
            daemon=True
        )
        self.receive_thread.start()
        
        # ==================== 启动日志 ====================
        self.get_logger().info("=" * 60)
        self.get_logger().info("MCU推进器控制器启动")
        self.get_logger().info(f"连接地址: {self.mcu_ip}:{self.mcu_port}")
        self.get_logger().info(f"状态发布: {self.publish_hz}Hz")
        self.get_logger().info(f"指令发送: {self.send_hz}Hz")
        self.get_logger().info("推进器顺序: " + " ".join(self.thruster_names))
        self.get_logger().info("=" * 60)
    
    def _tcp_receiver_worker(self):
        """TCP接收线程 - 修复解析逻辑"""
        buffer = bytearray()
        current_reconnect_delay = self.reconnect_delay
        
        while self.running and rclpy.ok():
            try:
                # 建立TCP连接
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.settimeout(5.0)
                self.get_logger().info(f"尝试连接到 {self.mcu_ip}:{self.mcu_port}...")
                self.sock.connect((self.mcu_ip, self.mcu_port))
                self.sock.settimeout(0.05)
                self.get_logger().info("MCU推进器连接成功")
                self.connected = True
                current_reconnect_delay = self.reconnect_delay
                buffer.clear()
                
                # 主接收循环
                while self.running and rclpy.ok():
                    try:
                        ready = select.select([self.sock], [], [], 0.01)
                        if not ready[0]:
                            continue
                        
                        data = self.sock.recv(1024)
                        if not data:
                            self.get_logger().warning("连接断开")
                            self.connected = False
                            break
                        
                        buffer.extend(data)
                        self.stats['packets_received'] += 1
                        
                        # 修复：更好的包解析逻辑
                        while len(buffer) >= 11:
                            # 查找包头
                            header_idx = -1
                            for i in range(len(buffer) - 1):
                                if buffer[i] == 0xAB and buffer[i+1] == 0x01:
                                    header_idx = i
                                    break
                            
                            if header_idx == -1:
                                # 没找到包头，清空缓冲区
                                buffer.clear()
                                break
                            
                            # 丢弃包头前的数据
                            if header_idx > 0:
                                buffer = buffer[header_idx:]
                            
                            # 检查是否有完整包
                            if len(buffer) < 11:
                                break
                            
                            # 检查包尾
                            if buffer[10] != 0xFF:
                                # 包尾错误，移除第一个字节继续查找
                                buffer.pop(0)
                                continue
                            
                            # 提取完整数据包
                            packet = buffer[:11]
                            buffer = buffer[11:]
                            
                            # 解析数据包
                            self._parse_response_packet(packet)
                            
                    except socket.timeout:
                        continue
                    except Exception as e:
                        self.get_logger().warning(f"接收数据异常: {e}")
                        self.connected = False
                        break
                        
            except (socket.error, ConnectionRefusedError, TimeoutError) as e:
                self.connected = False
                if self.auto_reconnect:
                    self.get_logger().error(f"连接失败: {e}, {current_reconnect_delay:.1f}秒后重试")
                    time.sleep(current_reconnect_delay)
                    current_reconnect_delay = min(
                        current_reconnect_delay * 1.5,
                        self.max_reconnect_delay
                    )
                    continue
                else:
                    self.get_logger().error(f"连接失败: {e}")
                    break
                    
            except Exception as e:
                self.connected = False
                self.get_logger().error(f"未知错误: {e}")
                time.sleep(5)
                
            finally:
                if self.sock:
                    try:
                        self.sock.close()
                    except:
                        pass
                    self.sock = None
                if self.running and self.auto_reconnect:
                    time.sleep(current_reconnect_delay)
    
    def _parse_response_packet(self, packet):
        """解析MCU返回的数据包"""
        try:
            if len(packet) != 11:
                return
            
            # 提取8个推进器的当前功率
            actual_powers = list(packet[2:10])
            
            with self.data_lock:
                self.actual_powers = np.array(actual_powers, dtype=np.int32)
            
            # 调试输出（降低频率）
            # if self.stats['packets_received'] % 50 == 0:
            #     self.get_logger().debug(
            #         f"接收功率: {actual_powers}",
            #         throttle_duration_sec=1.0
            #     )
            
        except Exception as e:
            self.stats['parse_errors'] += 1
            self.get_logger().warning(f"解析数据包失败: {e}")
    
    def thrusters_cmd_callback(self, msg):
        """推进器指令回调 - 修复：只更新数据，不直接发送"""
        if not self.connected:
            return
        
        try:
            with self.force_lock:
                # 更新设置功率
                new_powers = np.zeros(8, dtype=np.int32)
                new_powers[self.thruster_mapping['send']['lfu']] = msg.set_power_lfu
                new_powers[self.thruster_mapping['send']['lfd']] = msg.set_power_lfd
                new_powers[self.thruster_mapping['send']['rfu']] = msg.set_power_rfu
                new_powers[self.thruster_mapping['send']['rfd']] = msg.set_power_rfd
                new_powers[self.thruster_mapping['send']['lbu']] = msg.set_power_lbu
                new_powers[self.thruster_mapping['send']['lbd']] = msg.set_power_lbd
                new_powers[self.thruster_mapping['send']['rbu']] = msg.set_power_rbu
                new_powers[self.thruster_mapping['send']['rbd']] = msg.set_power_rbd
                self.set_powers = new_powers
            # 标记有待发送的命令
            with self.command_lock:
                self.command_ready = True
                
        except Exception as e:
            self.stats['send_errors'] += 1
            self.get_logger().error(f"处理指令失败: {e}")
    
    def _send_commands_timer(self):
        """定时发送指令 - 修复：添加这个方法"""
        if not self.connected or not self.sock:
            return
        
        # 检查是否有命令需要发送
        with self.command_lock:
            if not self.command_ready:
                return
            self.command_ready = False
        
        try:
            with self.force_lock:
                # 检查功率是否有变化
                power_changed = not np.array_equal(self.set_powers, self.last_set_powers)
                
                if power_changed:
                    # 构建数据包
                    packet = bytearray()
                    packet.append(0xAA)  # 包头
                    packet.append(0x01)  # 设备ID
                    
                    # 添加8个推进器功率
                    for power in self.set_powers:
                        # 确保功率在0-200范围内
                        power = max(0, min(200, int(power)))
                        packet.append(power)
                    
                    packet.append(0xFF)  # 包尾
                    
                    # 发送数据
                    self.sock.sendall(packet)
                    self.stats['packets_sent'] += 1
                    
                    # 保存当前设置值
                    self.last_set_powers = self.set_powers.copy()
                    
                    # 调试输出
                    # if self.stats['packets_sent'] % 50 == 0:
                    #     self.get_logger().debug(
                    #         f"发送功率: {list(self.set_powers)}",
                    #         throttle_duration_sec=1.0
                    #     )
                
        except Exception as e:
            self.stats['send_errors'] += 1
            self.get_logger().error(f"发送指令失败: {e}")
            self.sock = None
            self.connected = False
    
    def _publish_status(self):
        """发布推进器状态"""
        if not self.connected:
            return
        
        try:
            with self.data_lock:
                status_msg = ThrusterStatus()
                status_msg.timestamp = self.get_clock().now().to_msg()

                actual_values = {
                    'lfu': 0, 'lfd': 0, 'rfu': 0, 'rfd': 0,
                    'lbu': 0, 'lbd': 0, 'rbu': 0, 'rbd': 0
                }
                for channel, name in self.thruster_mapping['receive'].items():
                    if channel < len(self.actual_powers):
                        actual_values[name] = int(self.actual_powers[channel])
                
                # 实际功率
                status_msg.actual_power_lfu = actual_values['lfu']
                status_msg.actual_power_lfd = actual_values['lfd']
                status_msg.actual_power_rfu = actual_values['rfu']
                status_msg.actual_power_rfd = actual_values['rfd']
                status_msg.actual_power_lbu = actual_values['lbu']
                status_msg.actual_power_lbd = actual_values['lbd']
                status_msg.actual_power_rbu = actual_values['rbu']
                status_msg.actual_power_rbd = actual_values['rbd']
                
                # 状态标志
                status_msg.data_valid = True
                status_msg.temperature = 25.0
                
                # 发布
                self.status_pub.publish(status_msg)
                
        except Exception as e:
            self.get_logger().error(f"发布状态失败: {e}")
    
    def _print_statistics(self):
        """输出统计信息"""
        if not self.connected:
            self.get_logger().info("等待MCU连接...")
            return
            
        current_time = time.time()
        interval = current_time - self.stats['last_stat_time']
        
        if interval > 0:
            send_rate = self.stats['packets_sent'] / interval
            receive_rate = self.stats['packets_received'] / interval
            
            with self.data_lock:
                avg_set_power = np.mean(self.set_powers)
                avg_actual_power = np.mean(self.actual_powers)
                power_diff = np.mean(np.abs(self.set_powers - self.actual_powers))
            
            self.get_logger().info(
                f"推进器统计: "
                f"发送={send_rate:.1f}Hz ({self.stats['packets_sent']}) | "
                f"接收={receive_rate:.1f}Hz ({self.stats['packets_received']}) | "
                f"错误={self.stats['parse_errors']}/{self.stats['send_errors']} | "
                f"功率: 设置={avg_set_power:.1f}, 实际={avg_actual_power:.1f}, 差={power_diff:.1f}"
            )
            
            # 重置统计
            self.stats['packets_sent'] = 0
            self.stats['packets_received'] = 0
            self.stats['parse_errors'] = 0
            self.stats['send_errors'] = 0
            self.stats['last_stat_time'] = current_time
    
    def destroy_node(self):
        """清理资源"""
        self.get_logger().info("关闭MCU推进器控制器...")
        self.running = False
        self.connected = False
        
        # 发送停止指令
        if self.sock:
            try:
                stop_packet = bytes([0xAA, 0x01] + [100]*8 + [0xFF])
                self.sock.sendall(stop_packet)
                time.sleep(0.1)
            except:
                pass
        
        # 等待线程结束
        if hasattr(self, 'receive_thread') and self.receive_thread.is_alive():
            self.receive_thread.join(timeout=2.0)
        
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    
    node = None
    try:
        node = MCUPropellerController()
        rclpy.spin(node)
    except KeyboardInterrupt:
        if node:
            node.get_logger().info("用户中断")
    except Exception as e:
        if node:
            node.get_logger().error(f"节点崩溃: {e}")
        else:
            print(f"节点启动失败: {e}")
    finally:
        if node:
            node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()