cmake_minimum_required(VERSION 3.22)
project(phd_uvms_moveitGZ)

find_package(ament_cmake REQUIRED)

if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/launch")
install(
  DIRECTORY launch
    DESTINATION share/${PROJECT_NAME}
    PATTERN "setup_assistant.launch" EXCLUDE)
    endif()
    
    install(DIRECTORY config world plugin
    DESTINATION share/${PROJECT_NAME}
    )
    
    install(FILES .setup_assistant DESTINATION share/${PROJECT_NAME})
    
ament_package()